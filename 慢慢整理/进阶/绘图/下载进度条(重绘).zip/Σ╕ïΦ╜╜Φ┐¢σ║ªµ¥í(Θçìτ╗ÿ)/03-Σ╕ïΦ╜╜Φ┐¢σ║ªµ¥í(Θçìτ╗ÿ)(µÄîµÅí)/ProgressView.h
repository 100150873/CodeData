//
//  ProgressView.h
//  03-下载进度条(重绘)(掌握)
//
//  Created by xiaomage on 16/1/22.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProgressView : UIView


/** 当前的进度值 */
@property (nonatomic, assign) CGFloat progressValue;

@end
