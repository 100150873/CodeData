//
//  ViewController.h
//  05-UIKit绘图演练(熟悉)
//
//  Created by xiaomage on 16/1/22.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

