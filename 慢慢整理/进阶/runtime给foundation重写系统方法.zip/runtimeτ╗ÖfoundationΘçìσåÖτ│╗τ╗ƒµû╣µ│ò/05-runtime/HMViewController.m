//
//  HMViewController.m
//  05-runtime
//
//  Created by apple on 14-8-21.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import "HMViewController.h"
#import "HMPerson.h"
#import <objc/runtime.h>
#import <objc/message.h>

@interface HMViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *iconView1;
@property (weak, nonatomic) IBOutlet UIImageView *iconView2;

@property (nonatomic, strong) NSMutableArray *names;
@property (nonatomic, strong) NSArray *books;

@end

@implementation HMViewController

- (NSMutableArray *)names
{
    if (_names == nil) {
        self.names = [NSMutableArray array];
    }
    return _names;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    
//    NSDictionary *info = @{@"name" : @"jack", @"age" : @10};
//    
//    NSString *key = nil;
//    
//    NSLog(@"%@", info[key]);
    
    NSMutableDictionary *info = [NSMutableDictionary dictionary];
    info[@"name"] = nil;
    
//    self.books = @[@"kiuhua", @"xxx"];
//
//    NSLog(@"%@", self.books[4]);
    
//    [self addName:@"jack"];
//    [self addName:@"rose"];
//    [self addName:@"jim"];
//
//    NSLog(@"%@", self.names[4]);
//    NSLog(@"%@", [self.names objectAtIndex:4]);
}

- (void)addName:(NSString *)name
{
    [self.names addObject:name];
}

- (void)imageSwizzle
{
    // 什么是iOS Swizzle？利用运行时函数交换2个方法的实现
    
    //    BOOL iOS7 = [[UIDevice currentDevice].systemVersion floatValue] >= 7.0;
    //    if (iOS7) {
    //        self.iconView1.image = [UIImage imageNamed:@"face_os7"];
    //        self.iconView2.image = [UIImage imageNamed:@"vip_os7"];
    //    } else {
    //        self.iconView1.image = [UIImage imageNamed:@"face"];
    //        self.iconView2.image = [UIImage imageNamed:@"vip"];
    //    }
    self.iconView1.image = [UIImage imageNamed:@"face"];
    self.iconView2.image = [UIImage imageNamed:@"vip"];
}

- (void)testRuntimeIvar
{
    // Ivar : 成员变量
    unsigned int count = 0;
    // 获得所有的成员变量
    Ivar *ivars = class_copyIvarList([HMPerson class], &count);
    for (int i = 0; i<count; i++) {
        // 取得i位置的成员变量
        Ivar ivar = ivars[i];
        const char *name = ivar_getName(ivar);
        const char *type = ivar_getTypeEncoding(ivar);
        NSLog(@"%d %s %s", i, name, type);
    }
    
    //    HMPerson *p = [[HMPerson alloc] init];
    //    objc_msgSend(p, @selector(setAge:), 20);
    
    //    NSLog(@"%d", p.age);
}

@end
