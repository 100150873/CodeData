//
//  UIImage+Extension.m
//  05-runtime
//
//  Created by apple on 14-8-21.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import <objc/runtime.h>

@implementation UIImage (Extension)
/**
 *  只要分类被装载到内存中，就会调用1次
 */
+ (void)load
{
    Method otherMehtod = class_getClassMethod(self, @selector(imageWithName:));
    Method originMehtod = class_getClassMethod(self, @selector(imageNamed:));
    // 交换2个方法的实现
    method_exchangeImplementations(otherMehtod, originMehtod);
}

+ (UIImage *)imageWithName:(NSString *)name
{
    BOOL iOS7 = [[UIDevice currentDevice].systemVersion floatValue] >= 7.0;
    UIImage *image = nil;
    if (iOS7) {
        NSString *newName = [name stringByAppendingString:@"_os7"];
        image = [UIImage imageWithName:newName];
    }
    
    if (image == nil) {
        image = [UIImage imageWithName:name];
    }
    return image;
}


@end
