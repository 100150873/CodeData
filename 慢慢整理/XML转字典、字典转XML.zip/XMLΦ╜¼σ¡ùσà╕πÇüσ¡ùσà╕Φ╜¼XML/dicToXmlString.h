//
//  dicToXmlString.h
//  MangoCityTravel
//
//  Created by mangocity on 14-7-29.
//  Copyright (c) 2014年 mangocity. All rights reserved.
//

//  dic to xml

#import <Foundation/Foundation.h>

@interface dicToXmlString : NSObject

+(NSMutableString *)dicToXmlString:(NSMutableDictionary *)dic;
+(NSMutableString *)dicToXmlString2:(NSMutableDictionary *)dic;

@end
