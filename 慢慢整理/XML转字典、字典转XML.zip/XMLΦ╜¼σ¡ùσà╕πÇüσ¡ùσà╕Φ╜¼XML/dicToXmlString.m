//
//  dicToXmlString.m
//  MangoCityTravel
//
//  Created by mangocity on 14-7-29.
//  Copyright (c) 2014年 mangocity. All rights reserved.
//

#import "dicToXmlString.h"

@implementation dicToXmlString

/** dic to xml string */
+(NSMutableString *)dicToXmlString:(NSMutableDictionary *)dic
{
    NSMutableString *returnStr=[[NSMutableString alloc]init];
    [returnStr appendString:@"<body>"];
    NSDictionary *currentDic = [NSDictionary dictionaryWithDictionary:dic];
    for (NSString *str in currentDic.allKeys) {
        id tempVal = [currentDic objectForKey:str];
        NSString *stringValue;
        if(tempVal)
        {
            if(tempVal && [tempVal isKindOfClass:[NSNumber class]])
            {
                stringValue = [NSString stringWithFormat:@"%d", [tempVal intValue]];
            }else{
                stringValue = (NSString *)tempVal;
            }
            [returnStr appendString:[NSString stringWithFormat:@"<%@>",str]];
            [returnStr appendString:stringValue];
            [returnStr appendString:[NSString stringWithFormat:@"</%@>",str]];
        }
    }
    [returnStr appendString:@"</body>"];
    return returnStr;
}

/** dic to xml string */
+(NSMutableString *)dicToXmlString2:(NSMutableDictionary *)dic
{
    NSMutableString *returnStr=[[NSMutableString alloc]init];
    [returnStr appendString:@"<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"no\" ?>"];
    [returnStr appendString:@"<mpm>"];
    for (NSString *str in dic.allKeys) {
        if ([str isEqualToString:@"request"]) {
            NSMutableDictionary *dic2=dic[@"request"];
            [returnStr appendString:@"<request>"];
            for(NSString *str2 in dic2.allKeys){
                id tempVal = [dic2 objectForKey:str2];
                if(tempVal)
                {
                    if(tempVal && [tempVal isKindOfClass:[NSNumber class]])
                        tempVal = [NSString stringWithFormat:@"%d", [tempVal intValue]];
                    [returnStr appendString:[NSString stringWithFormat:@"<%@>",str2]];
                    [returnStr appendString:tempVal];
                    [returnStr appendString:[NSString stringWithFormat:@"</%@>",str2]];
                }
            }
            [returnStr appendString:@"</request>"];
        }else{
            id tempVal = [dic objectForKey:str];
            if(tempVal)
            {
                if(tempVal && [tempVal isKindOfClass:[NSNumber class]])
                    tempVal = [NSString stringWithFormat:@"%d", [tempVal intValue]];
                
                [returnStr appendString:[NSString stringWithFormat:@"<%@>",str]];
                [returnStr appendString:tempVal];
                [returnStr appendString:[NSString stringWithFormat:@"</%@>",str]];
            }
        }
    }
    [returnStr appendString:@"</mpm>"];
    return returnStr;
}

@end
