//
//  ViewController.m
//  01-CoreLocatino基本使用
//
//  Created by 李南江 on 14/11/1.
//  Copyright (c) 2014年 itcast. All rights reserved.
//

#import "ViewController.h"
#import <CoreLocation/CoreLocation.h>

@interface ViewController ()<CLLocationManagerDelegate>
/**
 *  定位管理者
 */
@property (nonatomic ,strong) CLLocationManager *mgr;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
//1 检查用户是否 在设置中 打开了定位服务
    if ([CLLocationManager locationServicesEnabled]) {
        NSLog(@"用户打开了位置服务功能");
    }
    else
    {
        NSLog(@"请开启定位:设置 > 隐私 > 位置 > 定位服务");
    }
//2 设置代理 并实现代理方法
    
    self.mgr.delegate = self;
    self.mgr.distanceFilter = 500; //设置多久获取一次
    /*
     设置获取位置的精确度
     kCLLocationAccuracyBestForNavigation 最佳导航
     kCLLocationAccuracyBest;  最精准
     kCLLocationAccuracyNearestTenMeters;  10米
     kCLLocationAccuracyHundredMeters;  百米
     kCLLocationAccuracyKilometer;  千米
     kCLLocationAccuracyThreeKilometers;  3千米
     */
    self.mgr.desiredAccuracy = kCLLocationAccuracyNearestTenMeters;
    
// 3 info中添加描述使用 定位的目的 并向用户申请授权
    /**
     注意: iOS7只要开始定位, 系统就会自动要求用户对你的应用程序授权. 但是从iOS8开始, 想要定位必须先"自己""主动"要求用户授权
     在iOS8中不仅仅要主动请求授权, 而且必须再info.plist文件中配置一项属性才能弹出授权窗口
     定位权限：Privacy - Location When In Use Usage Description 我们需要通过您的地理位置信息获取您周边的相关数据
     定位权限: Privacy - Location Always Usage Description 我们需要通过您的地理位置信息获取您周边的相关数据
     定位的需要这么写，防止上架被拒
     如多需要 使用后台定位服务 需要在 info中添加Required background modes 这个KEY以及它里面的元素App registers for location updates 否则不添加这个值
     self.mgr.allowsBackgroundLocationUpdates = YES;
     */


    //4 开始定位
    if([[UIDevice currentDevice].systemVersion doubleValue] >= 8.0)
    {
        // 主动要求用户对我们的程序授权, 授权状态改变就会通知代理
        [self.mgr requestAlwaysAuthorization]; // 请求前台和后台定位权限
//        [self.mgr requestWhenInUseAuthorization];// 请求前台定位权限
    }
    else
    {
        // 3.开始监听(开始获取位置)
        [self.mgr startUpdatingLocation];
    }
    
}

/**
 *  授权状态发生改变时调用
 *
 *  @param manager 触发事件的对象
 *  @param status  当前授权的状态
 */
- (void)locationManager:(CLLocationManager *)manager didChangeAuthorizationStatus:(CLAuthorizationStatus)status
{
    /*
     用户从未选择过权限
     kCLAuthorizationStatusNotDetermined
     无法使用定位服务，该状态用户无法改变
     kCLAuthorizationStatusRestricted
     用户拒绝该应用使用定位服务，或是定位服务总开关处于关闭状态
     kCLAuthorizationStatusDenied
     已经授权（废弃）
     kCLAuthorizationStatusAuthorized
     用户允许该程序无论何时都可以使用地理信息
     kCLAuthorizationStatusAuthorizedAlways
     用户同意程序在可见时使用地理位置
     kCLAuthorizationStatusAuthorizedWhenInUse
     */
    
    if (status == kCLAuthorizationStatusNotDetermined)
    {
        NSLog(@"等待用户授权");
    }
    else if (status == kCLAuthorizationStatusAuthorizedAlways ||
              status == kCLAuthorizationStatusAuthorizedWhenInUse)
        
    {
        NSLog(@"授权成功");
        // 开始定位
        [self.mgr startUpdatingLocation];
        
    }else
    {
        NSLog(@"授权失败");
    }
}

#pragma mark - CLLocationManagerDelegate
//- (void)locationManager:(CLLocationManager *)manager didUpdateToLocation:(CLLocation *)newLocation fromLocation:(CLLocation *)oldLocation
/**
 *  获取到位置信息之后就会调用(调用频率非常高)
 *
 *  @param manager   触发事件的对象
 *  @param locations 获取到的位置
 */
- (void)locationManager:(CLLocationManager *)manager didUpdateLocations:(NSArray *)locations
{
    NSLog(@"%s", __func__);
    // 如果只需要获取一次, 可以获取到位置之后就停止
//    [self.mgr stopUpdatingLocation];
    
}

#pragma mark - 懒加载
- (CLLocationManager *)mgr
{
    if (!_mgr)
    {
        _mgr = [[CLLocationManager alloc] init];
    }
    return _mgr;
}
@end
