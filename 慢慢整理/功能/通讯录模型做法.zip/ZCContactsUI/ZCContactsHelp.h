//
//  ZCContactsHelp.h
//  RAC
//
//  Created by yixin on 17/4/17.
//  Copyright © 2017年 yixin. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ZCContactsModel.h"
typedef void(^ZCContactBlock) (ZCContactsModel *contactsModel);
@interface ZCContactsHelp : NSObject

+ (NSMutableArray *)getAllPhoneInfo;

- (void)getOnePhoneInfoWithUI:(UIViewController *)target callBack:(ZCContactBlock)block;

@end
