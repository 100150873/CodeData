//
//  ZCContactsModel.h
//  RAC
//
//  Created by yixin on 17/4/17.
//  Copyright © 2017年 yixin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZCContactsModel : NSObject

@property (nonatomic, copy) NSString *num;
@property (nonatomic, copy) NSString *name;

- (instancetype)initWithName:(NSString *)name num:(NSString *)num;

@end
