//
//  ZCContactsModel.m
//  RAC
//
//  Created by yixin on 17/4/17.
//  Copyright © 2017年 yixin. All rights reserved.
//

#import "ZCContactsModel.h"

@implementation ZCContactsModel

- (instancetype)initWithName:(NSString *)name num:(NSString *)num {
    if (self = [super init]) {
        self.name = name;
        self.num = num;
    }
    return self;
}

@end
