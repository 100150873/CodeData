//
//  UIWindow+Extension.m
//  黑马微博2期
//
//  Created by apple on 14-10-12.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import "UIWindow+Extension.h"
#import "LPTabBarController.h"
#import "ZCGuidePageView.h"

static NSString *const KEY_VERSION = @"CFBundleShortVersionString";
@implementation UIWindow (Extension)
- (void)isShowGuidePage
{
   
    // 存储在沙盒中的版本号
    NSString *lastVersion = [[NSUserDefaults standardUserDefaults] objectForKey:KEY_VERSION];
    // 当前软件的版本号
    NSString *currentVersion = [NSBundle mainBundle].infoDictionary[KEY_VERSION];
    
    if (![currentVersion isEqualToString:lastVersion])
    { // 版本号不相同，显示新特性
        ZCGuidePageView *guidePageView = [ZCGuidePageView guidepageViewWithImages:@[@"guidePage_one",
                                      @"guidePage_two",
                                      @"guidePage_three",
                                      @"guidePage_four",] hiddenSkipButton:NO];
        UIViewController *rootViewController = self.rootViewController;
        [rootViewController.view addSubview:guidePageView];
        // 将当前的版本号存进沙盒
        [[NSUserDefaults standardUserDefaults] setObject:currentVersion forKey:KEY_VERSION];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
    else
    {
    }
}
@end
