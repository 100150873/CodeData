//
//  ZCGuidePageView.h
//  GuidePage
//
//  Created by yixin on 17/3/29.
//  Copyright © 2017年 shining3d. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZCGuidePageView : UIView

+ (instancetype)guidepageViewWithImages:(NSArray *)images hiddenSkipButton:(BOOL)hidden;

- (instancetype)initWithImages:(NSArray *)images hiddenSkipButton:(BOOL)hidden;
@end
