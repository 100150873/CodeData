//
//  ZCGuidePageView.m
//  GuidePage
//
//  Created by yixin on 17/3/29.
//  Copyright © 2017年 shining3d. All rights reserved.
//

#import "ZCGuidePageView.h"
#define Button_Name    @"开始体验"
#define Button_Height    50
@interface ZCGuidePageView ()<UIScrollViewDelegate>
@property(nonatomic,strong)NSArray *arrayImages;
@property(nonatomic,strong)UIButton *buttonEnter;
@property(nonatomic,strong)UIButton *buttonSkip;
@property(nonatomic,strong)UIScrollView *scrollViewGuide;
@property(nonatomic,strong)UIPageControl *pageControl;
@property(nonatomic,assign)BOOL isHidden;
@end

@implementation ZCGuidePageView

+ (instancetype)guidepageViewWithImages:(NSArray *)images hiddenSkipButton:(BOOL)hidden
{
    return [[[self class] alloc]initWithImages:images hiddenSkipButton:hidden];
}

- (instancetype)initWithImages:(NSArray *)images hiddenSkipButton:(BOOL)hidden
{
    self = [super initWithFrame:CGRectMake(0, 0, PhoneScreen_WIDTH, PhoneScreen_HEIGHT)];
    if (self)
    {
        _isHidden = hidden;
        _arrayImages = images;
        [self setupScrollView];
        [self setupButtonSkip];
        [self addScrollViewSubViews];
        [self setupPageControl];
        
    }
    return self;
}

#pragma mark - InitUI
- (void)setupScrollView
{
    [self addSubview:({
        UIScrollView *scrollView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, self.width, self.height)];
        scrollView.bounces = NO;
        scrollView.delegate = self;
        scrollView.contentSize = CGSizeMake(_arrayImages.count * self.width, self.height);
        scrollView.showsHorizontalScrollIndicator = NO;
        scrollView.pagingEnabled = YES;
        _scrollViewGuide = scrollView;
    })];
}

- (void)setupPageControl
{
    [self addSubview:({
        UIPageControl *pageCon = [[UIPageControl alloc]initWithFrame:CGRectMake(self.width*0.1, self.height*0.9, self.width*0.8, Button_Height)];
        pageCon.currentPage = 0;
        pageCon.numberOfPages = _arrayImages.count;
        pageCon.pageIndicatorTintColor = [UIColor grayColor];
        pageCon.currentPageIndicatorTintColor = [UIColor redColor];
        _pageControl = pageCon;
    })];
}

- (void)addScrollViewSubViews
{
    NSUInteger count = _arrayImages.count;
    for (NSInteger i = 0; i < count; i ++)
    {
       
        UIImageView *imageView = [[UIImageView alloc]initWithFrame:(CGRect){i * self.width, 0, self.bounds.size}];
        imageView.image = [UIImage imageNamed:_arrayImages[i]];
        [_scrollViewGuide addSubview:imageView];
        if (i == count - 1)
        {
            imageView.userInteractionEnabled = YES;
            [imageView addSubview:({
                UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(self.width*0.3, self.height*0.8, self.width*0.4, Button_Height)];
                [btn setTitle:Button_Name forState:UIControlStateNormal];
                btn.titleLabel.font = [UIFont systemFontOfSize:21];
                [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
                btn.backgroundColor = [UIColor colorWithRed:0.188 green:0.671 blue:0.271 alpha:1.000];
                [btn addTarget:self action:@selector(clickedButtonEnter:) forControlEvents:UIControlEventTouchUpInside];
                _buttonEnter = btn;
            })];
        }
    }
}

- (void)setupButtonSkip
{
    [self addSubview:({
        UIButton *buttonSkip = [[UIButton alloc] initWithFrame:CGRectMake(self.width*0.8, self.width*0.1, Button_Height, Button_Height * 0.5)];
        [buttonSkip setTitle:@"跳过" forState:UIControlStateNormal];
        [buttonSkip setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        buttonSkip.layer.borderWidth = 0.5;
        buttonSkip.layer.borderColor = [UIColor blackColor].CGColor;
        buttonSkip.titleLabel.font = [UIFont systemFontOfSize:15];
        buttonSkip.backgroundColor = [UIColor whiteColor];
        buttonSkip.layer.cornerRadius = 5;
        buttonSkip.hidden = _isHidden;
        [buttonSkip addTarget:self action:@selector(clickedButtonEnter:) forControlEvents:UIControlEventTouchUpInside];
        _buttonSkip = buttonSkip;
    })];
}

#pragma mark - Action
- (void)clickedButtonEnter:(UIButton *)btn
{
    [UIView animateWithDuration:0.5 animations:^{
        self.alpha = 0;
        [self removeFromSuperview];
    }];
}

#pragma mark - UIScrollViewDelegate
- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    _pageControl.currentPage = scrollView.contentOffset.x / self.bounds.size.width + 0.5;
    _buttonSkip.hidden = (_pageControl.currentPage == _arrayImages.count - 1) ? YES : _isHidden;

    
}

@end
