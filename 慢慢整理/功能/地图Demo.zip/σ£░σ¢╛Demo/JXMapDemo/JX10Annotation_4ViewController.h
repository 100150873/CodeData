//
//  JX10Annotation_4ViewController.h
//  JXMapDemo
//
//  Created by JackXu on 15/11/22.
//  Copyright © 2015年 BFMobile. All rights reserved.
//

#import "BaseViewController.h"

@interface JX10Annotation_4ViewController : BaseViewController

@end
