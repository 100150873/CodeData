//
//  BaseViewController.h
//  JXMapDemo
//
//  Created by JackXu on 15/11/22.
//  Copyright © 2015年 BFMobile. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <MapKit/MapKit.h>

@interface BaseViewController : UIViewController
@property (nonatomic,strong) MKMapView *mapView;

@end
