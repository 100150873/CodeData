//
//  ZbarViewController.h
//  MangoCityTravel
//
//  Created by chenyangmo on 15-3-18.
//  Copyright (c) 2015年 mangocity. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZBarReaderView.h"
#import "ZBarSDK.h"
#import <AVFoundation/AVFoundation.h>

#define TOPBAR_ALPHA 0.8
#define FOUR_ALPHA 0.5
#define TOPBARHEIGHT (IOS7ABOVE?64:44)
#define IOS7ABOVE ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0f ? YES : NO)

@protocol ZbarViewControllerDelegate <NSObject>

//扫描成功
-(void)zbarScanSuccess:(NSString *)content;

@end

@interface ZbarViewController : UIViewController
@property(nonatomic,weak)id <ZbarViewControllerDelegate> delegate;
@end
