//
//  ZbarViewController.m
//  MangoCityTravel
//
//  Created by chenyangmo on 15-3-18.
//  Copyright (c) 2015年 mangocity. All rights reserved.
//

#import "ZbarViewController.h"
#import <AVFoundation/AVFoundation.h>
#import "ZCQRCodeTool.h"
#define BackW  60
#define CloseW  40
@interface ZbarViewController ()
@property(nonatomic,strong)UIView *navigationView;
@property(nonatomic,strong)UIButton *buttonBack;
@property(nonatomic,strong)UILabel *labelTitle;
@property (nonatomic,strong) UIView *scanBackView;
@property (nonatomic,strong) UIImageView *imageViewBorder;
@property (nonatomic,strong) UIImageView *imageViewLine;
@end

@implementation ZbarViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self beginScan];
    self.navigationView.backgroundColor = [UIColor blackColor];
    [self.buttonBack addTarget:self action:@selector(backPre:) forControlEvents:UIControlEventTouchDown];
    self.labelTitle.text = @"扫一扫";
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self beginScanAnimation];

}

// 开始扫描
- (void)beginScan
{
    
    [ZCQRCodeTool sharedZCQRCodeTool].isDrawQRCodeRect = YES;
    [[ZCQRCodeTool sharedZCQRCodeTool] setInsteretRect:self.scanBackView.frame];
    [[ZCQRCodeTool sharedZCQRCodeTool] beginScanInView:self.view result:^(NSArray<NSString *> *resultStrs) {
        [[ZCQRCodeTool sharedZCQRCodeTool] stopScan];
        if ([self.delegate respondsToSelector:@selector(zbarScanSuccess:)])
        {
            [self.delegate zbarScanSuccess:resultStrs.lastObject];
        }
    }];
    
    
    
}


// 开始扫描动画
- (void)beginScanAnimation
{

    [UIView animateWithDuration:2.0 delay:1.0 options:UIViewAnimationOptionCurveLinear animations:^{
        [UIView setAnimationRepeatCount:CGFLOAT_MAX];
        self.imageViewLine.transform = CGAffineTransformTranslate(self.imageViewLine.transform, 0, self.scanBackView.height - self.imageViewLine.height);
    } completion:^(BOOL finished) {
        self.imageViewLine.transform = CGAffineTransformIdentity;
    }];
    
}

- (void)backPre:(UIButton *)buttonBack
{

[self dismissViewControllerAnimated:YES completion:^{
}];
}

- (UIView *)scanBackView
{
    if (!_scanBackView) {
        _scanBackView = [UIView new];
//        _scanBackView.backgroundColor = [UIColor redColor];
        [self.view addSubview:_scanBackView];
        _scanBackView.bounds = CGRectMake(0, 0, 200, 200);
        _scanBackView.center = self.view.center;
        self.imageViewBorder.image = [UIImage imageNamed:@"qrcode_border"];
        self.imageViewLine.image = [UIImage imageNamed:@"scanline"];

    }
    return _scanBackView;
}

- (UIImageView *)imageViewBorder
{
    if (!_imageViewBorder) {
        _imageViewBorder = [UIImageView new];
        [self.scanBackView addSubview:_imageViewBorder];
        _imageViewBorder.frame = CGRectMake(0, 0, self.scanBackView.width, self.scanBackView.height);
    }
    return _imageViewBorder;
}

- (UIImageView *)imageViewLine
{
    if (!_imageViewLine) {
        _imageViewLine = [UIImageView new];
        [self.scanBackView addSubview:_imageViewLine];
        _imageViewLine.frame = CGRectMake(0, 0, self.scanBackView.width, 18);
    }
    return _imageViewLine;
}

- (UIView *)navigationView
{
    if (!_navigationView)
    {
        _navigationView = [UIView new];
        _navigationView.frame = CGRectMake(0, 0, SCREEN_WIDTH, 64);
        [self.view addSubview:_navigationView];
    }
    return _navigationView;
}

- (UILabel *)labelTitle
{
    if (!_labelTitle)
    {
        _labelTitle = [UILabel new];
        _labelTitle.font = FONT_18;
        _labelTitle.textAlignment = NSTextAlignmentCenter;
        _labelTitle.textColor = [UIColor whiteColor];
        [self.navigationView addSubview:_labelTitle];
        _labelTitle.frame = CGRectMake(0, 20, 100, 44);
        _labelTitle.centerX = self.view.centerX;
    }
    return _labelTitle;
}

- (UIButton *)buttonBack
{
    if (!_buttonBack) {
        _buttonBack = [UIButton new];
        _buttonBack.titleLabel.font = FONT_16;
        [_buttonBack setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        [_buttonBack setImage:[UIImage imageNamed:@"back"] forState:UIControlStateNormal];
        [self.navigationView addSubview:_buttonBack];
        _buttonBack.frame = CGRectMake(10, 20, BackW, 44);
    }
    return _buttonBack;
}

@end
