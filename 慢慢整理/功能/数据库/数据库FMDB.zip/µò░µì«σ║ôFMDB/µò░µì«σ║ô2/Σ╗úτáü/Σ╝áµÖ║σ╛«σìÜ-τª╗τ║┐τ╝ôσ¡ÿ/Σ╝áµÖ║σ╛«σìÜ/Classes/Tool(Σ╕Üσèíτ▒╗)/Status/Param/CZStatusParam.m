//
//  CZStatusParam.m
//  传智微博
//
//  Created by apple on 15-3-10.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "CZStatusParam.h"

@implementation CZStatusParam

@end
