//
//  CZOriginalView.h
//  传智微博
//
//  Created by apple on 15-3-11.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>
@class CZStatusFrame;
@interface CZOriginalView : UIImageView

@property (nonatomic, strong) CZStatusFrame *statusF;

@end
