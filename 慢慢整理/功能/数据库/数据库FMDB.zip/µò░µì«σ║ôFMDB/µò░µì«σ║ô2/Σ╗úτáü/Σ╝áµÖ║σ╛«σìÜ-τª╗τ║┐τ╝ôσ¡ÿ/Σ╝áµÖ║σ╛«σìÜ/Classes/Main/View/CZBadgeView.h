//
//  CZBadgeView.h
//  传智微博
//
//  Created by apple on 15-3-5.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CZBadgeView : UIButton

@property (nonatomic, copy) NSString *badgeValue;

@end
