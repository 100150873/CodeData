//
//  ImageTool.m
//  04-tableViewCell滑动
//
//  Created by apple on 15-3-16.
//  Copyright (c) 2015年 apple. All rights reserved.
//

#import "ImageTool.h"

@implementation ImageTool
//+ (UIImage *)imageWithName:(NSString *)imageName
//{
//    if (<#condition#>) {
//        <#statements#>
//    }
//}
@end
