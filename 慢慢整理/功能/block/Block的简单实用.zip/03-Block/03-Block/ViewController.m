//
//  ViewController.m
//  03-Block
//
//  Created by xiaomage on 15/6/13.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "ViewController.h"

// name：Block类型别名
typedef void(^MyBlock)(int a);

@interface ViewController ()
@property (nonatomic, weak) MyBlock myBlock1;
@end

@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    _myBlock1 = ^(int a){
        NSLog(@"%d",a);
    };
    
    NSLog(@"%@",_myBlock1);
    // 1.如何定义block
    /*
     // inline
     // blockName：block变量名
     <#returnType#>(^blockName)(<#parameterTypes#>) = ^(<#parameters#>) {
     <#statements#>
     };
     
     */
    
    void(^block)() = ^(){
        NSLog(@"block");
    };
    // block类型:void(^)()
    int a = 0;
     MyBlock myBlock = ^(int a){
         
    };
    
    
    // 调用block
    block();
    myBlock(2);
    
    // 2.block作用:跟函数和方法很像，其实就是用来保存一段代码,等到恰当的时候再去使用
    
    // 3.什么时候使用block，逆传:用block来传值,处理网络的时候经常使用block封装代码。
    
    // 请求网络数据（延迟） 先把展示到控件的代码先保存到block，等请求到数据的时候直接调用Block
    
    // 4.通讯录Block使用:
    // 点击保存，通知联系人刷新表格，用代理
    // block：小弟 代理：打电话
    // block:先把刷新表格的代码保存起来
    // 等用户点击了保存按钮的时候，调用Block
    
    NSLog(@"%@",myBlock);
    
}
- (void)test
{
    NSLog(@"方法");
}
void test()
{
    NSLog(@"test");
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
