//
//  ViewController.m
//  换肤
//
//  Created by xiaomage on 15/8/19.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UIImageView *faceImageView;
@property (weak, nonatomic) IBOutlet UIImageView *heartImageView;
@property (weak, nonatomic) IBOutlet UIImageView *rectImageView;

@end

@implementation ViewController

/*
 问题一:默认进来没有皮肤颜色
 
 问题二:没有记录用户选中皮肤颜色
 
 问题三:和美工沟通的问题
 
 问题四:多个控制器的换肤
 */

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSString *skinColor = [[NSUserDefaults standardUserDefaults] objectForKey:@"skinColor"];
    if (skinColor == nil) {
        skinColor = @"blue";
    }
    
    [self changeSkinWithSkinColor:skinColor];
}

- (IBAction)changeToBlueSkin {
    [self changeSkinWithSkinColor:@"blue"];
}

- (IBAction)changeToRedSkin {
    [self changeSkinWithSkinColor:@"red"];
}

- (IBAction)changeToGreenSkin {
    [self changeSkinWithSkinColor:@"green"];
}

- (void)changeSkinWithSkinColor:(NSString *)skinColor
{
    NSString *faceImageName = [NSString stringWithFormat:@"skin/%@/face", skinColor];
    self.faceImageView.image = [UIImage imageNamed:faceImageName];
    NSString *heartImageName = [NSString stringWithFormat:@"skin/%@/heart", skinColor];
    self.heartImageView.image = [UIImage imageNamed:heartImageName];
    NSString *rectImageName = [NSString stringWithFormat:@"skin/%@/rect", skinColor];
    self.rectImageView.image = [UIImage imageNamed:rectImageName];
    
    // 记录用户选中的皮肤颜色
    [[NSUserDefaults standardUserDefaults] setObject:skinColor forKey:@"skinColor"];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

@end
