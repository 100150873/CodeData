//
//  TwoViewController.m
//  换肤
//
//  Created by xiaomage on 15/8/19.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

#import "TwoViewController.h"

@interface TwoViewController ()

@property (weak, nonatomic) IBOutlet UIImageView *faceImageView;
@property (weak, nonatomic) IBOutlet UIImageView *heartImageView;
@property (weak, nonatomic) IBOutlet UIImageView *rectImageView;

@end

@implementation TwoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSString *skinColor = [[NSUserDefaults standardUserDefaults] objectForKey:@"skinColor"];
    if (skinColor == nil) {
        skinColor = @"blue";
    }
    
    [self changeSkinWithSkinColor:skinColor];
}

- (void)changeSkinWithSkinColor:(NSString *)skinColor
{
    NSString *faceImageName = [NSString stringWithFormat:@"skin/%@/face", skinColor];
    self.faceImageView.image = [UIImage imageNamed:faceImageName];
    NSString *heartImageName = [NSString stringWithFormat:@"skin/%@/heart", skinColor];
    self.heartImageView.image = [UIImage imageNamed:heartImageName];
    NSString *rectImageName = [NSString stringWithFormat:@"skin/%@/rect", skinColor];
    self.rectImageView.image = [UIImage imageNamed:rectImageName];
}

@end
