//
//  ViewController.h
//  05-UIScrollView的代理(delegate)
//
//  Created by xiaomage on 16/1/4.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController 


@end

