//
//  XMGSubcategoryViewController.m
//  10-级联菜单
//
//  Created by xiaomage on 15/7/5.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

#import "XMGSubcategoryViewController.h"

@interface XMGSubcategoryViewController ()
/** 子类别数据 */
@property (nonatomic, strong) NSArray *subcategories;
@end

@implementation XMGSubcategoryViewController

static NSString *subcategoryID = @"subcategory";
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:subcategoryID];
}

#pragma mark - <XMGCategoryViewControllerDelegate>
- (void)categoryViewController:(XMGCategoryViewController *)categoryViewController didSelectSubcategories:(NSArray *)subcategories
{
    self.subcategories = subcategories;
    
    [self.tableView reloadData];
}

#pragma mark - Table view data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.subcategories.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:subcategoryID];
    cell.textLabel.text = self.subcategories[indexPath.row];
    return cell;
}
@end
