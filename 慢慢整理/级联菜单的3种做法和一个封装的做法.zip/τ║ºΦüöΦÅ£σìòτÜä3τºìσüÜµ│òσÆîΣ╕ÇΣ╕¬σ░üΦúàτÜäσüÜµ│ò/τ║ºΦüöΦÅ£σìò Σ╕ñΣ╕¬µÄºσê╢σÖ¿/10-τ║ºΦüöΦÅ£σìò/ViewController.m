//
//  ViewController.m
//  10-级联菜单
//
//  Created by xiaomage on 15/7/5.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

#import "ViewController.h"
#import "XMGCategoryViewController.h"
#import "XMGSubcategoryViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    CGFloat width = self.view.frame.size.width * 0.5;
    CGFloat height = self.view.frame.size.height;
    
    XMGSubcategoryViewController *subcategoryVc = [[XMGSubcategoryViewController alloc] init];
    subcategoryVc.view.frame = CGRectMake(width, 0, width, height);
    [self addChildViewController:subcategoryVc];
    [self.view addSubview:subcategoryVc.view];
    
    XMGCategoryViewController *categoryVc = [[XMGCategoryViewController alloc] init];
    categoryVc.delegate = subcategoryVc;
    categoryVc.view.frame = CGRectMake(0, 0, width, height);
    [self addChildViewController:categoryVc];
    [self.view addSubview:categoryVc.view];
}

@end
