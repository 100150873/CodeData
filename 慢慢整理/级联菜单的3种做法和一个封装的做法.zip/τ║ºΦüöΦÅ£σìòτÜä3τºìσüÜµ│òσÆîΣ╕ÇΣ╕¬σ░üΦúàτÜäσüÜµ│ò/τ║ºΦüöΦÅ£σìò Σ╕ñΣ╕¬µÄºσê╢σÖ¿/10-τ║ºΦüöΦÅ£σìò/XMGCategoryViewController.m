//
//  XMGCategoryViewController.m
//  10-级联菜单
//
//  Created by xiaomage on 15/7/5.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

#import "XMGCategoryViewController.h"
#import "XMGCategory.h"

@interface XMGCategoryViewController ()
/** 所有的类别数据 */
@property (nonatomic, strong) NSArray *categories;
@end

@implementation XMGCategoryViewController

- (NSArray *)categories
{
    if (_categories == nil) {
        NSArray *dictArray = [NSArray arrayWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"categories" ofType:@"plist"]];
        
        NSMutableArray *categoryArray = [NSMutableArray array];
        for (NSDictionary *dict in dictArray) {
            [categoryArray addObject:[XMGCategory categoryWithDict:dict]];
        }
        _categories = categoryArray;
    }
    return _categories;
}

static NSString *categoryID = @"category";
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:categoryID];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.categories.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:categoryID];
    
    XMGCategory *c = self.categories[indexPath.row];
    
    // 设置普通图片
    cell.imageView.image = [UIImage imageNamed:c.icon];
    // 设置高亮图片（cell选中 -> cell.imageView.highlighted = YES -> cell.imageView显示highlightedImage这个图片）
    cell.imageView.highlightedImage = [UIImage imageNamed:c.highlighted_icon];
    
    // 设置label高亮时的文字颜色
    cell.textLabel.highlightedTextColor = [UIColor redColor];
    
    cell.textLabel.text = c.name;
    cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    
    return cell;
}

#pragma mark - <代理方法>
- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    // 告诉代理
    if ([self.delegate respondsToSelector:@selector(categoryViewController:didSelectSubcategories:)]) {
        XMGCategory *c = self.categories[indexPath.row];
        [self.delegate categoryViewController:self didSelectSubcategories:c.subcategories];
    }
}

// 当一个cell被选中的时候，cell内部的子控件都会达到highlighted状态
@end
