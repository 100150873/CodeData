//
//  XMGCategoryViewController.h
//  10-级联菜单
//
//  Created by xiaomage on 15/7/5.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

#import <UIKit/UIKit.h>

@class XMGCategoryViewController;

@protocol XMGCategoryViewControllerDelegate <NSObject>
@optional
- (void)categoryViewController:(XMGCategoryViewController *)categoryViewController didSelectSubcategories:(NSArray *)subcategories;
@end

@interface XMGCategoryViewController : UITableViewController
@property (nonatomic, weak) id<XMGCategoryViewControllerDelegate> delegate;
@end
