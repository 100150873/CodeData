//
//  XMGPerson.m
//  11-通知、KVO、代理
//
//  Created by xiaomage on 15/6/6.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "XMGPerson.h"

@implementation XMGPerson
- (void)test
{
    NSLog(@"test - %@", self.name);
}
@end
