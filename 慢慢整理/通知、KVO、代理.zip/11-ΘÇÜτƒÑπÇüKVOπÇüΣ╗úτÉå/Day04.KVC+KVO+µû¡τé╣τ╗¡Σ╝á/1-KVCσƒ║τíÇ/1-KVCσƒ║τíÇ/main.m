//
//  main.m
//  1-KVC基础
//
//  Created by qianfeng on 15/12/17.
//  Copyright (c) 2015年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"
#import "Dog.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        Person *person = [[Person alloc] init];
        
        //使用KVC， key-value-code,  给一个对象的成员变量赋值
        [person setValue:@"张三" forKey:@"name"];
        NSString *name = [person valueForKey:@"name"];
        NSLog(@"name = %@", name);
        
        [person setValue:@"20" forKey:@"age"];
        NSString *ageStr = [person valueForKey:@"age"];
        NSLog(@"age = %ld", [ageStr integerValue]);
        
        
        Dog *dog = [[Dog alloc] init];
        [person setValue:dog forKeyPath:@"dog"];
        NSLog(@"dog = %@", [person valueForKey:@"dog"]);
        
        
        //通过keypath, 给dog赋值
        [person setValue:@"藏獒" forKeyPath:@"dog.kind"];
        NSLog(@"kind: %@", [person valueForKeyPath:@"dog.kind"]);
        
        
        //如果KVC赋值， key不存在
        [person setValue:@"男性" forKeyPath:@"sex"];
        [person valueForKeyPath:@"sex"];
        
        

    }
    return 0;
}










