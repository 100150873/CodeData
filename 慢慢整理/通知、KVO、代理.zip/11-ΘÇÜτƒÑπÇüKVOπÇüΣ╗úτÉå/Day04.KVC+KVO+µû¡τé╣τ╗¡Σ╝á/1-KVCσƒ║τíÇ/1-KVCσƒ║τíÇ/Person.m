//
//  Person.m
//  1-KVC基础
//
//  Created by qianfeng on 15/12/17.
//  Copyright (c) 2015年 qianfeng. All rights reserved.
//

#import "Person.h"

@implementation Person
//当使用KVC赋值， 找不到对应的key的时候，会调用该函数
- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    NSLog(@"找不到当前的key: %@", key);
}

//当取值的时候， 找不到相应的key, 会调用该方法
- (id)valueForUndefinedKey:(NSString *)key
{
    NSLog(@"取值的时候，找不到key; %@", key);
    return nil;
}

@end
