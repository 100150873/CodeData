//
//  Person.h
//  1-KVC基础
//
//  Created by qianfeng on 15/12/17.
//  Copyright (c) 2015年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Dog.h"

@interface Person : NSObject
{
    NSString *_name;
    //NSInteger _age;
    NSString *_age;
    
    Dog *_dog;
}
@end
