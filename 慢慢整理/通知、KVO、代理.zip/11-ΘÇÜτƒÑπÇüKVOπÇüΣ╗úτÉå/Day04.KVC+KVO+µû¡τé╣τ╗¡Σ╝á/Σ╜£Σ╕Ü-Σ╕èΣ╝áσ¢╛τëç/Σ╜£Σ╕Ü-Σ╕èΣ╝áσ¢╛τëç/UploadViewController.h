//
//  UploadViewController.h
//  作业-上传图片
//
//  Created by qianfeng on 15/12/17.
//  Copyright (c) 2015年 qianfeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UploadViewController : UIViewController

@end
