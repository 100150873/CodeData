//
//  UploadViewController.m
//  作业-上传图片
//
//  Created by qianfeng on 15/12/17.
//  Copyright (c) 2015年 qianfeng. All rights reserved.
//

#import "UploadViewController.h"
#import "AFNetworking.h"

@interface UploadViewController () <UINavigationControllerDelegate, UIImagePickerControllerDelegate>
{
    
    __weak IBOutlet UIImageView *selectImgView;
    
    __weak IBOutlet UIImageView *downloadImgView;
}
@end

@implementation UploadViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}



- (IBAction)selectImgBtnClicked:(UIButton *)sender {
    
    UIImagePickerController *pickerVC = [[UIImagePickerController alloc] init];
    
    pickerVC.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
    
    pickerVC.allowsEditing = YES;
    
    pickerVC.delegate = self;
    
    
    [self presentViewController:pickerVC animated:YES completion:nil];
}


//选择图片的回调函数
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    NSLog(@"info = %@", info);
    
    UIImage *image = info[UIImagePickerControllerOriginalImage];

    
    selectImgView.image = image;

    
    [picker dismissViewControllerAnimated:YES completion:nil];
}





- (IBAction)confirmUploadBtnClicked:(UIButton *)sender {

    
    //AFN + POST + 上传非文本
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
    
    //上传非文本（二进制）
    [manager POST:@"http://10.0.8.8/sns/my/upload_headimage.php" parameters:nil constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        //第一个参数： 需要上传的二进制
        //第二个参数： name, 服务器对应的key(headimage)
        //第三个参数： filename, 保存在服务器上的文件的名字
        //第四个参数： 文件的类型: .png(image/png). jpg(image/jpeg)
        UIImage *image = selectImgView.image;
        //将图片的对象， 转换成二进制
        //UIImagePNGRepresentation
        //UIImageJPEGRepresentation, 对图片进行一个压缩，可以是文件打下变得很小
        
        NSData *data = UIImageJPEGRepresentation(image, 0.0001);
        NSData *data1 = UIImagePNGRepresentation(image);
        NSLog(@"data = %lu", data.length);
        NSLog(@"data1 = %lu", data1.length);
        //NSString *path = [[NSBundle mainBundle] pathForResource:@"photo" ofType:@"png"];
        //NSData *data = [NSData dataWithContentsOfFile:path];
        
        
        [formData appendPartWithFileData:data name:@"headimage" fileName:@"test.jpg" mimeType:@"image/jpeg"];
        
        
    } success:^(AFHTTPRequestOperation *operation, id responseObject) {
        if (responseObject != nil) {
            NSLog(@"message = %@", responseObject[@"message"]);
            
        }
        
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"网络连接失败!");
    }];
}
    
    
- (IBAction)downloadBtnClicked:(UIButton *)sender {
    
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
