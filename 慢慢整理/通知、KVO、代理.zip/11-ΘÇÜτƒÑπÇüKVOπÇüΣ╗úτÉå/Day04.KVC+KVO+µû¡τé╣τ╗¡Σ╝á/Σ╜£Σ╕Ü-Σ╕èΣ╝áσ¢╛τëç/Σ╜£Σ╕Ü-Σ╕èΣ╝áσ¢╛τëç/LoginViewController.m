//
//  LoginViewController.m
//  作业-上传图片
//
//  Created by qianfeng on 15/12/17.
//  Copyright (c) 2015年 qianfeng. All rights reserved.
//

#import "LoginViewController.h"
#import "RegisterViewController.h"
#import "UploadViewController.h"
#import "AFNetworking.h"


#define URL_LOGIN @"http://10.0.8.8/sns/my/login.php"

@interface LoginViewController ()

@property (weak, nonatomic) IBOutlet UITextField *usernameTF;

@property (weak, nonatomic) IBOutlet UITextField *passwdTF;


@end

@implementation LoginViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

//实现反向传值的方法
- (IBAction)unwind:(UIStoryboardSegue *)segue
{
    
    RegisterViewController *registerVC = segue.sourceViewController;
    
    self.usernameTF.text = registerVC.usernameTF.text;
    self.passwdTF.text = registerVC.passwdTF.text;
}

- (IBAction)loginBtnClicked:(UIButton *)sender {
    
    NSString *name = self.usernameTF.text;
    NSString *passwd = self.passwdTF.text;
    
    if (name.length == 0 || passwd.length == 0) {
        return;
    }
    
    
    AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
    
    manager.responseSerializer = [AFJSONResponseSerializer serializer];
    manager.responseSerializer.acceptableContentTypes = [NSSet setWithObject:@"text/html"];
    
    
    NSString *urlStr = [NSString stringWithFormat:@"%@?username=%@&password=%@", URL_LOGIN, name, passwd];
    
    [manager GET:urlStr parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
       
        if (responseObject != nil) {
            NSLog(@"message = %@", responseObject[@"message"]);
            
            if ([responseObject[@"code"] isEqualToString:@"login_success"]) {
             
                //切换到上传图片的界面
                
                UploadViewController *uploadVC = [self.storyboard instantiateViewControllerWithIdentifier:@"uploadvc"];
                
                [self.navigationController pushViewController:uploadVC animated:YES];
                
                
            }
        }
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
    }];
    
    
    
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
