//
//  main.m
//  2-KVC2
//
//  Created by qianfeng on 15/12/17.
//  Copyright (c) 2015年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {

        Person *person = [[Person alloc] init];
        
        NSDictionary *dict
        = @{
                @"name":@"张三",
                @"age":@22,
                @"id":@"001",
                @"score":@100,
                @"height":@"170",
                @"weight":@"60KG"
           };
        
        
        [person setValuesForKeysWithDictionary:dict];
        
        NSLog(@"person = %@", person);
        
    }
    return 0;
}







