//
//  Person.m
//  2-KVC2
//
//  Created by qianfeng on 15/12/17.
//  Copyright (c) 2015年 qianfeng. All rights reserved.
//

#import "Person.h"

@implementation Person
- (NSString *)description
{
    return [NSString stringWithFormat:@"name:%@, age:%@, num:%@, score:%@", _name, _age, _num, _score];
}

//重写父类的KVC的方法

//
- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    NSLog(@"找不到key: %@", key);
    if ([key isEqualToString:@"id"]) {
        [self setValue:value forKey:@"num"];
    }
}

//当value的类型， 和模型的类型不一致， 也需要重写该方法
- (void)setValue:(id)value forKey:(NSString *)key
{
    //将字典里面所有的NSNumber都转换成为 NSString
    if ([value isKindOfClass:[NSNumber class]]) {
        [super setValue:[NSString stringWithFormat:@"%@", value] forKey:key];
    } else {
        [super setValue:value forKey:key];
    }
}

- (id)valueForUndefinedKey:(NSString *)key
{
    return nil;
}




@end
