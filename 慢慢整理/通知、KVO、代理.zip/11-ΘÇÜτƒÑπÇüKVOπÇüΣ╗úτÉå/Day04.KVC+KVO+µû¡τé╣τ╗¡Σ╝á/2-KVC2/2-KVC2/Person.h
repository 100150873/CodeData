//
//  Person.h
//  2-KVC2
//
//  Created by qianfeng on 15/12/17.
//  Copyright (c) 2015年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Person : NSObject
{
    NSString *_name;
    
    
    NSString *_age;
    
    //学号
    NSString *_num;
    
    //成绩
    NSString *_score;
}
@end
