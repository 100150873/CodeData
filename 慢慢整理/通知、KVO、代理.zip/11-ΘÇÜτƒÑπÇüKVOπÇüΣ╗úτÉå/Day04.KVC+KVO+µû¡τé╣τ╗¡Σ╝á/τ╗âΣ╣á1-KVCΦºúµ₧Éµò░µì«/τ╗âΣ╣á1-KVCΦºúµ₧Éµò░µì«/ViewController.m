//
//  ViewController.m
//  练习1-KVC解析数据
//
//  Created by qianfeng on 15/12/17.
//  Copyright (c) 2015年 qianfeng. All rights reserved.
//

#import "ViewController.h"
#import "MovieModel.h"

@interface ViewController ()

@property (nonatomic, strong) NSMutableArray *dataSource;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _dataSource = [NSMutableArray array];
    
    
    
    NSURL *url = [NSURL URLWithString:@"http://api.douban.com/v2/movie/us_box?apikey=02970273f8e1e22a07c5075beaa5a67e"];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
       
        NSDictionary *jsonDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
        NSLog(@"jsonDic = %@", jsonDic);
        
        for (NSDictionary *movieDic in jsonDic[@"subjects"]) {
            NSDictionary *subjectDic = movieDic[@"subject"];
            
            MovieModel *model = [[MovieModel alloc] init];

            
            [model setValuesForKeysWithDictionary:subjectDic];
            
            [_dataSource addObject:model];
        }
        
        for (MovieModel *model in _dataSource) {
            NSLog(@"%@", model);
        }
    
        
    }];
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
