//
//  MovieModel.m
//  练习1-KVC解析数据
//
//  Created by qianfeng on 15/12/17.
//  Copyright (c) 2015年 qianfeng. All rights reserved.
//

#import "MovieModel.h"

@implementation MovieModel

- (NSString *)description
{
    return [NSString stringWithFormat:@"%@, %@, %@, %@, %@", _title, _imageUrl, _rating, _numid, _castsMutArr];
}

- (id)init
{
    self = [super init];
    if (self) {
        _castsMutArr = [NSMutableArray array];
    }
    return self;
}


- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    if ([key isEqualToString:@"images"]) {
        [super setValue:value[@"small"] forKey:@"imageUrl"];
    } else if ([key isEqualToString:@"id"]) {
        [super setValue:[NSString stringWithFormat:@"%@", value] forKey:@"numid"];
    } else if ([key isEqualToString:@"casts"]) {

        for (NSDictionary *castDic in value) {
            NSString *name = castDic[@"name"];
            
            [_castsMutArr addObject:name];
        }
        
    }
}

- (void)setValue:(id)value forKey:(NSString *)key
{
    if ([key isEqualToString:@"rating"]) {
        NSString *str = [NSString stringWithFormat:@"%@", value[@"average"]];
        [super setValue:str forKey:key];
    } else {
        [super setValue:value forKey:key];
    }
}
@end
