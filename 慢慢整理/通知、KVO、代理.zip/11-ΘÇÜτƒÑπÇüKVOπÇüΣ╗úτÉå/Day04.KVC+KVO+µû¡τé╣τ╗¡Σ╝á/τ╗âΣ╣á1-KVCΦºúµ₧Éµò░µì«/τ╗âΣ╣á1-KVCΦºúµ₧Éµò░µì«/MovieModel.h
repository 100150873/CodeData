//
//  MovieModel.h
//  练习1-KVC解析数据
//
//  Created by qianfeng on 15/12/17.
//  Copyright (c) 2015年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MovieModel : NSObject
{
    NSString *_title;
    NSString *_rating;
    NSString *_imageUrl;
    NSString *_numid;
    
    NSMutableArray *_castsMutArr;
}

@end
