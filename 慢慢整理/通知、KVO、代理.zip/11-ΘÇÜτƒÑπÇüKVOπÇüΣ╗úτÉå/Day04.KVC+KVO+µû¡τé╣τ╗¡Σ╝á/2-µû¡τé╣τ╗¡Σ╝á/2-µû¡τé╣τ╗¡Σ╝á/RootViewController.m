//
//  RootViewController.m
//  2-断点续传
//
//  Created by qianfeng on 15/10/19.
//  Copyright (c) 2015年 qianfeng. All rights reserved.
//

#import "RootViewController.h"

@interface RootViewController ()
<NSURLConnectionDataDelegate>
@property (weak, nonatomic) IBOutlet UIButton *startBtn;
@property (weak, nonatomic) IBOutlet UIButton *stopBtn;
@property (weak, nonatomic) IBOutlet UILabel *progressLabel;
@property (weak, nonatomic) IBOutlet UIProgressView *progressView;

//创建的文件的路径
@property (nonatomic, strong) NSString *tmpFilePath;
//文件的大小
@property (nonatomic, assign) long long tmpFileSize;
//下载的文件的总大小
@property (nonatomic, assign) long long fullSize;
//当前已经下载的大小
@property (nonatomic, assign) long long currentSize;
@property (nonatomic, strong) NSFileHandle *fileHander;
@property (nonatomic, strong) NSURLConnection *connection;

@end

#define MAPUrlStr @"http://map.onegreen.net/中国政区2500.jpg"
#define MP3UrlStr @"http://sc1.111ttt.com:8282/2014/1/12/09/5091057146.mp3?tflag=1444600998&pin=b3915be1dfcb8a4ffe6ce07cc68098d"
#define QQUrlStr @"http://www.baidu.com/link?url=fQBBzV2jSQiLyuP8vlp6UTkumflwNpO_fH5cKoz9fA02CU2BtFbCqSaQ3AQKTgRMmEDOVik0snwh_JsT5MB15aUBhhy7TufK21AwEgiuEmO"

@implementation RootViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //改变进度
    NSNumber *fullSizeNum = [[NSUserDefaults standardUserDefaults] objectForKey:@"fullSize"];
    self.fullSize = [fullSizeNum longLongValue];
    
    self.progressLabel.text = [NSString stringWithFormat:@"%.2f%%", self.tmpFileSize*1.0f/self.fullSize * 100];
    
}

- (IBAction)startBtnClick:(UIButton *)sender {
    
    self.startBtn.enabled = NO;
    
    
    //如果网址里面有中文， 需要进行转吗
    //NSString *urlStr = [MAPUrlStr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    NSURL *url = [NSURL URLWithString:QQUrlStr];
    
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    
    // 读文件
    NSFileManager *manager = [NSFileManager defaultManager];
    //----－－－－－如何实现断点续传----------------
    //判断文件存不存在
    if ([manager fileExistsAtPath:self.tmpFilePath]) {
        NSString *bytesStr = [NSString stringWithFormat:@"bytes=%lld-", self.tmpFileSize];
        
        
        
        //如果文件存在， 在请求头里面设定数据的请求范围
        //如果文件大小是200b，那么就从200b字节往后面请求
        [request addValue:bytesStr forHTTPHeaderField:@"RANGE"];
    }
    //---------------------------------------
    
    self.connection = [NSURLConnection connectionWithRequest:request delegate:self];
    
}

- (IBAction)stopBtnClick:(UIButton *)sender {
    
    // 断开连接
    [self.connection cancel];
    // 使能开始按钮
    self.startBtn.enabled = YES;
    
}



#pragma mark - NSURLConnectionDataDelegate
- (void)connection:(NSURLConnection *)connection didReceiveResponse:(NSURLResponse *)response
{
    //NSLog(@"-respose = %@", response);
    NSHTTPURLResponse *httpResponse = (NSHTTPURLResponse *)response;
    NSDictionary *headInfo = [httpResponse allHeaderFields];
    
    long long contentLength = [headInfo[@"Content-Length"]  integerValue];
    
    
    
    NSFileManager *manager = [NSFileManager defaultManager];
    //如果文件不存在， 先要创建一个文件
    if (![manager fileExistsAtPath:self.tmpFilePath]) {
        [manager createFileAtPath:self.tmpFilePath contents:nil attributes:nil];

        //不存在文件的情况
        self.fullSize = contentLength;
        self.currentSize = 0;
    } else {
        //存在文件的情况
        self.fullSize = contentLength + self.tmpFileSize;
        self.currentSize = self.tmpFileSize;
    }
    
    
    //实例化fileHander
    if (self.fileHander == nil) {
        self.fileHander = [NSFileHandle fileHandleForUpdatingAtPath:self.tmpFilePath];
    }
    
    //将文件指针， 偏移到文件的末尾
    [self.fileHander seekToEndOfFile];
    
    
    // 保存fullSize
    
    [[NSUserDefaults standardUserDefaults] setObject:@(self.fullSize) forKey:@"fullSize"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
}

- (void)connection:(NSURLConnection *)connection didReceiveData:(NSData *)data
{
    //改变当前下载的数据大小
    self.currentSize += data.length;
    
    //接收到数据， 写文件
    [self.fileHander writeData:data];
    
    
    long long currentLength = self.currentSize;
    
    float p = 0;
    if (self.fullSize) {
        p = (float)currentLength / self.fullSize;
    }
    
    self.progressLabel.text = [NSString stringWithFormat:@"%.2f%%", p * 100];
    self.progressView.progress = p;
}

- (void)connectionDidFinishLoading:(NSURLConnection *)connection
{
    NSLog(@"下载完成");

    self.fileHander = nil;
    self.startBtn.enabled = YES;
    
    NSString *toPath = @"/Users/qianfeng/Desktop/qq.dmg";
    NSFileManager *manager = [NSFileManager defaultManager];

    [manager moveItemAtPath:self.tmpFilePath toPath:toPath error:nil];
}


- (NSString *)tmpFilePath
{
    //Documents: 长久保存，如果iClod打开，同步，恢复手机的时候可以恢复的数据
    //Cache:     长久保存，不能恢复
    //tmp:       临时文件，app重启的时候，删除
    
    NSString *cachePath = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES)[0];
    
    // 文件的保存路径
    NSString *filePath = [cachePath stringByAppendingPathComponent:@"tmpFile"];
    
    //NSLog(@"filePath = %@", filePath);
    return filePath;
}

//返回文件大小
- (long long)tmpFileSize
{
    NSFileManager *manager = [NSFileManager defaultManager];
    
    //如果文件存在， 返回文件大小
    if ([manager fileExistsAtPath:self.tmpFilePath]) {
        NSDictionary *fileAttDic =
        [manager attributesOfItemAtPath:self.tmpFilePath error:nil];

        NSLog(@"--fileSize = %lld", [fileAttDic fileSize]);
        //fileAttDic[@"fileSize"];
        return [fileAttDic fileSize];
    }
    
    return 0;
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
