//
//  ViewController.m
//  4-KVO(键值观察者)
//
//  Created by qianfeng on 15/12/17.
//  Copyright (c) 2015年 qianfeng. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet UILabel *value1Label;

@property (weak, nonatomic) IBOutlet UILabel *value2Label;


@end

@implementation ViewController
- (void)dealloc
{
    //删除观察者
    [_value1Label removeObserver:self forKeyPath:@"text"];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    //KVO（key-value-observer） 任何对象都可以被观察， 任何对象也可以
    //作为观察者
    //第一个参数： 设置观察者
    //第二个参数： 被观察者的属性
    //第三个参数： 设置观察的属性的变化的值(旧值 | 新值)
    //第四个参数： 额外传送的信息， void *
    [_value1Label addObserver:self forKeyPath:@"text" options:NSKeyValueObservingOptionNew | NSKeyValueObservingOptionOld context:"textInfo"];

}

//当被观察的属性， 发生变化的时候， 被观察者会发送一些信息给回调函数
//第一个参数：keyPath
//第二个参数：被观察的对象
//第三个参数：监测的属性的值的变化
//第四个参数：额外信息
- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    NSLog(@"keyPath = %@, obj = %@, change = %@, %s", keyPath, object, change, context);
    
    
    self.value2Label.text = self.value1Label.text;
}


- (IBAction)buttonClicked:(UIButton *)sender {
    
    self.value1Label.text = [NSString stringWithFormat:@"%d", arc4random() % 10000];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end









