//
//  ViewController.m
//  5-KVO+通知中心
//
//  Created by qianfeng on 15/12/17.
//  Copyright (c) 2015年 qianfeng. All rights reserved.
//

#import "ViewController.h"
#import "LoginManager.h"

@interface ViewController ()
@property (nonatomic, strong) LoginManager *loginManager;

@property (nonatomic, strong) UILabel *titleLabel;
@end

@implementation ViewController
- (void)dealloc
{
    [self.loginManager removeObserver:self forKeyPath:@"loginStatus" context:nil];
}


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    self.loginManager = [[LoginManager alloc] init];
    
#if 0
    
    //给self.loginManager添加一个观察者
    [self.loginManager addObserver:self forKeyPath:@"loginStatus" options:NSKeyValueObservingOptionNew context:nil];
    
#else
    
    //添加监听事件
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(statusChange:) name:@"NotifactionLoginStatus" object:self.loginManager];
    
    
#endif
    

    
    _titleLabel = [[UILabel alloc] init];
    _titleLabel.frame = CGRectMake(0, 0, 80, 30);
    _titleLabel.backgroundColor = [UIColor greenColor];
    _titleLabel.textAlignment = NSTextAlignmentCenter;
    self.navigationItem.titleView = _titleLabel;
}

//通知通知的回调函数
- (void)statusChange:(NSNotification *)notifaction
{
    NSLog(@"notifaction = %@", notifaction);
    
    BOOL ret = [notifaction.userInfo[@"status"] boolValue];
    
    if (ret == YES) {
        _titleLabel.text = @"登陆成功";
    } else {
        _titleLabel.text = @"登陆失败";
    }
}



- (IBAction)btnClicked:(UIButton *)sender {
    //登陆
    [self.loginManager login];
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    NSLog(@"change = %@", change);
    
    if ([change[@"new"] integerValue] == YES) {

        _titleLabel.text = @"登陆成功";
    } else {
        _titleLabel.text = @"登陆失败";
    }
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end






