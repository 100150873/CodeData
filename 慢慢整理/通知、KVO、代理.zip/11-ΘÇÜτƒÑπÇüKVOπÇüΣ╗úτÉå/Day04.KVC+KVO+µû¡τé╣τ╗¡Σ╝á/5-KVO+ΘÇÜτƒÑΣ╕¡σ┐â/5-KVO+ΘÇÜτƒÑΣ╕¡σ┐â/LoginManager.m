//
//  LoginManager.m
//  5-KVO+通知中心
//
//  Created by qianfeng on 15/12/17.
//  Copyright (c) 2015年 qianfeng. All rights reserved.
//

#import "LoginManager.h"

@implementation LoginManager
- (void)login
{
    
    NSURL *url = [NSURL URLWithString:@"http://10.0.8.8/sns/my/login.php?username=szios15310010&password=123456"];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
       
        if (connectionError == nil) {
            NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            if ([dic[@"code"] isEqualToString:@"login_success"]) {
                self.loginStatus = YES;
            } else {
                self.loginStatus = NO;
            }
            
        } else {
            self.loginStatus = NO;
        }
        
    }];
    
}



- (void)setLoginStatus:(BOOL)loginStatus
{
    if (_loginStatus != loginStatus) {
        _loginStatus = loginStatus;
        
        /*
         - (void)postNotification:(NSNotification *)notification;
         - (void)postNotificationName:(NSString *)aName object:(id)anObject;
         - (void)postNotificationName:(NSString *)aName object:(id)anObject userInfo:(NSDictionary *)aUserInfo;
         */

        
        //NSNotification: 消息的对象
        NSNotification *notifacation = [NSNotification notificationWithName:@"NotifactionLoginStatus" object:self userInfo:@{@"status":@(self.loginStatus),@"打招呼":@"helloworld"}];
        
        //通过通知中心， 来发送消息
        [[NSNotificationCenter defaultCenter] postNotification:notifacation];
        
    }
}



@end












