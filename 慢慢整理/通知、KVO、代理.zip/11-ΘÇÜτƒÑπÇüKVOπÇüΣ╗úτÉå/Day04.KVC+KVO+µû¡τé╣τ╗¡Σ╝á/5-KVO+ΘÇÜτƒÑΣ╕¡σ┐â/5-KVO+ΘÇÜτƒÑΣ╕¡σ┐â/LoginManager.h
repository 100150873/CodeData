//
//  LoginManager.h
//  5-KVO+通知中心
//
//  Created by qianfeng on 15/12/17.
//  Copyright (c) 2015年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LoginManager : NSObject

@property (nonatomic, assign) BOOL loginStatus;

- (void)login;

@end
