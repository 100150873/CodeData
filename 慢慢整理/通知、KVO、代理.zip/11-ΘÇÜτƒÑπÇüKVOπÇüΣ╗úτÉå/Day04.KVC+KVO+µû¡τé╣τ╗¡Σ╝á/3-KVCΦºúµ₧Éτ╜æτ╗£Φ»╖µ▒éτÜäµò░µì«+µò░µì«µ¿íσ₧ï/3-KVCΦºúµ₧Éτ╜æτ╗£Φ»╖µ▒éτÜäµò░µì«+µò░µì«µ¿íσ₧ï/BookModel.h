//
//  BookModel.h
//  3-KVC解析网络请求的数据+数据模型
//
//  Created by qianfeng on 15/12/17.
//  Copyright (c) 2015年 qianfeng. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BookModel : NSObject
@property (nonatomic, copy) NSString *title;
@property (nonatomic, copy) NSString *imageUrl;
@property (nonatomic, copy) NSString *numID;
@property (nonatomic, strong) NSArray *author;
@property (nonatomic, copy) NSString *summary;
@property (nonatomic, strong) NSMutableArray *tagsMutArray;
@end
