//
//  TagModel.m
//  3-KVC解析网络请求的数据+数据模型
//
//  Created by qianfeng on 15/12/17.
//  Copyright (c) 2015年 qianfeng. All rights reserved.
//

#import "TagModel.h"

@implementation TagModel
- (NSString *)description
{
    return [NSString stringWithFormat:@"%@, %@, %@", _count, _name, _title];
}

- (void)setValue:(id)value forKey:(NSString *)key
{
    if ([value isKindOfClass:[NSNumber class]]) {
        [super setValue:[NSString stringWithFormat:@"%@", value] forKey:key];
    } else {
        [super setValue:value forKey:key];
    }
}
@end
