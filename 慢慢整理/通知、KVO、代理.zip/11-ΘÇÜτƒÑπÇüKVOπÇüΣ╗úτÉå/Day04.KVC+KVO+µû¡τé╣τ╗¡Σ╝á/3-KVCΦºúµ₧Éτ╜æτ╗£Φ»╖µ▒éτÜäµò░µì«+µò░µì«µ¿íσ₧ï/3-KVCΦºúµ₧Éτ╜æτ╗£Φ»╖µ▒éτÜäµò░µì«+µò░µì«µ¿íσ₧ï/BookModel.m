//
//  BookModel.m
//  3-KVC解析网络请求的数据+数据模型
//
//  Created by qianfeng on 15/12/17.
//  Copyright (c) 2015年 qianfeng. All rights reserved.
//

#import "BookModel.h"
#import "TagModel.h"

@implementation BookModel


- (id)init
{
    self = [super init];
    if (self) {
         _tagsMutArray = [[NSMutableArray alloc] init];
    }
    return self;
}

- (void)setValue:(id)value forUndefinedKey:(NSString *)key
{
    if ([key isEqualToString:@"id"]) { //id
        [self setValue:[NSString stringWithFormat:@"%@", value] forKey:@"numID"];
    } else if ([key isEqualToString:@"image"]) {
        [self setValue:value forKey:@"imageUrl"];
    } else if ([key isEqualToString:@"tags"]) {
        //遍历数组
        for (NSDictionary *tagDic in value) {
            TagModel *tagModel = [[TagModel alloc] init];
            
            [tagModel setValuesForKeysWithDictionary:tagDic];
        
            
            [_tagsMutArray addObject:tagModel];
        }
    }
}



//NSNumber
- (void)setValue:(id)value forKey:(NSString *)key
{
    if ([value isKindOfClass:[NSNumber class]]) {
        [super setValue:[NSString stringWithFormat:@"%@", value] forKey:key];
    } else {
        [super setValue:value forKey:key];
    }
}




@end




