//
//  ViewController.m
//  3-KVC解析网络请求的数据+数据模型
//
//  Created by qianfeng on 15/12/17.
//  Copyright (c) 2015年 qianfeng. All rights reserved.
//

#import "ViewController.h"
#import "BookModel.h"
#import "TagModel.h"

#define urlStr @"https://api.douban.com/v2/book/1220562?apikey=0cec39ab7e45d21d26c4ad027ad17657"

@interface ViewController ()

@property (nonatomic, strong) NSMutableArray *dataSource;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.

    _dataSource = [NSMutableArray array];
    
    
    
    NSURL *url = [NSURL URLWithString:urlStr];
    
    NSURLRequest *request = [NSURLRequest requestWithURL:url];
    
    [NSURLConnection sendAsynchronousRequest:request queue:[NSOperationQueue mainQueue] completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
       
        if (connectionError == nil) {
            
            NSDictionary *jsonDic = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
            
            NSLog(@"jsonDic = %@", jsonDic);
            
            BookModel *model = [[BookModel alloc] init];
            
            [model setValuesForKeysWithDictionary:jsonDic];
            
            
            [_dataSource addObject:model];
            
            
            NSLog(@"_dataSource = %@", _dataSource);
            
            
            for (BookModel *model in _dataSource) {
                NSLog(@"title:  %@", model.title);
                NSLog(@"summary:%@", model.summary);
                NSLog(@"imagUlr:%@", model.imageUrl);
                
                //NSLog(@"tags = %@", model.tagsMutArray);
                for (TagModel *tagModel in model.tagsMutArray) {
            
                    //NSLog(@"%@, %@, %@", tagModel.count, tagModel.name, tagModel.title);
                    NSLog(@"%@", tagModel);
                }
            }
            
            
        }
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
