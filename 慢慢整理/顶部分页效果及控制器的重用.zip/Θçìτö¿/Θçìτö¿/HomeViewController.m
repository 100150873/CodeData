//
//  ViewController.m
//  重用
//
//  Created by qingyun on 16/3/30.
//  Copyright © 2016年 qingyun. All rights reserved.
//

#import "HomeViewController.h"
#import "QYSmllScroll.h"
#define ScrollViewW [UIScreen mainScreen].bounds.size.width
@interface HomeViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)NSArray *leftArr;
@property(nonatomic,strong)NSArray *midArr;
@property(nonatomic,strong)NSArray *rigthArr;
@property (nonatomic,strong)NSArray *titles;
@property (nonatomic,strong)NSArray *tabArr;
@property (nonatomic,assign)NSInteger inde;
@property (nonatomic,strong)QYSmllScroll *scroll;
//数据源存放model
@property (nonatomic,strong)NSArray *statuss;

@property(nonatomic,assign)NSInteger currentIndex;
@property (weak, nonatomic) IBOutlet UIScrollView *scrollView;
@property (weak, nonatomic) IBOutlet UITableView *left;
@property (weak, nonatomic) IBOutlet UITableView *mid;
@property (weak, nonatomic) IBOutlet UITableView *right;
@property(nonatomic)BOOL isView;
@end

@implementation HomeViewController
static NSString *identifier = @"cell";
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    self.edgesForExtendedLayout = UIRectEdgeNone;
    self.scrollView.bounces=NO;
    self.titles = @[@"国内新闻",@"旅游新闻",@"科技新闻",@"体育新闻",@"奇闻轶事",@"hhhhhh"];
    _tabArr=@[@[@"1",@"1",@"1"],@[@"2",@"2",@"2"],@[@"3",@"3",@"3"],@[@"4",@"4",@"4"],@[@"5",@"5",@"5"],@[@"6",@"6",@"6"]];
    _left.delegate=self;
    _left.dataSource=self;
    _mid.delegate=self;
    _mid.dataSource=self;
    _right.delegate=self;
    _right.dataSource=self;
    _scrollView.delegate=self;
    //注册单元格
    [_left registerClass:[UITableViewCell class] forCellReuseIdentifier:identifier];
    [_mid registerClass:[UITableViewCell class] forCellReuseIdentifier:identifier];
    [_right registerClass:[UITableViewCell class] forCellReuseIdentifier:identifier];
      _scrollView.contentOffset = CGPointMake(0, 0);
    [self addSmllScroll];
    [self changeTableViewAndLoadData];
    
//    [self gestures];
}
-(void)addSmllScroll{
    _scroll = [[QYSmllScroll alloc]initWithSmllScroll:_titles];
    _scroll.bounces = NO;
    __weak HomeViewController *WeakSelf=self;
    void(^changeValue)(NSInteger)=^(NSInteger indexs){
        _currentIndex=indexs;
        [WeakSelf changeTableViewAndLoadData];
    };
    _scroll.changeIndexValue=changeValue;
    
    [self.view addSubview:_scroll];
}
//确保索引可用
-(NSInteger)indexForEnable:(NSInteger)index{
    if (index < 0 || index == 0) {
        return _currentIndex=0;
    }else if (index > self.tabArr.count - 1 || index == self.tabArr.count - 1){
        return _currentIndex = self.tabArr.count-1;
    }else{
        return _currentIndex==index;
    }
}
#pragma mark -UIScrollViewDelegate
//滚动结束
-(void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    if (scrollView != self.scrollView) {
        return;
    }
    //tableView继承scrollView，如果没有上面的判断下拉tableView的时候默认scrollView.contentOffset.x == 0也就是认为向右滑动
    if (scrollView.contentOffset.x == 0) {//右滑（看上一张）
        _currentIndex--;
    }
    if (scrollView.contentOffset.x == ScrollViewW * 2){//左滑（看下一张）
        _currentIndex++;
    }
    //在最左边往左滑看下一张
    if (_currentIndex == 0 && scrollView.contentOffset.x == ScrollViewW){
        _currentIndex++;
    }
    //在最右边往右滑看上一张
    if(_currentIndex == self.tabArr.count-1 && scrollView.contentOffset.x == ScrollViewW){
        _currentIndex--;
    }
    if ([scrollView isEqual:self.scrollView]) {
        if (_currentIndex<0) {
            _currentIndex=0;
        }
        if (_currentIndex>self.tabArr.count-1) {
            _currentIndex=self.tabArr.count-1;
        }
        _scroll.index = _currentIndex;
    }

    [self indexForEnable:_currentIndex];
    [self changeTableViewAndLoadData];
}
- (void)changeTableViewAndLoadData
{
    //index = 0 情况，只需要刷新左边tableView和中间tableView
    if (_currentIndex == 0) {
        _leftArr = self.tabArr[_currentIndex];
        _midArr = self.tabArr[_currentIndex +1];
        
        [_left reloadData];
        [_mid reloadData];
        
        self.scrollView.contentOffset = CGPointMake(0, 0);
        
        //index 是为最后的下标时，刷新右边tableView 和 中间 tableView
    }else if(_currentIndex == _tabArr.count - 1){
        _rigthArr = self.tabArr[_currentIndex];
        _midArr = self.tabArr[_currentIndex - 1];
        [_right reloadData];
        [_mid reloadData];
        
        self.scrollView.contentOffset = CGPointMake(ScrollViewW*2, 0);
        //除了上边两种情况，三个tableView 都要刷新，为了左右移动时都能够显示数据
    }else{
        _rigthArr = self.tabArr[_currentIndex+1];
        _midArr = self.tabArr[_currentIndex];
        _leftArr = self.tabArr[_currentIndex - 1];
        
        [_right reloadData];
        [_mid reloadData];
        [_left reloadData];
        
        self.scrollView.contentOffset = CGPointMake(ScrollViewW, 0);
    }
}

#pragma mark - tableView
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return 3;
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier forIndexPath:indexPath];
    if (tableView==_left) {
        cell.textLabel.text=self.leftArr[indexPath.row];
    }
    if (tableView==_mid) {
        cell.textLabel.text=self.midArr[indexPath.row];
    }
    if (tableView==_right) {
        cell.textLabel.text=self.rigthArr[indexPath.row];
    }
    return cell;
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
