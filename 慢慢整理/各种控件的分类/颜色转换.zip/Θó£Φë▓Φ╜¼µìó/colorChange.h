//
//  colorChange.h
//  MangoCityTravel
//
//  Created by mangocity on 5/9/14.
//  Copyright (c) 2014 mangocity. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface colorChange : NSObject
+(UIColor *) colorWithHexString: (NSString *)color;
@end
