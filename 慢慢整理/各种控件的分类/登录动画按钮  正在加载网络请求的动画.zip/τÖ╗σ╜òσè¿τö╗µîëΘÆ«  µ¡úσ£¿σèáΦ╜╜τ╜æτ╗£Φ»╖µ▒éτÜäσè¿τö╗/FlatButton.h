//
//  FlatButton.h
//  Popping
//
//  Created by André Schneider on 12.05.14.
//  Copyright (c) 2014 André Schneider. All rights reserved.
//使用前应该在pods里面倒入  ‘pop’库

#import <UIKit/UIKit.h>

@interface FlatButton : UIButton

+ (instancetype)button;

@end
