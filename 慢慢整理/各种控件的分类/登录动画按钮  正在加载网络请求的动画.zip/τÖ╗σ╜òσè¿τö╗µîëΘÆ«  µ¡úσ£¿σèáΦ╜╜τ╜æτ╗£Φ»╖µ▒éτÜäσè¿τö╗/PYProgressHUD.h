//
//  PYProgressHUD.h
//  RAC+MVVMTest
//
//  Created by ZpyZp on 16/1/19.
//  Copyright © 2016年 zpy. All rights reserved.
// 使用之前应该在pods里面倒入 ‘MBProgressHUD’

#import <MBProgressHUD/MBProgressHUD.h>

@interface PYProgressHUD : MBProgressHUD

+(void)showMessage:(NSString *)message;

+(void)hideHud;
@end
