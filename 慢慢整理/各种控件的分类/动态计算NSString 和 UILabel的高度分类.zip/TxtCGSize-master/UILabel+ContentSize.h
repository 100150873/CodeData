//
//  UILabel+ContentSize.h
//  仿朋友圈
//
//  Created by owen on 2017/2/21.
//  Copyright © 2017年 imac. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (ContentSize)

/**
 UILable高度计算
 */
- (CGSize)contentSize:(NSString*)content ;
@end
