
    
    version.itemOpertion = ^{
        XMGBlurView *blurView = [[XMGBlurView alloc] initWithFrame:XMGScreenBounds];
        
        [XMGKeyWindow addSubview:blurView];
        
        [MBProgressHUD showSuccess:@"当前木有最新的版本"];
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [blurView removeFromSuperview];
        });
    
    };
    
