//
//  RedView.m
//  07-自定义对象归档
//
//  Created by xiaomage on 15/6/13.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "RedView.h"

@implementation RedView

// 解析文件都会调用这个方法

- (id)initWithCoder:(NSCoder *)aDecoder
{
    
    // 只要父类遵守了NSCoding,就调用initWithCoder
    // 先初始化父类
    if (self = [super initWithCoder:aDecoder]) {
        NSLog(@"%s",__func__);
    }
    
    return self;
}


// 通过代码初始化的时候，调用init方法，底层就会调用initWithFrame
- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        NSLog(@"%s",__func__);
    }
    return self;
}
@end
