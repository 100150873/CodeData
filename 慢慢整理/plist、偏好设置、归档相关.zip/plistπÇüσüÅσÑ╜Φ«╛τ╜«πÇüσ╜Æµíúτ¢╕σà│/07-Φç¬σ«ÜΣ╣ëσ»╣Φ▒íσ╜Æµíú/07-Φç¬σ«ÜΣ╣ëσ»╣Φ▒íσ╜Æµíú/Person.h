//
//  Person.h
//  07-自定义对象归档
//
//  Created by xiaomage on 15/6/13.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import <Foundation/Foundation.h>

// 如果一个自定义对象想要归档，必须遵守NSCoding协议，实现协议方法。
@interface Person : NSObject<NSCoding>
@property (nonatomic, assign) int age;
@property (nonatomic, strong) NSString* name;
@end
