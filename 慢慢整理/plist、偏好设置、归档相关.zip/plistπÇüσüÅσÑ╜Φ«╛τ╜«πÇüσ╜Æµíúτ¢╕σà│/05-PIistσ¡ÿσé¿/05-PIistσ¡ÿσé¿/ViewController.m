//
//  ViewController.m
//  05-PIist存储
//
//  Created by xiaomage on 15/6/13.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "ViewController.h"
#import "Person.h"

@interface ViewController ()

@end

@implementation ViewController
// 点击存储的时候调用
- (IBAction)save:(id)sender {
    Person *p = [[Person alloc] init];
    // Plist注意：不能存储自定义对象
    // Plist：数组和字典,
    // 如何判断一个对象能不能使用Plist，就看下有没有writeToFile
    NSArray *arr = @[@"123",@1,p];

    
    // 获取应用的文件夹（应用沙盒）
//    NSString *homePath = NSHomeDirectory();
    
    // 获取temp
//    NSTemporaryDirectory();
    
    // 获取Cache文件路径
    // NSSearchPathDirectory:搜索的目录
    // NSSearchPathDomainMask：搜索范围 NSUserDomainMask:表示在用户的手机上查找
    // expandTilde 是否展开全路径，如果没有展开，应用的沙盒路径就是~
    // 存储一定要要展开路径
    NSString *cachePaht = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES)[0];
    
    
    // 拼接文件名
    NSString *filePath = [cachePaht stringByAppendingPathComponent:@"personArr.plist"];
    
    
    
    NSLog(@"%@",cachePaht);
    
    
    // File:文件的全路径
    [arr writeToFile:filePath atomically:YES];
    
}

- (IBAction)read:(id)sender {
    
    NSString *cachePaht = NSSearchPathForDirectoriesInDomains(NSCachesDirectory, NSUserDomainMask, YES)[0];
    
    
    // 拼接文件名
    NSString *filePath = [cachePaht stringByAppendingPathComponent:@"arr.plist"];
    
   NSArray *arr = [NSArray arrayWithContentsOfFile:filePath];
    
    NSLog(@"%@",arr);
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
