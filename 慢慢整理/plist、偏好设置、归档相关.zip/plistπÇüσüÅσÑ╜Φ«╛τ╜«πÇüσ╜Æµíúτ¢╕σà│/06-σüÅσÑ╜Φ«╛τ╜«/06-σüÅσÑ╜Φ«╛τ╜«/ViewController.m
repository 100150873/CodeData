//
//  ViewController.m
//  06-偏好设置
//
//  Created by xiaomage on 15/6/13.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

// 偏好设置存储:
// 好处：1.不需要关心文件名
// 2.快速做键值对存储

// 底层：就是封装了一个字典
// account:xmg pwd:123 rmbPwd:YES
- (IBAction)save:(id)sender {
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    
    [userDefaults setObject:@"xmg" forKey:@"account"];
    [userDefaults setObject:@"123" forKey:@"pwd"];
    [userDefaults setBool:YES forKey:@"rmbPwd"];
    // 在iOS7之前，默认不会马上把跟硬盘同步
    // 同步
    [userDefaults synchronize];
    
    
    
}
- (IBAction)read:(id)sender {
   NSString *pwd = [[NSUserDefaults standardUserDefaults] objectForKey:@"pwd"];
    
    NSLog(@"%@",pwd);
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
