//
//  AppDelegate.h
//  06-偏好设置
//
//  Created by xiaomage on 15/6/13.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

