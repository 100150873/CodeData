//
//  main.m
//  01-NSFileManager
//
//  Created by MLJ on 14-5-18.
//  Copyright (c) 2014年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{
    @autoreleasepool {
        NSFileManager *mgr = [NSFileManager defaultManager];
        
        // 创建文件夹
        // Intermediate 中间的、中间产物
        // withIntermediateDirectories : 如果是YES，代表会自动创建所有的文件夹
//        [mgr createDirectoryAtPath:@"/Users/apple/Desktop/test/abc/itcast" withIntermediateDirectories:YES attributes:nil error:nil];
        // NSData ： 存放二进制字节数据
        NSString *str = @"爆发后就开始客户机房环境快递顺丰快回家";
        // NSString --> NSData
        NSData *data = [str dataUsingEncoding:NSUTF8StringEncoding];
        [mgr createFileAtPath:@"/Users/apple/Desktop/itcast.mp3" contents:data attributes:nil];
    }
    return 0;
}

void useMgr3()
{
    NSFileManager *mgr = [NSFileManager defaultManager];
    
    // 获得当前文件夹下面有哪些内容
    //        NSArray *contents = [mgr contentsOfDirectoryAtPath:@"/Users/apple/Desktop/共享课堂/02-OC语法加强" error:nil];
    
    NSArray *subpaths = [mgr subpathsOfDirectoryAtPath:@"/Users/apple/Desktop/共享课堂/02-OC语法加强" error:nil];
    
    NSLog(@"%@", subpaths);
}

void useMgr2()
{
    NSFileManager *mgr = [NSFileManager defaultManager];
    // 获得文件、文件夹的属性
    NSDictionary *attrs = [mgr attributesOfItemAtPath:@"/Users/apple/Desktop/test.txt" error:nil];
    NSLog(@"%@", attrs[NSFileSize]);
}

void useMgr()
{
    NSFileManager *mgr = [NSFileManager defaultManager];
    //        BOOL exist = [mgr fileExistsAtPath:@"/Users/apple/Desktop/test.txt"];
    // 默认不是文件夹
    BOOL dir = NO;
    //返回两个值
    BOOL exist = [mgr fileExistsAtPath:@"/Users/apple/Desktop/flows" isDirectory:&dir];
    NSLog(@"文件是否存在：%d， 是否为文件夹：%d", exist, dir);
}
