//
//  ViewController.m
//  01-自定义控制器的切换
//
//  Created by xiaomage on 15/7/5.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

#import "ViewController.h"
#import "XMGOneViewController.h"
#import "XMGTwoViewController.h"
#import "XMGThreeViewController.h"

@interface ViewController ()
/** 正在显示的控制器 */
@property (nonatomic, weak) UIViewController *showingVc;

/** 存放所有控制器的数组 */
//@property (nonatomic, strong) NSArray *allVces;
@end

@implementation ViewController

/**
 如果2个控制器的view是父子关系(不管是直接还是间接的父子关系)，那么这2个控制器也应该为父子关系
[a.view addSubview:b.view];
[a addChildViewController:b];
或者
[a.view addSubview:otherView];
[otherView addSubbiew.b.view];
[a addChildViewController:b];
 */

- (void)viewDidLoad {
    [super viewDidLoad];
    
//    self.allVces = @[
//                     [[XMGOneViewController alloc] init],
//                     [[XMGTwoViewController alloc] init],
//                     [[XMGThreeViewController alloc] init]
//                     ];
    
//    self.childViewControllers = @[
//                                  [[XMGOneViewController alloc] init],
//                                [[XMGTwoViewController alloc] init],
//                                [[XMGThreeViewController alloc] init]
//                                  ];
    
    // 通过addChildViewController添加的控制器都会存在于childViewControllers数组中
    [self addChildViewController:[[XMGOneViewController alloc] init]];
    [self addChildViewController:[[XMGTwoViewController alloc] init]];
    [self addChildViewController:[[XMGThreeViewController alloc] init]];
    
    // 将XMGOneViewController从childViewControllers数组中移除
//    [self.childViewControllers[0] removeFromParentViewController];
}

- (IBAction)buttonClick:(UIButton *)button {
    // 移除其他控制器的view
    [self.showingVc.view removeFromSuperview];
    
    // 获得控制器的位置（索引）
    NSUInteger index = [button.superview.subviews indexOfObject:button];

    // 添加控制器的view
    self.showingVc = self.childViewControllers[index];
    self.showingVc.view.frame = CGRectMake(0, 64, self.view.frame.size.width, self.view.frame.size.height - 64);
    [self.view addSubview:self.showingVc.view];
}

/**
 * 屏幕即将旋转到某个方向时会调用这个方法
 */
- (void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration
{
    NSLog(@"%@ willRotateToInterfaceOrientation", self.class);
}
@end