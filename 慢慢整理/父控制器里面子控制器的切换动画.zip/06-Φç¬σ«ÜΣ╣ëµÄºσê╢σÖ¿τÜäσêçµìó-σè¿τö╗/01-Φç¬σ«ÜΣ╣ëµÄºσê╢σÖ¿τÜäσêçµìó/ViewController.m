//
//  ViewController.m
//  01-自定义控制器的切换
//
//  Created by xiaomage on 15/7/5.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

#import "ViewController.h"
#import "XMGOneViewController.h"
#import "XMGTwoViewController.h"
#import "XMGThreeViewController.h"

@interface ViewController ()
/** 正在显示的控制器 */
@property (nonatomic, weak) UIViewController *showingVc;
/** 用来存放子控制器的view */
@property (nonatomic, weak) UIView *contentView;
@end

@implementation ViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIView *contentView = [[UIView alloc] init];
    contentView.frame = CGRectMake(0, 64, self.view.frame.size.width, self.view.frame.size.height - 64);
    [self.view addSubview:contentView];
    self.contentView = contentView;
    
    [self addChildViewController:[[XMGOneViewController alloc] init]];
//    [self.childViewControllers[0] didMoveToParentViewController:self];
    
    [self addChildViewController:[[XMGTwoViewController alloc] init]];
    [self addChildViewController:[[XMGThreeViewController alloc] init]];
    
    // 当一个控制器从父控制器中移除时。会自动调用控制器的didMoveToParentViewController:方法，并且参数是nil
//    [self.childViewControllers[0] removeFromParentViewController];
}

- (IBAction)buttonClick:(UIButton *)button {
    // 移除其他控制器的view
    [self.showingVc.view removeFromSuperview];
    
    // 获得控制器的位置（索引）
    NSUInteger index = [button.superview.subviews indexOfObject:button];
    
    // 当前控制器的索引
    NSUInteger oldIndex = [self.childViewControllers indexOfObject:self.showingVc];

    // 添加控制器的view
    self.showingVc = self.childViewControllers[index];
    self.showingVc.view.frame = self.contentView.bounds;
    [self.contentView addSubview:self.showingVc.view];
    
    // 动画
    CATransition *animation = [CATransition animation];
    animation.type = @"cube";
    animation.subtype = index > oldIndex ? kCATransitionFromRight : kCATransitionFromLeft;
    animation.duration = 0.5;
    [self.contentView.layer addAnimation:animation forKey:nil];
}

/**
 * 屏幕即将旋转到某个方向时会调用这个方法
 */
- (void)willRotateToInterfaceOrientation:(UIInterfaceOrientation)toInterfaceOrientation duration:(NSTimeInterval)duration
{
    NSLog(@"%@ willRotateToInterfaceOrientation", self.class);
}
@end