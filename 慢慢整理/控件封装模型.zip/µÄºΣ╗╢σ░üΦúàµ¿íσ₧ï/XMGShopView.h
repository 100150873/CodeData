//
//  XMGShopView.h
//  03-综合使用
//
//  Created by xiaomage on 15/5/26.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

#import <UIKit/UIKit.h>

@class XMGShop;

@interface XMGShopView : UIView
/** 商品模型 */
@property (nonatomic, strong) XMGShop *shop;

+ (instancetype)shopView;
@end
