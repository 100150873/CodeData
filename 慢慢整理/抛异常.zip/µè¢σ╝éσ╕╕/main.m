//
//  main.m
//  02-了解-网页开发
//
//  Created by xiaomage on 15/7/16.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
//    @try {
        @autoreleasepool {
            return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
        }
//    } @catch (NSException *exception) {
    调用栈  即那个方法调用了这个方法  把错误原因在这里记录在沙盒里面  下次用户打开APP是上传给公司服务器错误原因
//        NSLog(@"main------%@", [exception callStackSymbols]);
//    }
}
