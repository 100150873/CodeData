//
//  main.m
//  15-copy
//
//  Created by xiaomage on 15/7/5.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "XMGPerson.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        XMGPerson *p = [[XMGPerson alloc] init];
        p.age = 10;
        p.money = 100.6;
        
//        XMGPerson *p2 = [p copy];
    }
    return 0;
}

void array()
{
    NSArray *array = @[@"1", @"2"];
    
    NSArray *array1 = [array copy];
    
    NSMutableArray *array2 = [array mutableCopy];
    [array2 addObject:@"3"];
    
    NSLog(@"%@ %@", array, array2);
}

void string()
{
    NSString *string = @"12";
    
    NSString *str1 = [string copy]; // 没有产生新对象
    NSMutableString *str2 = [string mutableCopy]; // 产生新对象
    
    NSLog(@"%p %p %p", string, [string copy], [string mutableCopy]);
}

void mutableString()
{
    NSMutableString *string = [NSMutableString string];
    [string appendString:@"1"];
    [string appendString:@"2"];
    
    NSString *str1 = [string copy]; // 产生新对象
    NSMutableString *str2 = [string mutableCopy]; // 产生新对象
    //
    //        [str2 appendString:@"123"];
    
    [string appendString:@"345"];
    
    NSLog(@"%@ - %@", string, str1);
    
    //        NSLog(@"%p %p %p", string, [string copy], [string mutableCopy]);
    //        NSLog(@"%@ %@ %@", string, [string copy], [string mutableCopy]);
}
