//
//  XMGAddViewController.m
//  小码哥通讯录
//
//  Created by xiaomage on 15/6/12.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "XMGAddViewController.h"
#import "XMGContact.h"


@interface XMGAddViewController ()
@property (weak, nonatomic) IBOutlet UITextField *nameField;
@property (weak, nonatomic) IBOutlet UITextField *phoneField;
@property (weak, nonatomic) IBOutlet UIButton *addBtn;

@end

@implementation XMGAddViewController

// 点击添加的时候调用
- (IBAction)add:(id)sender {
    // 0.把文本框的值包装成联系人模型
    XMGContact *c = [XMGContact contactWithName:_nameField.text phone:_phoneField.text];
   
    // 1.把联系人添加到联系人控制器的数组，让联系人控制器刷新表格
    if (_block) {
        _block(c);
    }
    
    // 2.回到联系人控制器
    [self.navigationController popViewControllerAnimated:YES];
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    // 给文s    [_nameField addTarget:self action:@selector(textChange) forControlEvents:UIControlEventEditingChanged];
    [_phoneField addTarget:self action:@selector(textChange) forControlEvents:UIControlEventEditingChanged];
    
}

- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    // 主动弹出姓名文本框
    [_nameField becomeFirstResponder];
}

// 任一一个文本框的内容改变都会调用
- (void)textChange
{
    _addBtn.enabled = _nameField.text.length && _phoneField.text.length;
    
}

@end
