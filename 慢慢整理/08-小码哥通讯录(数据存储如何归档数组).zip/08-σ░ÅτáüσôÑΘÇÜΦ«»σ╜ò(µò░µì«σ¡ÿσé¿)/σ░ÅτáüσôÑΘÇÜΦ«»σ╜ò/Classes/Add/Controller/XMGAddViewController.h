//
//  XMGAddViewController.h
//  小码哥通讯录
//
//  Created by xiaomage on 15/6/12.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import <UIKit/UIKit.h>

@class XMGContactViewController,XMGContact;

// 利用block传值，需要把什么传递出去，就作为block参数,通常不需要返回值

typedef void(^XMGAddViewControllerBlock)(XMGContact *contact);


@interface XMGAddViewController : UIViewController


@property (nonatomic, strong) XMGAddViewControllerBlock block;




@end
