//
//  XMGEditViewController.h
//  小码哥通讯录
//
//  Created by xiaomage on 15/6/13.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import <UIKit/UIKit.h>

@class XMGContact;

// 定义block类型别名
typedef void(^XMGEditViewControllerBlock)();

@interface XMGEditViewController : UIViewController

@property (nonatomic, strong) XMGContact *contact;

@property (nonatomic, strong) XMGEditViewControllerBlock block;

@end
