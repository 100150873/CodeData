//
//  ViewController.swift
//  选项卡的封装
//
//  Created by Apple on 2017/3/31.
//  Copyright © 2017年 swift小练习. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    lazy var tabTitleView:TabTitleView = {
         let titles = ["萝莉直播", "宝石直播", "设备器材", "排练直播","排练直播","排练直播","排练直播"]
        let tabTitleViewTemp = TabTitleView(frame: CGRect(x: 0, y: 64, width: UIScreen.main.bounds.width, height: 60), titles: titles)
        tabTitleViewTemp.backgroundColor = UIColor.blue
        return tabTitleViewTemp
    }()
    
    override func viewDidLoad() {
        super.viewDidLoad()
     loadUI()
    }
}

extension ViewController{
    func loadUI()  {
        //关闭内边距
        automaticallyAdjustsScrollViewInsets = false
        view.addSubview(tabTitleView)
    }

}
