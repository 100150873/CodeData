//
//  TabTitleView.swift
//  选项卡的封装
//
//  Created by Apple on 2017/3/31.
//  Copyright © 2017年 swift小练习. All rights reserved.
//

import UIKit

class TabTitleView: UIView {
    

    var titles : [String]?//储存属性  用来保存数组数据
    //自定义构造函数
    init(frame:CGRect,titles:[String]){
        self.titles = titles
        super.init(frame: frame)
        loadUI()
    
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    lazy var scrollView:UIScrollView = {
        let tempScrollView = UIScrollView()
        tempScrollView.showsVerticalScrollIndicator = false
        tempScrollView.showsHorizontalScrollIndicator = false
        tempScrollView.isPagingEnabled = true
        tempScrollView.scrollsToTop = false
        tempScrollView.bounces = false
        return tempScrollView
    }()
}

extension TabTitleView{

    func loadUI() {
        addSubview(scrollView)
        scrollView.frame = bounds//scrollView的size等于self.bounds
        setupTitleLabels()
    }
    
    func setupTitleLabels() {
        for (index,title) in (titles?.enumerated())! {
            
            let label = UILabel()
            label.text = title
            label.tag = index
            label.font = UIFont.systemFont(ofSize: 15)
            label.textColor = UIColor(red: 51, green: 49, blue: 60, alpha: 1.0)
            label.textAlignment = .center
            //设置frame
            let labelW : CGFloat = bounds.size.width / 4
            let labelH : CGFloat = frame.height - 2
            let labelX : CGFloat = CGFloat(index) * labelW
            let labelY : CGFloat  = 0
            label.frame = CGRect(x: labelX, y: labelY, width: labelW, height: labelH)
             scrollView.addSubview(label)
            
            
            //设置添加按钮
            let buttonMore = UIButton()
            buttonMore.frame = CGRect(x: frame.width, y: 0, width: 40, height: 40)
            buttonMore.setBackgroundImage(UIImage(named:"subnavaddBtn"), for: .normal)
            addSubview(buttonMore)
           
        }
        scrollView.contentSize = CGSize(width: frame.width * 2, height: frame.height)
    }

}

