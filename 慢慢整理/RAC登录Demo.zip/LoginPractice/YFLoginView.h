//
//  YFLoginView.h
//  LoginPractice
//
//  Created by tsaievan on 2017/5/4.
//  Copyright © 2017年 tsaievan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFLoginView : UIView

@property (nonatomic,strong)UITextField *usernameTextField;
@property (nonatomic,strong)UITextField *passwordTextField;
@property (nonatomic,strong)UIButton *loginButton;

@end
