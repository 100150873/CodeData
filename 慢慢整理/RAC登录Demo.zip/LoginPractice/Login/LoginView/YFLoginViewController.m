//
//  YFLoginViewController.m
//  LoginPractice
//
//  Created by tsaievan on 2017/5/4.
//  Copyright © 2017年 tsaievan. All rights reserved.
//

#import "YFLoginViewController.h"
#import "YFLoginView.h"
#import "YFLoginViewModel.h"
#import <ReactiveObjC/ReactiveObjC.h>

@interface YFLoginViewController ()

@property (nonatomic,strong)YFLoginView *loginView;
@property (nonatomic,strong)YFLoginViewModel *loginViewModel;

@end

@implementation YFLoginViewController

#pragma mark - life cycle
- (void)loadView {
    self.loginView = [[YFLoginView alloc] init];
    self.view = _loginView;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self loginButtonEnable];
    [self loginButtonAction];
}

#pragma mark - events && actions

- (void)loginButtonEnable {
    RAC(self.loginViewModel, username) = _loginView.usernameTextField.rac_textSignal;
    RAC(self.loginViewModel, password) = _loginView.passwordTextField.rac_textSignal;
    RAC(self.loginView.loginButton, enabled) = _loginViewModel.loginButtonEnableSignal;
}

- (void)loginButtonAction {
    [[_loginView.loginButton rac_signalForControlEvents:UIControlEventTouchUpInside] subscribeNext:^(__kindof UIControl * _Nullable x) {
        [self.loginViewModel.loginCommad execute:nil];
    }];
}

#pragma mark - lazy initialization
- (YFLoginViewModel *)loginViewModel {
    if (!_loginViewModel) {
        _loginViewModel = [[YFLoginViewModel alloc] init];
    }
    return _loginViewModel;
}

@end
