//
//  YFFirstPageViewController.h
//  LoginPractice
//
//  Created by tsaievan on 2017/5/4.
//  Copyright © 2017年 tsaievan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YFFirstPageViewController : UIViewController

@end
