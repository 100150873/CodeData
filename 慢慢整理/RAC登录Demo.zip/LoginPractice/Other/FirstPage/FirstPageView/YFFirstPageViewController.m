//
//  YFFirstPageViewController.m
//  LoginPractice
//
//  Created by tsaievan on 2017/5/4.
//  Copyright © 2017年 tsaievan. All rights reserved.
//

#import "YFFirstPageViewController.h"

@interface YFFirstPageViewController ()

@end

@implementation YFFirstPageViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self setupUI];
}

- (void)setupUI {
    self.view.backgroundColor = [UIColor yellowColor];
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, 200, 40)];
    label.textAlignment = NSTextAlignmentCenter;
    label.center = self.view.center;
    label.text = @"欢迎来到首页";
    [self.view addSubview:label];
}


@end
