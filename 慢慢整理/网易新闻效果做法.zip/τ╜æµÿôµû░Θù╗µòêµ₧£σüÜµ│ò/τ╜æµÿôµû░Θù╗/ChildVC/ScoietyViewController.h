//
//  ScoietyViewController.h
//  网易新闻
//
//  Created by xiaomage on 16/3/8.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScoietyViewController : UIViewController

@end
