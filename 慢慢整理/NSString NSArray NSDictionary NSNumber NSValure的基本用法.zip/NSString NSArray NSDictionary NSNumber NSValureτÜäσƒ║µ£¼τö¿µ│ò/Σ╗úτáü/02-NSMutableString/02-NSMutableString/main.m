//
//  main.m
//  02-NSMutableString
//
//  Created by MLJ on 14-5-17.
//  Copyright (c) 2014年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{
    @autoreleasepool {
        // 1.将file://ios.itcast.cn/ios/images/content_25.jpg中的file替换为http
//        NSMutableString *str = [NSMutableString stringWithString:@"file://ios.itcast.cn/ios/images/content_25.jpg"];
        NSMutableString *str = [NSMutableString string];
        // 设置整个字符串的内容
        str.string = @"file://ios.itcast.cn/ios/images/content_25.jpg";
        
        // 替换
//        NSRange range = NSMakeRange(0, str.length);
        NSLog(@"%@", str);
//        [str replaceOccurrencesOfString:@"file" withString:@"http" options:0 range:range];
        
        [str replaceCharactersInRange:[str rangeOfString:@"file"] withString:@"http"];
        
        NSLog(@"%@", str);
        
        // 将字符串拼接到最后面
//        [str appendString:@"abc"];
        
        // 设置整个字符串的所有内容
//        str.string = @"def";
        
        
        // 这种方法会产生新的字符串对象
//        NSString *str = @"file://ios.itcast.cn/ios/images/content_25.jpg";
//        
//        NSString *newStr = [str stringByReplacingOccurrencesOfString:@"file" withString:@"http"];
//        
//        NSLog(@"str=%@", str);
//        NSLog(@"newStr=%@", newStr);
    }
    return 0;
}

void insertString()
{
    NSMutableString *str = [NSMutableString string];
    [str appendString:@"itcast"];
    [str insertString:@"http://" atIndex:0];
    NSLog(@"%@", str);
}

/**
 不建议采取（会产生很多临时的字符串对象）
 */
void appendString4()
{
    // 1.将10个itcast拼接起来, 中间用空格隔开
    // 目标字符串
    NSString *destStr = @"";
    
    // 拼接字符串
    for (int i = 0; i<10; i++) {
        destStr = [destStr stringByAppendingString:@" itcast"];
    }
    
    destStr = [destStr stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceCharacterSet]];
    
    NSLog(@"-%@-", destStr);
}

void appendString3()
{
    // 1.将10个itcast拼接起来, 中间用空格隔开
    NSMutableString *destStr = [NSMutableString string];
    for (int i = 0; i<10; i++) {
        [destStr appendString:@" itcast"];
    }
    
    // 2.删除最后一个空格
    [destStr deleteCharactersInRange:NSMakeRange(0, 1)];
    // [destStr deleteCharactersInRange:NSMakeRange(destStr.length - 1, 1)];
    
    NSLog(@"--%@--", destStr);
}

void deleteString()
{
    NSMutableString *str = [NSMutableString string];
    [str appendString:@"http://itcast"];
    NSLog(@"初始化：%@", str);
    
    //        [str deleteCharactersInRange:NSMakeRange(0, 7)];
    
    // 结合rangeOfString和deleteCharactersInRange方法能准确删除某个固定的字符串
    NSRange range = [str rangeOfString:@"itcast"];
    [str deleteCharactersInRange:range];
    
    NSLog(@"删除后：%@", str);
}

void appendString2()
{
    // 1.将10个itcast拼接起来, 中间用空格隔开, 最后写入文件中
    NSString *substr = @"itcast";
    
    NSMutableString *destStr = [NSMutableString string];
    for (int i = 0; i<10; i++) {
        //            if (i != 0) {
        if (i) { // 只有i不等于
            [destStr appendString:@" "];
        }
        [destStr appendString:substr];
    }
    
    [destStr writeToFile:@"/Users/apple/Desktop/dest.txt" atomically:YES encoding:NSUTF8StringEncoding error:nil];
}

void appendString()
{
    // 不可变
    NSString *str = @"Jack";
    
    // 可变
    NSMutableString *str2 = [NSMutableString string];
    
    [str2 appendString:@"Rose"];
    [str2 appendString:@" love  "];
    [str2 appendString:@"Jack."];
    
    int age = 20;
    [str2 appendFormat:@"My age is %d", age];
    
    NSLog(@"%@", str2);

}