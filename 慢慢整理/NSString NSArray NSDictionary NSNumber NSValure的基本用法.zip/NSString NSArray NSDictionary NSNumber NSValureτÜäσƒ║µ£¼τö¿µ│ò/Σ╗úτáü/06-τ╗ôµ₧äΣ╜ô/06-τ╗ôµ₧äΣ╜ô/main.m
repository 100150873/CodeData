//
//  main.m
//  06-结构体
//
//  Created by MLJ on 14-5-17.
//  Copyright (c) 2014年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{
    @autoreleasepool {
//        CGPoint p;
//        p.x = 10;
//        p.y = 10;
        
//        CGPoint p = CGPointMake(10, 10);
        
//        CGPoint p = NSMakePoint(10, 10);
        
//        CGSize s = CGSizeMake(100, 100);
//        CGSize s = NSMakeSize(100, 100);
        
//        CGRectMake(<#CGFloat x#>, <#CGFloat y#>, <#CGFloat width#>, <#CGFloat height#>)
    }
    return 0;
}

