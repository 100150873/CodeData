//
//  main.m
//  05-NSDictionary
//
//  Created by MLJ on 14-5-17.
//  Copyright (c) 2014年 itcast. All rights reserved.
//
/**
 1.集合
 1> 能存放多个对象的容器
 2> 常见的集合：NSArray、NSMutableArray、NSDictionary、NSMutableDictionary
 
 2.NSArray和NSDictionary的区别
 1> NSArray是有序的，NSDictionary是无序的
 2> NSArray是通过下标访问元素，NSDictionary是通过key访问元素
 
 3.NSArray的用法
 1> 创建
 @[@"Jack", @"Rose"]  (返回是不可变数组)
 
 2> 访问
 id d = array[1];
 
 3> 赋值
 array[1] = @"jack";
 
 4.NSDictionary的用法
 1> 创建
 @{ @"name" : @"Jack", @"phone" : @"10086" }  (返回是不可变字典)
 
 2> 访问
 id d = dict[@"name"];
 
 3> 赋值
 dict[@"name"] = @"jack";
 */

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{
    @autoreleasepool {
        NSMutableDictionary *dict = [NSMutableDictionary dictionary];
        
        dict.dictionary = @{
                            @"name" : @"张三",
                            @"nickname" : @"张三",
                            @"phone" : @"10010",
                            @"address" : @"中国"};
        
//        [dict setObject:@"Jack" forKey:@"name"];
//        [dict setObject:@"Rose" forKey:@"name"];
//        [dict setObject:@"10086" forKey:@"phone"];
//        dict[@"name"] = @"Jack";
//        dict[@"name"] = @"Jim";
//        dict[@"phone"] = @"10086";
        
//        [dict removeAllObjects];
        // 通过key删除键值对
        [dict removeObjectForKey:@"phone"];
        
        NSLog(@"%@", dict);
    }
    return 0;
}

void useDict4()
{
    // 字典的key不能一样
    // 字典的value可以一样
    NSDictionary *dict = @{
                           @"name" : @"张三",
                           @"nickname" : @"张三",
                           @"phone" : @"10010",
                           @"address" : @"中国"};
    
    NSLog(@"%@", dict[@"name"]);
}

void useDict3()
{
    NSArray *array = @[
                       @{@"name" : @"张三", @"phone" : @"10010", @"address" : @"中国"},
                       @{@"name" : @"李四", @"phone" : @"10000", @"address" : @"美国"},
                       @{@"name" : @"王八", @"phone" : @"10086", @"address" : @"埃及"}
                       ];
    [array writeToFile:@"/Users/apple/Desktop/persons.plist" atomically:YES];
    
    //        NSDictionary *dict = @{
    //                               @"name" : @"张三",
    //                               @"phone" : @"10010",
    //                               @"address" : @"中国",
    //                               @"age" : @"20",
    //                               @"sex" : @"男"};
    //
    //        [dict writeToFile:@"/Users/apple/Desktop/person.plist" atomically:YES];
}

void useDict2()
{
    // 字典是无序的
    NSDictionary *dict = @{
                           @"name" : @"张三",
                           @"phone" : @"10010",
                           @"address" : @"中国",
                           @"age" : @"20",
                           @"sex" : @"男"};
    
    for (NSString *key in dict) {
        NSLog(@"%@ - %@", key, dict[key]);
    }
    
    //        [dict enumerateKeysAndObjectsUsingBlock:^(id key, id obj, BOOL *stop) {
    //            NSLog(@"%@ - %@", key, obj);
    //        }];
}

void useDict()
{
    //        NSDictionary *dict = [NSDictionary dictionaryWithObject:@"Jack" forKey:@"name"];
    
    //        id d = [dict objectForKey:@"name"];
    
    //        NSDictionary *dict = [NSDictionary dictionaryWithObjectsAndKeys:@"王八个", @"name", @"10086", @"phone", @"埃及", @"address", nil];
    //
    //        NSLog(@"%@", [dict objectForKey:@"address"]);
    
    NSDictionary *dict1 = @{@"name" : @"张三", @"phone" : @"10010", @"address" : @"中国"};
    
    NSLog(@"%zd", dict1.count);
    
    //        NSDictionary *dict2 = @{@"name" : @"李四", @"phone" : @"10000", @"address" : @"美国"};
    //        NSDictionary *dict3 = @{@"name" : @"王八", @"phone" : @"10086", @"address" : @"埃及"};
    
    //        NSArray *array = @[dict1, dict2, dict3];
    
    //        NSArray *array = @[
    //                           @{@"name" : @"张三", @"phone" : @"10010", @"address" : @"中国"},
    //                           @{@"name" : @"李四", @"phone" : @"10000", @"address" : @"美国"},
    //                           @{@"name" : @"王八", @"phone" : @"10086", @"address" : @"埃及"}
    //                           ];
    // 字典打印的特点：用大括号{}包住所有的元素
    //        NSDictionary *lisiDict = array[1];
    //        NSLog(@"%@", lisiDict[@"phone"]);
    // 键值对
    // key - 键
    // value（object） - 值
    //        NSLog(@"%@", array[0][@"address"]);
}