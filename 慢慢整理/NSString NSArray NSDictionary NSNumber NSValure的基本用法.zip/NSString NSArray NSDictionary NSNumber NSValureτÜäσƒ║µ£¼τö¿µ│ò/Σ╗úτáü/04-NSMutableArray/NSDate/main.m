//
//  main.m
//  NSDate
//
//  Created by apple on 14-5-17.
//  Copyright (c) 2014年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{

    @autoreleasepool {
        
        NSData *now = [NSData date];
        NSDateFormatter *ftm = [[NSDateFormatter alloc]init];
        
        //当前时间
        NSDate *now = [NSDate date]
        
        
        
    }
    return 0;
}

