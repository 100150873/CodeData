//
//  main.m
//  04-NSMutableArray
//
//  Created by MLJ on 14-5-17.
//  Copyright (c) 2014年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 1.创建数组
 @[ ]
 
 2.访问元素
 id d = array[0];
 
 3.替换元素
 array[0] = @"Tom";
 */

int main(int argc, const char * argv[])
{
    @autoreleasepool {
        // 错误写法：将“不可变的对象” 当做 “可变对象”来使用
        NSMutableString *str = @"Jack";
        
//        [str appendString:@" Rose"];
        
        // 错误写法
//        NSMutableArray *array = @[@"A", @"B", @"C"];
        
//        NSArray *array2 = @[@"A", @"B", @"C"];
        
//        NSMutableArray *array = [NSMutableArray arrayWithArray:@[@"A", @"B", @"C"]];
//        NSMutableArray *array = [NSMutableArray array];
//        [array addObjectsFromArray:@[@"A", @"B", @"C"]];
        
//        [array addObject:@"A"];
//        [array addObject:@"B"];
//        [array addObject:@"C"];
    }
    return 0;
}

void useArray()
{
    NSMutableArray *array = [NSMutableArray array];
    
    // 添加元素
    [array addObject:@"Jack"];
    [array addObject:@"Rose"];
    [array addObject:@"Jim"];
    
    // 替换
    //        [array replaceObjectAtIndex:1 withObject:@"Tom"];
    array[1] = @"Tom";
    
    // 将整个数组当做元素 添加到array中
    //        [array addObject:@[@"A", @"B"]];
    // 将整个数组的所有元素 添加到array中
    //        [array addObjectsFromArray:@[@"A", @"B"]];
    
    //        [array insertObject:@"Tom" atIndex:1];
    // 删除元素
    //        [array removeObject:@"Rose"];
    //        [array removeLastObject];
    //        [array removeAllObjects];
    //        [array removeObjectAtIndex:0];
    
    NSLog(@"%@", array);
}

/**
 *  
 集合
 能存放多个对象的容器
 常见的集合：NSArray、NSMutanbleArray、NSDictionary、NSMutableDictionary

 
 
 */











