//
//  main.m
//  08-NSDate
//
//  Created by MLJ on 14-5-17.
//  Copyright (c) 2014年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{
    @autoreleasepool {
        NSString *time1 = @"2014-04-08 20:50:40";
        NSString *time2 = @"2014-04-04 18:45:30";
        
        NSDateFormatter *fmt = [[NSDateFormatter alloc] init];
        fmt.dateFormat = @"yyyy-MM-dd HH:mm:ss";
        
        NSDate *date1 = [fmt dateFromString:time1];
        NSDate *date2 = [fmt dateFromString:time2];
        
        // 1.创建一个日历对象
        NSCalendar *calendar = [NSCalendar currentCalendar];
        
        // 2.比较时间的差距
        int unit = NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay
        | NSCalendarUnitHour | NSCalendarUnitMinute | NSCalendarUnitSecond;
        NSDateComponents *cmps = [calendar components:unit fromDate:date2 toDate:date1 options:0];
        
        NSLog(@"相差%ld年%ld月%ld天%ld小时%ld分钟%ld秒", cmps.year, cmps.month, cmps.day, cmps.hour, cmps.minute, cmps.second);
    }
    return 0;
}

void componentsOfDate()
{
    // 1.当前时间
    NSDate *now = [NSDate date];
    
    // 2.创建一个日历对象
    NSCalendar *calendar = [NSCalendar currentCalendar];
    
    // 3.利用日历对象 或者 时间对象 对应的 年、月、日、时分秒
    int unit = NSCalendarUnitYear | NSCalendarUnitMonth | NSCalendarUnitDay;
    NSDateComponents *cmps = [calendar components:unit fromDate:now];
    
    // 4.打印时间的要素
    NSLog(@"%ld", cmps.day);
}

void formatDate2()
{
    NSDateFormatter *fmt = [[NSDateFormatter alloc] init];
    fmt.dateFormat = @"yyyy-MM-dd HH:mm";
    
    NSDate *date = [fmt dateFromString:@"2014-09-10 16:34"];
    
    NSLog(@"%@", date);
}

void formatDate()
{
    
    // 微博\QQ\QQ空间
    
    // 18：56
    
    // 1分钟前
    
    // 昨天 17:45
    
    // 日期格式化
    NSDate *now = [NSDate date];
    
    // 创建一个格式化工具类
    NSDateFormatter *fmt = [[NSDateFormatter alloc] init];
    
    // 设置格式
    //        fmt.dateFormat = @"今天 HH:mm";
    
    // HH : 24小时制
    // hh : 12小时制
    // yyyy : 年
    // MM : 月
    // dd : 号
    // mm : 分钟
    // ss : 秒
    // Z :  时区
    fmt.dateFormat = @"yyyy年MM月dd号 hh:mm:ss Z";
    
    // 转换格式：将 NSDate 转成某种格式的 字符串
    NSString *nowStr = [fmt stringFromDate:now];
    
    NSLog(@"%@", nowStr);
}

void useDate()
{
    NSDate *now = [NSDate date];
    
    NSDate *date = [now dateByAddingTimeInterval:10];
    
    NSLog(@"now:%@", now);
    NSLog(@"date:%@", date);
}