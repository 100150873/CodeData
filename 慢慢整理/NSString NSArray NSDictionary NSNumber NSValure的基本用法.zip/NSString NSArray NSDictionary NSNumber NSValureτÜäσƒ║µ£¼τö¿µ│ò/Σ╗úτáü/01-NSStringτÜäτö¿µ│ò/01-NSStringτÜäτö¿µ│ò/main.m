//
//  main.m
//  01-NSString的用法
//
//  Created by MLJ on 14-5-17.
//  Copyright (c) 2014年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>



int main(int argc, const char * argv[])
{
    @autoreleasepool {
        
    }
    return 0;
}

void stringTrimUpper()
{
    NSString *str = @"HTTP://ios.itcast.cn/IOS/images/content_25.jpg";
    
    NSString *newStr = [str stringByTrimmingCharactersInSet:[NSCharacterSet uppercaseLetterCharacterSet]];
    NSLog(@"%@", newStr);
}

void stringTrimSpace()
{
    NSString *str = @"  http://ios.itcast.cn  ios/images/  content_25.jpg  ";
    
    // trim : 去除头尾
    // whitespaceCharacterSet : 空格
    NSCharacterSet *set = [NSCharacterSet whitespaceCharacterSet];
    NSString *newStr = [str stringByTrimmingCharactersInSet:set];
    
    NSLog(@"--%@--", str);
    NSLog(@"--%@--", newStr);
}

void string2int()
{
    NSString *str = @"108";
    NSString *str2 = @"200.5";
    // str.intValue ---> 108
    //        int sum = str.intValue + str2.intValue;
    double sum = str.intValue + str2.doubleValue;
    NSLog(@"%f", sum);
}

void replaceString2()
{
    NSString *str = @"  http:**  ios.itcast.cn  *ios*images*  content_25.jpg  ";
    
    // 1.把空格消掉
    NSString *newStrWithoutSpace = [str stringByReplacingOccurrencesOfString:@" " withString:@""];
    
    // 2.把*换成/
    NSString *destStr = [newStrWithoutSpace stringByReplacingOccurrencesOfString:@"*" withString:@"/"];
    
    NSLog(@"str = %@", str);
    NSLog(@"newStrWithoutSpace = %@", newStrWithoutSpace);
    NSLog(@"destStr = %@", destStr);
}

/**
 将http:**ios.itcast.cn*ios*images*content_25.jpg中的*替换为/
 */
void replaceString()
{
    NSString *str = @"http:**ios.itcast.cn*ios*images*content_25.jpg";
    
    // Replacing : 替换
    // Occurrences : 出现
    //  用/替换所有出现的*
    NSString *newStr = [str stringByReplacingOccurrencesOfString:@"*" withString:@"/"];
    NSLog(@"%@", newStr);
}

/**
 用3种方法将下面字符串中的中文截取出来
 <itcast>传智播客</itcast>
 */
void substring()
{
    NSString *str = @"<itt>传智</itt>";
    
    // 不建议采取
    //        NSRange range;
    //        range.location = 8;
    //        range.length = 4;
    //        NSString *substr = [str substringWithRange:range];
    
    // 1.方法1
    //        NSRange range;
    //        range.location = [str rangeOfString:@">"].location + 1;
    //        range.length = [str rangeOfString:@"</"].location - range.location;
    
    /**
     typedef struct _NSRange {
     NSUInteger location;
     NSUInteger length;
     } NSRange;
     */
    NSUInteger loc = [str rangeOfString:@">"].location + 1;
    NSUInteger len = [str rangeOfString:@"</"].location - loc;
    //        NSRange range = {loc, len};
    //        NSRange range = {.length = len, .location = loc};
    NSRange range = NSMakeRange(loc, len);
    NSString *substr = [str substringWithRange:range];
    NSLog(@"%@", substr);
    
    // 2.方法2
    // <it>传智</it>  ---> 传智</it>  --> 传智
    // <it>传智</it>  ---> <it>传智  --> 传智
    //        NSUInteger from = [str rangeOfString:@">"].location + 1;
    //        NSString *substr = [str substringFromIndex:from];
    //        // 传智</it>
    //        NSUInteger to = [substr rangeOfString:@"<"].location;
    //        NSString *destStr = [substr substringToIndex:to];
    //        NSLog(@"%@", destStr);
}