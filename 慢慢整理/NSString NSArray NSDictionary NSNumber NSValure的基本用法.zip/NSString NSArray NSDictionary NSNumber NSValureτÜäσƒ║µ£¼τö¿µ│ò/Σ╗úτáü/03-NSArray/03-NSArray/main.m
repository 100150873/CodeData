//
//  main.m
//  03-NSArray
//
//  Created by MLJ on 14-5-17.
//  Copyright (c) 2014年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Person.h"
#import "Dog.h"

int main(int argc, const char * argv[])
{
    @autoreleasepool {
        NSString *str = @"Jack-Rose*Jim-Kate";
        NSArray *array = [str componentsSeparatedByString:@"-"];
        NSLog(@"%@", array);
        
//        NSArray *array = @[@"A", @"B", @"C", @"D"];
//        NSString *str = [array componentsJoinedByString:@"-"];
//        NSLog(@"%@", str);
        
//        NSMutableString *str = [NSMutableString string];
//        
//        for (NSString *obj in array) {
//            [str appendString:@"*"];
//            [str appendString:obj];
//        }
//        
//        [str deleteCharactersInRange:NSMakeRange(0, 1)];
//        
//        NSLog(@"%@", str);
    }
    return 0;
}

void userArray3()
{
    //        NSArray *array = [NSArray arrayWithContentsOfFile:@"/Users/apple/Desktop/array.xml"];
    //        NSLog(@"%@", array);
    //        NSArray *array = @[@"Jack", @"Rose", @"Rose"];
    //        // XML
    //        [array writeToFile:@"/Users/apple/Desktop/array.xml" atomically:YES];
}

void userArray2()
{
    Dog *d1 = [[Dog alloc] init];
    d1.age = 1;
    Dog *d2 = [[Dog alloc] init];
    d2.age = 2;
    Dog *d3 = [[Dog alloc] init];
    d3.age = 3;
    Dog *d4 = [[Dog alloc] init];
    d4.age = 4;
    Dog *d5 = [[Dog alloc] init];
    d5.age = 5;
    
    NSArray *array = @[d1, d2, d3, d4, d5];
    // 一个SEL就代表一个方法
    
    // 让数组中的所有对象都执行run方法
    //        [array makeObjectsPerformSelector:@selector(eat:) withObject:@"狗肉"];
    
    //        [array makeObjectsPerformSelector:@selector(run)];
    
    //        for (int i = 0; i<array.count; i++) {
    //            Dog *dog = array[i];
    //            [dog run];
    //        }
    
    //        for (Dog *dog in array) {
    //            [dog run];
    //        }
    
    //        [array enumerateObjectsUsingBlock:^(Dog *obj, NSUInteger idx, BOOL *stop) {
    //            [obj run];
    //        }];
    
    //        [d1 run];
    //        [d2 run];
    //        [d3 run];
    //        [d4 run];
    //        [d5 run];
    
    
    
    //        NSArray *array = @[@"A" , @"B", @"C"];
    
    //        NSLog(@"%@", array[2]);
}

void useArray()
{
    NSObject *obj = [[NSObject alloc] init];
    Person *p = [[Person alloc] init];
    
    NSArray *array = [NSArray arrayWithObjects:@"A", p, @"B", @"C", @"D", obj, nil];
    //        NSLog(@"%@ %@", array.lastObject, array.firstObject);
    
    //        NSLog(@"%d", [array containsObject:@"A"]);
    
    //        id d = [array objectAtIndex:3];
    
    //        NSLog(@"%@", d);
}

void createArray()
{
    // 初始化一个数组
    //        NSArray *array = [NSArray arrayWithObject:@"Jack"];
    
    //        NSArray *array = [NSArray arrayWithObjects:@"Jack", @"Rose", @"Jim", nil];
    
    // 数组打印的特殊：用小括号()包住所有的元素
    //        NSLog(@"%@", array);
    
    NSArray *array = [NSArray array];
    
    NSLog(@"%zd", array.count);
    //        [array count];
}