//
//  Dog.m
//  03-NSArray
//
//  Created by MLJ on 14-5-17.
//  Copyright (c) 2014年 itcast. All rights reserved.
//

#import "Dog.h"

@implementation Dog
- (void)run
{
    NSLog(@"%d岁的Dog---run---跑起来了", self.age);
}

- (void)eat:(NSString *)food
{
    NSLog(@"%d岁的Dog吃%@了", self.age, food);
}
@end
