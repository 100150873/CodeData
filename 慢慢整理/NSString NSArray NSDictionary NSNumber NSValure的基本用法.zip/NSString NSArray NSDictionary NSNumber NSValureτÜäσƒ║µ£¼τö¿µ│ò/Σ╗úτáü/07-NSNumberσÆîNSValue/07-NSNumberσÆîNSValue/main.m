//
//  main.m
//  07-NSNumber和NSValue
//
//  Created by MLJ on 14-5-17.
//  Copyright (c) 2014年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{
    @autoreleasepool {
        typedef struct {
            int year;
            int month;
            int day;
        } Date;
        Date d = {2014, 5, 17};
        // 将结构体d包装成NSValue对象
        NSValue *dValue = [NSValue valueWithBytes:&d objCType:@encode(Date)];
        NSArray *array = @[dValue];
        // 取出value之前包装的结构体数据
        Date newD;
        [dValue getValue:&newD];
    }
    return 0;
}

void useValue()
{
    CGPoint p1 = CGPointMake(10, 10);
    CGPoint p2 = CGPointMake(20, 30);
    NSArray *array = @[
                       [NSValue valueWithPoint:p1],
                       [NSValue valueWithPoint:p2]];
    
    //        NSValue *v2 = [array lastObject];
    //        v2.pointValue
}

void useNumber()
{
    // 基本数据类型
    int age = 20;
    double height = 10.5;
    BOOL rich = YES;
    
    // 将基本数据类型包装成NSNumber对象
    //        NSNumber *ageNum = [NSNumber numberWithInt:age];
    //        NSNumber *heightNum = [NSNumber numberWithDouble:height];
    //        NSNumber *richNum = [NSNumber numberWithBool:rich];
    
    //        NSArray *array = @[ageNum, heightNum, richNum];
    
    NSArray *array = @[ @(age), @(height), @(rich), @(10), @30];
    
    
    NSNumber *richNum = [array lastObject];
    
    // 取出之前的包装的数值
    NSLog(@"%d", richNum.boolValue);
}
