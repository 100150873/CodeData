# LXNetworking
###网络层封装，基于AFNetworking 3.0
---
####实现的功能
* get请求
* post请求
* 图片上传
* 文件下载
* 网络状况检测
* HUD显示（使用的MBProgressHUD，不喜欢的可以自己去掉）

---

[详细使用方法及请至我的简书查看](http://www.jianshu.com/p/3b285eee9a91)


