//
//  AppDelegate.h
//  LXNetworkingDemo
//
//  Created by 刘鑫 on 16/4/9.
//  Copyright © 2016年 liuxin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

