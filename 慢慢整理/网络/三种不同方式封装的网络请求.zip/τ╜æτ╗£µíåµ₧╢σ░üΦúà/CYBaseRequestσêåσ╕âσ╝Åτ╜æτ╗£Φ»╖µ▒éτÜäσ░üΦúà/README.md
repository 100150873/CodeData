AFNetWorking->CYRequestManager->CYBaseRequest

简书地址：http://www.jianshu.com/p/1f5cd52981a1
