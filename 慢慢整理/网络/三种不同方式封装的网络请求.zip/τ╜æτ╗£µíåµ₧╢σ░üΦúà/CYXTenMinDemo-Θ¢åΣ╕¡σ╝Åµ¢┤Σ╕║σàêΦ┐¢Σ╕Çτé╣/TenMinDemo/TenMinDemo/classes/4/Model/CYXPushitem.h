//
//  CYXPushitem.h
//  
//
//  Created by Macx on 15/9/11.
//  Copyright (c) 2015年 CYX. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CYXPushitem : NSObject

// 保存跳转的控制器的类型
@property (nonatomic, assign) Class descVcClass;

@end
