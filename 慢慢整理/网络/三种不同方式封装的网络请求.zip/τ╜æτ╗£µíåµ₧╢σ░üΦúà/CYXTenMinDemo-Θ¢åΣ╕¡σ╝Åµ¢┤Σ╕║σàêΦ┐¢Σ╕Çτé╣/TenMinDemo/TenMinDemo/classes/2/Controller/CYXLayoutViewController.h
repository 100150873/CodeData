//
//  CYXLayoutViewController.h
//  CYCollectionViewTest
//
//  Created by Macx on 16/3/6.
//  Copyright © 2016年 cyx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CYXLayoutViewController : UIViewController

@end
