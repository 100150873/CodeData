//
//  CYXPhotoCell.h
//  CYCollectionViewTest
//
//  Created by apple开发 on 16/3/8.
//  Copyright © 2016年 cyx. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CYXPhotoCell : UICollectionViewCell

@property (nonatomic, copy) NSString *imageName;

@end
