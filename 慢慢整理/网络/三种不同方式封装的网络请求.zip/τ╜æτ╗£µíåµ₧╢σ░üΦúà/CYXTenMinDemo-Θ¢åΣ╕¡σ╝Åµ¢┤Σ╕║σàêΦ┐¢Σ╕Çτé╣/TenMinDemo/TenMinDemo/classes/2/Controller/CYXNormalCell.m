//
//  CYXNormalCell.m
//  CYCollectionViewTest
//
//  Created by apple开发 on 16/3/7.
//  Copyright © 2016年 cyx. All rights reserved.
//

#import "CYXNormalCell.h"

@implementation CYXNormalCell

- (void)awakeFromNib {
    // Initialization code
}

@end
