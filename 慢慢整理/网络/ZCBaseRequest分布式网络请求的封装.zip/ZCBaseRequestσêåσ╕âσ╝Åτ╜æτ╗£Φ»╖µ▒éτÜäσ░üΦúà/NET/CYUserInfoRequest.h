//
//  CYUserInfoRequest.h
//  NET
//
//  Created by Charles on 2017/3/14.
//  Copyright © 2017年 Charles. All rights reserved.
//

#import "CYBaseRequest.h"

@interface CYUserInfoRequest : CYBaseRequest

@property (nonatomic, assign) NSInteger userId;

@end
