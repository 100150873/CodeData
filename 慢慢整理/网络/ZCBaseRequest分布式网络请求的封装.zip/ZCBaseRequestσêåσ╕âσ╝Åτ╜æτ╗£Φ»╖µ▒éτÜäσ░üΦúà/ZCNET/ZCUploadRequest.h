//
//  ZCUploadRequest.h
//  NET
//
//  Created by yixin on 17/4/19.
//  Copyright © 2017年 Charles. All rights reserved.
//

#import "ZCBaseRequest.h"

typedef void (^ZCConstructingBlock)(id<AFMultipartFormData> formData);

@interface ZCUploadRequest : ZCBaseRequest

@property(nonatomic,assign)ZCConstructingBlock constructingBlock;

- (void)uploadDataShowHUD:(BOOL)showHUD
         completionHandle:(ZCRequestCompletionHandle)completionHandle;
@end
