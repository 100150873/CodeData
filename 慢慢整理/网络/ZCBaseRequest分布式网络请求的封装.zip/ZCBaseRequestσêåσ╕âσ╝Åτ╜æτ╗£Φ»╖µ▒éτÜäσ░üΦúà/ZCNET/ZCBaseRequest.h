//
//  ZCBaseRequest.h
//  NET
//
//  Created by yixin on 17/4/1.
//  Copyright © 2017年 Charles. All rights reserved.
//
/**ZCRequestManager 需要参数、链接，所以设计ZCBaseRequest类 ，使得参数和链接不过于暴露 封装参数，链接 以及请求成功后数据的处理  */

#import <UIKit/UIKit.h>
#import "ZCRequestConst.h"
#import "ZCRequestManager.h"
#import "MBProgressHUD.h"
#import "YYModel.h"


@interface ZCBaseRequest : NSObject

@property(nonatomic,copy)NSString *url;
@property(nonatomic,assign)ZCRequestMethodType methodType;
@property(nonatomic,assign)ZCResponeSerializerType responeSerializerType;
@property(nonatomic,strong)NSDictionary *extraParameters;


/**
 *  获取网络
 */
@property (nonatomic,assign)NetworkStatus networkStats;

- (void)sendRequestWithResultModelClass:(Class)modelClass
                                showHUD:(BOOL)showHUD
                                completionHandle:(ZCRequestCompletionHandle)completionHandle;




@end
