//
//  ZCRequestConst.h
//  NET
//
//  Created by Apple on 2017/4/1.
//  Copyright © 2017年 Charles. All rights reserved.
//

#ifndef ZCRequestConst_h
#define ZCRequestConst_h

#import <Foundation/Foundation.h>
// 数据解析类型
typedef NS_ENUM(NSInteger, ZCResponeSerializerType) {//数据解析类型
    ZCResponeSerializerTypeDEFAULT,//默认类型 JSON
    ZCResponeSerializerTypeJSON,//
    ZCResponeSerializerTypeXML,//XML 返回数据XML格式
    ZCResponeSerializerTypePLIST,// Plist 返回类型是plist格式
    ZCResponeSerializerTypeIMAGE,// 返回的数据是Image格式
    ZCResponeSerializerTypeDATA//返回的数据是二进制格式
};

// 请求方式
typedef NS_ENUM(NSInteger, ZCRequestMethodType) {
    ZCRequestMethodTypeGET,
    ZCRequestMethodTypePOST
};

typedef enum{
    
    StatusUnknown           = -1, //未知网络
    StatusNotReachable      = 0,    //没有网络
    StatusReachableViaWWAN  = 1,    //手机自带网络
    StatusReachableViaWiFi  = 2     //wifi
    
}NetworkStatus;

#endif /* ZCRequestConst_h */
