//
//  ZCRequestManager.m
//  NET
//
//  Created by yixin on 17/4/1.
//  Copyright © 2017年 Charles. All rights reserved.
//

#import "ZCRequestManager.h"


@interface AFHTTPSessionManager (share)

+ (instancetype)shareManager;
@end

@implementation AFHTTPSessionManager (share)

+ (instancetype)shareManager
{
    static AFHTTPSessionManager *_requestManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _requestManager = [AFHTTPSessionManager manager];
        _requestManager.responseSerializer.acceptableContentTypes = [NSSet setWithObjects:@"application/json", @"text/plain", @"text/json", @"text/javascript", @"text/html", nil];
    });
    
    return _requestManager;
}

@end

@implementation ZCRequestManager

+ (NSURLSessionTask *)requestWithUrl:(NSString *)url
                          parameters:(id)parameters
                          serializerType:(ZCResponeSerializerType)serializerType
                          methodType:(ZCRequestMethodType)methodType
                          success:(ZCRequestSuccessBlock)success
                          failure:(ZCRequestFailBlock)failure {
    AFHTTPSessionManager *manager = [AFHTTPSessionManager shareManager];
    manager.responseSerializer = [self responeseSerializerWithSerializerType:serializerType];
    switch (methodType) {
            
        case ZCRequestMethodTypeGET:
        {
          return   [manager GET:url parameters:parameters progress:nil success:success failure:failure];
        }
            break;
        case ZCRequestMethodTypePOST:
        {
           return [manager POST:url parameters:parameters progress:nil success:success failure:failure];
        }
            break;
        default:
            return [manager POST:url parameters:parameters progress:nil success:success failure:failure];
            break;
    }
   
}

+ (NSURLSessionDataTask *)uploadWithURLString:(NSString *)URLString
                   params:(NSDictionary *)params
                   serializerType:(ZCResponeSerializerType)serializerType
                   constructingBody:(void (^)(id<AFMultipartFormData> formData))constructingBody
                   successHandle:(ZCRequestSuccessBlock)successHandle
                   failureHandle:(ZCRequestFailBlock)failureHandle {
    
    AFHTTPSessionManager *manager = [AFHTTPSessionManager shareManager];
    
    manager.responseSerializer = [self responeseSerializerWithSerializerType:serializerType];
    
   return  [manager POST:URLString parameters:params constructingBodyWithBlock:constructingBody progress:nil success:successHandle failure:failureHandle];
}


+ (AFHTTPResponseSerializer *)responeseSerializerWithSerializerType:(ZCResponeSerializerType)serializerType
{
    AFHTTPResponseSerializer *serializer = nil;
    switch (serializerType)
    {
        case ZCResponeSerializerTypeDEFAULT:
        {
            serializer = [AFJSONResponseSerializer serializer];
        }
            break;
        case ZCResponeSerializerTypeJSON:
        {
            serializer = [AFJSONResponseSerializer serializer];
        }
            break;
        case ZCResponeSerializerTypeXML:
        {
            serializer = [AFXMLParserResponseSerializer serializer];
        }
            break;
        case ZCResponeSerializerTypePLIST:
        {
            serializer = [AFPropertyListResponseSerializer serializer];
        }
            break;
        case ZCResponeSerializerTypeIMAGE:
        {
         serializer = [AFImageResponseSerializer serializer];
        }
            break;
        case ZCResponeSerializerTypeDATA:
        {
            serializer = [AFHTTPResponseSerializer serializer];
        }
            break;
    }
    return serializer;
}





@end
