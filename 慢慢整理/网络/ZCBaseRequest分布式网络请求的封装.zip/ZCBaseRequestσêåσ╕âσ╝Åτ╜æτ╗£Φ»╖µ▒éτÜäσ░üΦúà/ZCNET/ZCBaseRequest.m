//
//  ZCBaseRequest.m
//  NET
//
//  Created by yixin on 17/4/1.
//  Copyright © 2017年 Charles. All rights reserved.
//

#import "ZCBaseRequest.h"
#import "AFNetworkActivityIndicatorManager.h"
#import "AFNetworking.h"

typedef NSURLSessionTask ZCURLSessionTask;

static NSMutableArray *tasks;
@implementation ZCBaseRequest

- (NSMutableArray *)tasks{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
     
        tasks = [[NSMutableArray alloc] init];
    });
    return tasks;
}

- (instancetype)init
{
    if (self = [super init]) {
        _responeSerializerType = ZCResponeSerializerTypeDEFAULT;
        _methodType = ZCRequestMethodTypePOST;
    }
    return self;
}

- (void)sendRequestWithResultModelClass:(Class)modelClass
                                showHUD:(BOOL)showHUD
                                completionHandle:(ZCRequestCompletionHandle)completionHandle
{
    if (!_url || !_url.length) return;
    
    //检查地址中是否有中文
    NSString *urlStr=[NSURL URLWithString:_url]?_url:[self strUTF8Encoding:_url];
    if (showHUD==YES) {
        [MBProgressHUD showHUDAddedTo:nil animated:YES];
        [UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    }
    
   ZCURLSessionTask *sessionTask = [ZCRequestManager requestWithUrl:urlStr
                                                         parameters:self.parameters
                                                         serializerType:self.responeSerializerType
                                                         methodType:self.methodType
                                                         success:^(NSURLSessionTask *task, id respone) {
        if (showHUD) {
            [MBProgressHUD hideHUDForView:nil animated:YES];
            [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
        }
        if (!modelClass) {
         !completionHandle ?:  completionHandle(YES,respone,@"成功");
         [[self tasks] removeObject:sessionTask];
        }else{
        !completionHandle ?:  completionHandle(YES,[modelClass yy_modelWithJSON:respone],@"成功");
        }
       [[self tasks] removeObject:sessionTask];
       
    } failure:^(NSURLSessionTask *task, NSError *error) {
        if (showHUD) {
            [MBProgressHUD hideHUDForView:nil animated:YES];
            [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
        }

       !completionHandle ?:  completionHandle(NO,nil,error.description);
        [[self tasks] removeObject:sessionTask];
    }];
    
    if (sessionTask) {
        [[self tasks] addObject:sessionTask];
    }
}


- (NSDictionary *)parameters
{
    NSDictionary *jsonDic = [self yy_modelToJSONObject];
    if ([jsonDic isKindOfClass:[NSDictionary class]]) {
        NSMutableDictionary *params = [jsonDic mutableCopy];
        [params addEntriesFromDictionary:self.extraParameters];
        for (NSString *deleteKey in @[@"url", @"methodType", @"extraParams"]) {//删掉多余的键值对
            if ([params.allKeys containsObject:deleteKey]) {
                [params removeObjectForKey:deleteKey];
            }
        }
        
        for (id key in params.allKeys) {//删掉空值
            id obj = [params objectForKey:key];
            if (!obj || [obj isKindOfClass:[NSNull class]] || obj == (id)kCFNull) {
                [params removeObjectForKey:key];
            }
        }
        return params;
    }

    return self.extraParameters;
}

- (NSString *)strUTF8Encoding:(NSString *)str{
    return [str stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLPathAllowedCharacterSet]];
}

#pragma makr - 开始监听网络连接

- (void)startMonitoring
{
    // 1.获得网络监控的管理者
    AFNetworkReachabilityManager *mgr = [AFNetworkReachabilityManager sharedManager];
    // 2.设置网络状态改变后的处理
    [mgr setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status) {
        // 当网络状态改变了, 就会调用这个block
        switch (status)
        {
            case AFNetworkReachabilityStatusUnknown: // 未知网络
                
                self.networkStats=StatusUnknown;
                
                break;
            case AFNetworkReachabilityStatusNotReachable: // 没有网络(断网)
                
                self.networkStats=StatusNotReachable;
                break;
            case AFNetworkReachabilityStatusReachableViaWWAN: // 手机自带网络
                
                self.networkStats=StatusReachableViaWWAN;
                break;
            case AFNetworkReachabilityStatusReachableViaWiFi: // WIFI
                
                self.networkStats=StatusReachableViaWiFi;
                break;
        }
    }];
    [mgr startMonitoring];
}

@end
