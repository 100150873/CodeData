//
//  ZCUploadRequest.m
//  NET
//
//  Created by yixin on 17/4/19.
//  Copyright © 2017年 Charles. All rights reserved.
//

#import "ZCUploadRequest.h"

typedef NSURLSessionTask ZCUploadURLSessionTask;

static NSMutableArray *uploadTasks;

@implementation ZCUploadRequest

- (NSMutableArray *)uploadTasks{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        
        uploadTasks = [[NSMutableArray alloc] init];
    });
    return uploadTasks;
}

- (ZCConstructingBlock)constructingBodyBlock {
    return ^(id<AFMultipartFormData> formData) {
//        NSData *data = UIImageJPEGRepresentation(_image, 0.9);
        NSData *data = nil;
        NSString *fileName = @"photo.png";
        NSString *formKey = @"data";
        NSString *mimeType = @"image/png";
        /**
         猿题库原来是这种类型
         NSString *name = @"image";
         NSString *formKey = @"image";
         NSString *type = @"image/jpeg";
         */
        [formData appendPartWithFileData:data name:formKey fileName:fileName mimeType:mimeType];
    };
}

- (void)uploadDataShowHUD:(BOOL)showHUD
         completionHandle:(ZCRequestCompletionHandle)completionHandle;
{
    if (!self.url || !self.url.length) return;
    
    //检查地址中是否有中文
    NSString *urlStr=[NSURL URLWithString:self.url]?self.url:[self strUTF8Encoding:self.url];
    if (showHUD) {
        
        [MBProgressHUD hideHUDForView:[self getTopWindow] animated:YES];
        [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    }
    ZCUploadURLSessionTask *sessionTask = [ZCRequestManager uploadWithURLString:urlStr
                                                            params:self.parameters
                                                    serializerType:self.responeSerializerType
                                                  constructingBody:self.constructingBlock successHandle:^(NSURLSessionTask *task, id respone) {
                                                      if (showHUD) {
                                                          [MBProgressHUD hideHUDForView:[self getTopWindow] animated:YES];
                                                          [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
                                                      }
                                                      
                                                      !completionHandle ?:  completionHandle(YES,respone,@"成功");
                                                      [[self uploadTasks] removeObject:sessionTask];
                                                               } failureHandle:^(NSURLSessionTask *task, NSError *error) {
                                                                   if (showHUD) {
                                                                       [MBProgressHUD hideHUDForView:[self getTopWindow] animated:YES];
                                                                       [UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
                                                                   }
                                                                   
                                                                   !completionHandle ?:  completionHandle(NO,nil,error.description);
                                                                   [[self uploadTasks] removeObject:sessionTask];
                                                                   
                                                               }];
    if (sessionTask) {
        [[self uploadTasks] addObject:sessionTask];
    }
    
    
}

- (NSString *)strUTF8Encoding:(NSString *)str{
    return [str stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLPathAllowedCharacterSet]];
}

- (NSDictionary *)parameters
{
    NSDictionary *jsonDic = [self yy_modelToJSONObject];
    if ([jsonDic isKindOfClass:[NSDictionary class]]) {
        NSMutableDictionary *params = [jsonDic mutableCopy];
        [params addEntriesFromDictionary:self.extraParameters];
        for (NSString *deleteKey in @[@"url", @"methodType", @"extraParams"]) {//删掉多余的键值对
            if ([params.allKeys containsObject:deleteKey]) {
                [params removeObjectForKey:deleteKey];
            }
        }
        
        for (id key in params.allKeys) {//删掉空值
            id obj = [params objectForKey:key];
            if (!obj || [obj isKindOfClass:[NSNull class]] || obj == (id)kCFNull) {
                [params removeObjectForKey:key];
            }
        }
        return params;
    }
    
    return self.extraParameters;
}

- (UIWindow *)getTopWindow {
    UIWindow *keyWindow = [UIApplication sharedApplication].keyWindow;
    if (!keyWindow) {
        // 有可能keyWindow不存在
        keyWindow = [UIApplication sharedApplication].windows.firstObject;
    }
    return keyWindow;
}

@end
