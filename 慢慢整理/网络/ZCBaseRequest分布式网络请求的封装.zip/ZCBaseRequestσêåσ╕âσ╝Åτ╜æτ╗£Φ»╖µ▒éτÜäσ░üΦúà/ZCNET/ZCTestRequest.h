//
//  ZCTestRequest.h
//  NET
//
//  Created by yixin on 17/4/1.
//  Copyright © 2017年 Charles. All rights reserved.
//
/**设置 URL 参数  请求类型 */

#import "ZCBaseRequest.h"

@interface ZCTestRequest : ZCBaseRequest

@property(nonatomic,copy)NSString *token;
@property(nonatomic,copy)NSString *userName;
@property(nonatomic,copy)NSString *passWord;
@end
