01.获得文件的MIMEType    15
02.多线程下载文件思路 5
03.文件的压缩和解压缩 12
04.NSURLConnection和Runloop补充   20
----
05.NSURLSession的基本使用    13
06.NSURLSession相关代理方法   20
07.NSURLSessionDownloadTask大文件下载（block） 15
----
08.NSURLSessionDownloadTask大文件下载（delete) 13
09.NSURLSessionDownloadTask大文件下载（断点下载) 20
10.NSURLSessionDataTask实现大文件下载           10
------------------
11.NSURLSessionDataTask离线断点下载（断点续传）   21
12.NSURLSessionDataTask断点下载优化             10
13.NSURLSession对象的释放                       5
-------
14.NSURLSession实现文件上传                     15
15.NSURLSession配置简单说明                       10
-------
16.UIWebView简单介绍            5
17.UIWebView的基本使用           15
18.UIWebView应用小案例           15





01-掌握-获得文件的MIMEType
02-掌握-文件的压缩和解压缩
03-掌握-NSURLConnection和Runloop补充
04-掌握-NSURLSession的基本使用
05-掌握-NSURLSession相关代理方法
06-掌握-NSURLSessionDownloadTask大文件下载（block）
07-掌握-NSURLSessionDownloadTask大文件下载（delete)
08-掌握-NSURLSessionDownloadTask大文件下载（断点下载)
09-掌握-NSURLSessionDataTask实现大文件下载
10-掌握-NSURLSessionDataTask离线断点下载（断点续传）
11-掌握-NSURLSessionDataTask断点下载优化
12-掌握-NSURLSession实现文件上传
13-掌握-UIWebView的基本使用
14-掌握-UIWebView应用小案例

