//
//  ViewController.m
//  RDPSelectView
//
//  Created by RDP on 16/12/6.
//  Copyright © 2016年 RDP. All rights reserved.
//

#import "ViewController.h"
#import "RDPSelectView.h"
#import "ZCSelectView.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)showClick:(id)sender {
/**
    NSArray *array = @[
                       [RDPSelectModel rdpSelectModelWithTitle:@"小学" titleColor:nil],
                       [RDPSelectModel rdpSelectModelWithTitle:@"初中" titleColor:nil],
                       [RDPSelectModel rdpSelectModelWithTitle:@"高中" titleColor:nil],
                       [RDPSelectModel rdpSelectModelWithTitle:@"大学" titleColor:nil],
                       ];
    
    [RDPSelectView rdp_showSelectViewWithTitle:nil cancelButttonTitle:nil actionContent:array selectBlock:^(RDPSelectView *selectView, NSInteger index) {
    }];

    <##>*/
    
    NSArray *arrayTitles = @[@"高中",@"大学",@"初中",@"小学",@"幼儿园",@"培训班"];
   // NSArray *arrayColor = @[[UIColor blueColor],[UIColor redColor],[UIColor yellowColor],[UIColor purpleColor],[UIColor brownColor],[UIColor greenColor]];
    NSMutableArray *arrayTemp = [[NSMutableArray alloc]init];
    for (NSUInteger i = 0; i < arrayTitles.count; i ++)
    {
        contentModel *model = [[contentModel alloc]init];
        model.title = arrayTitles[i];
        //model.titleColor = arrayColor[i];
        [arrayTemp addObject:model];
    }
    ZCSelectView *selectView = [[ZCSelectView alloc]initWithFrame:(CGRect){0,0,[UIScreen mainScreen].bounds.size} withCancelButtonTitle:@"取消" topTitle:@"测试" contentArray:arrayTemp selectedContent:^(ZCSelectView *selectView, NSInteger index) {
        
    }];
    [selectView show];
}

@end
