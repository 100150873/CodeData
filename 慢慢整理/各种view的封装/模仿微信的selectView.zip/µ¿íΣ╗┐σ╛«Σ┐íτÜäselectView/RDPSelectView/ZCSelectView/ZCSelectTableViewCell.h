//
//  ZCSelectTableViewCell.h
//  RDPSelectView
//
//  Created by yixin on 17/4/1.
//  Copyright © 2017年 RDP. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "contentModel.h"
@interface ZCSelectTableViewCell : UITableViewCell

@property(nonatomic,strong)contentModel *model;



+ (instancetype)selectTableViewCellWithStyle:(UITableViewCellStyle)style tableView:(UITableView *)tableView reuseID:(NSString *)reuseID;

@end
