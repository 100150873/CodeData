//
//  contentModel.h
//  RDPSelectView
//
//  Created by yixin on 17/4/1.
//  Copyright © 2017年 RDP. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface contentModel : NSObject

@property(nonatomic,copy)NSString *title;



@end
