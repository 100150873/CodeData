//
//  ZCSelectView.m
//  RDPSelectView
//
//  Created by yixin on 17/4/1.
//  Copyright © 2017年 RDP. All rights reserved.
//

#define kScreen [UIScreen mainScreen].bounds
#define kScreenWidth [UIScreen mainScreen].bounds.size.width
#define kScreenHeight [UIScreen mainScreen].bounds.size.height
#define kTitleDefaultHeight 40
#define kSpaceHeight 5
#define kCellHeight 44
#define kCancelHeight kCellHeight
#define kMaxCellCount 4
#define Font_Size(...) [UIFont systemFontOfSize:(__VA_ARGS__)]
#define kContentColor [UIColor colorWithRed:245.0f/255.0f green:245.0f/255.0f blue:245.0f/255.0f alpha:1.0f]
#define REUSEID @"reuseid"

#import "ZCSelectView.h"
#import "ZCSelectTableViewCell.h"

@interface ZCSelectView ()<UITableViewDelegate,UITableViewDataSource,UIGestureRecognizerDelegate>
@property(nonatomic,copy)NSString *title;//顶部标题
@property(nonatomic,copy)NSString *cancelTitle;//取消按钮的标题
@property(nonatomic,strong)NSArray <contentModel *>*arrayContent;//模型数组
@property(nonatomic,assign)CGFloat contentViewHeight;//能显示的最大行数 4
@property(nonatomic,assign)BOOL outMaxCount;//内容超过了最大的默认行数
@property(nonatomic,assign)CGFloat containerViewHeight;//父视图的高度
@property(nonatomic,strong)UIView *viewContainer;//标题、取消按钮、内容的父视图
@property(nonatomic,strong)UILabel *labelTitle;//标题
@property(nonatomic,strong)UITableView *tableViewContent;//内容view
@property(nonatomic,strong)UIButton *buttonCancel;//取消button
/**<# #> */
@property(nonatomic,assign)ZCSelectedContentBlock selectBlock;
@end

@implementation ZCSelectView

#pragma mark - Life Cyle
- (instancetype)initWithFrame:(CGRect)frame withCancelButtonTitle:(NSString *)cancelTitle topTitle:(NSString *)topTitle contentArray:(NSArray *)arrayModel selectedContent:(ZCSelectedContentBlock)selectedBlock
{
    self = [super initWithFrame:frame];
    if (self)
    {
        _title = topTitle;
        _arrayContent = arrayModel;
        _cancelTitle = cancelTitle;
        _outMaxCount = _arrayContent.count > kMaxCellCount ? YES : NO;
        _selectBlock = selectedBlock;
        self.tag = kMaxCellCount;
        [self addSubviews];
        [self addGesture];
    }
    return self;
}

#pragma mark - Init UI

- (void)addSubviews
{
    _contentViewHeight = _outMaxCount ? kMaxCellCount * kCellHeight : _arrayContent.count * kCellHeight;
    _containerViewHeight = _contentViewHeight + kTitleDefaultHeight + kSpaceHeight + kCancelHeight;
    [self setupContainerView];
}

- (void)setupContainerView
{
    [self addSubview:({
        UIView *viewSuper = [[UIView alloc]initWithFrame:CGRectMake(0, kScreen.size.height, kScreen.size.width, _containerViewHeight)];
        viewSuper.backgroundColor = [UIColor grayColor];
        _viewContainer = viewSuper;
    })];
    [self setupTopTitle];
    [self setupContentView];
    [self setupCancelButton];
}

- (void)setupTopTitle
{
    if (_title)
    {
        [_viewContainer addSubview:({
            UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0, 0, kScreenWidth, kTitleDefaultHeight)];
            label.text = _title;
            label.font = Font_Size(14);
            label.textAlignment = NSTextAlignmentCenter;
            label.backgroundColor = [UIColor whiteColor];
            label.textColor = [UIColor grayColor];
            _labelTitle = label;
        })];
    }
   
}

- (void)setupContentView
{
    [_viewContainer addSubview:({
        CGFloat tableViewHeight = _outMaxCount ? kMaxCellCount * kCellHeight : _arrayContent.count * kCellHeight ;
        UITableView *tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(_labelTitle.frame), kScreenWidth, tableViewHeight)];
        tableView.bounces = NO;
        tableView.delegate = self;
        tableView.dataSource = self;
        tableView.scrollEnabled = _outMaxCount ;
        _tableViewContent = tableView;
    })];
}

- (void)setupCancelButton
{
    [_viewContainer addSubview:({
        UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(0, CGRectGetMaxY(_tableViewContent.frame) + kSpaceHeight, kScreenWidth, kCancelHeight)];
        [button setTitle:(_cancelTitle ? _cancelTitle : @"取消") forState:UIControlStateNormal];
        [button setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
        [button addTarget:self action:@selector(dismiss) forControlEvents:UIControlEventTouchDown];
        [button setBackgroundColor:[UIColor whiteColor]];
        _buttonCancel = button;
    })];
}

#pragma mark - Delegate
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return _arrayContent.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    ZCSelectTableViewCell *cell = [ZCSelectTableViewCell selectTableViewCellWithStyle:UITableViewCellStyleDefault tableView:tableView reuseID:REUSEID];
    cell.model = _arrayContent[indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    _selectBlock(self,indexPath.row);
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    [self dismiss];
    
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return kCellHeight;
}

#pragma mark - UIGestureRecognizerDelegate

- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
    if (touch.view == self) return YES;
    return NO;
}

#pragma mark - Event Response

- (void)show
{
    self.backgroundColor = [UIColor grayColor];
    [[[[UIApplication sharedApplication] windows] firstObject] addSubview:self];
    [UIView animateWithDuration:0.5f delay:0 usingSpringWithDamping:1.4f initialSpringVelocity:1.0f options:UIViewAnimationOptionCurveEaseInOut animations:^{
        _viewContainer.transform = CGAffineTransformMakeTranslation(0, - _containerViewHeight);
    } completion:nil];
}

- (void)dismiss
{
    [UIView animateWithDuration:0.3 animations:^{
        _viewContainer.transform = CGAffineTransformIdentity;
        self.alpha = 0.1f;
    } completion:^(BOOL finished) {
        [self removeFromSuperview];
    }];
}


#pragma mark - Private Method

- (void)addGesture
{
    self.userInteractionEnabled = YES;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(dismiss)];
    tap.delegate = self;
    [self addGestureRecognizer:tap];
}

#pragma mark - Getter and Setter






@end
