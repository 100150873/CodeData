//
//  ZCSelectView.h
//  RDPSelectView
//
//  Created by yixin on 17/4/1.
//  Copyright © 2017年 RDP. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "contentModel.h"
@class ZCSelectView;
typedef void(^ZCSelectedContentBlock)(ZCSelectView *selectView,NSInteger index);
@interface ZCSelectView : UIView

- (instancetype)initWithFrame:(CGRect)frame withCancelButtonTitle:(NSString *)cancelTitle topTitle:(NSString *)topTitle contentArray:(NSArray <contentModel *>*)arrayModel selectedContent:(ZCSelectedContentBlock)selectedBlock;
- (void)show;
@end
