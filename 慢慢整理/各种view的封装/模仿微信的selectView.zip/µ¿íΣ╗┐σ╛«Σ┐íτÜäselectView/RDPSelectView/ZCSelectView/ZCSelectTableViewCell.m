//
//  ZCSelectTableViewCell.m
//  RDPSelectView
//
//  Created by yixin on 17/4/1.
//  Copyright © 2017年 RDP. All rights reserved.
//

#import "ZCSelectTableViewCell.h"

@implementation ZCSelectTableViewCell

+ (instancetype)selectTableViewCellWithStyle:(UITableViewCellStyle)style tableView:(UITableView *)tableView reuseID:(NSString *)reuseID
{
    ZCSelectTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:reuseID];
    if (!cell)
    {
        cell = [[ZCSelectTableViewCell alloc]initWithStyle:style reuseIdentifier:reuseID];
        cell.textLabel.textAlignment = NSTextAlignmentCenter;
        cell.backgroundColor = [UIColor colorWithWhite:0.9f alpha:1.0f];
    }
    return cell;
}

- (void)setModel:(contentModel *)model
{
    _model = model;
    self.textLabel.textColor = [UIColor blackColor];
    self.textLabel.text = model.title;
}

@end
