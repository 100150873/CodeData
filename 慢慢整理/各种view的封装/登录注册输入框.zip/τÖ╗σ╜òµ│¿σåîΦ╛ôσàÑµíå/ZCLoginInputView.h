//
//  ZCLoginInputView.h
//  WFAPP
//
//  Created by HFY on 2018/7/3.
//  Copyright © 2018年 GZC. All rights reserved.
//

typedef NS_ENUM(NSInteger, ZCInputBoardType) {//输入框类型
    ZCInputBoardTypeTitle = 0,//左侧显示文字
    ZCInputBoardTypeImage//左侧显示图片
};
#import <UIKit/UIKit.h>

@interface ZCLoginInputView : UIView

/**
 输入框显示类型
 */
@property (nonatomic, assign) ZCInputBoardType  inputType;

- (NSString *)text;
- (void)setEdit:(BOOL)edit;
- (void)setText:(NSString *)text;
- (void)setTitle:(NSString *)title;
- (void)setImage:(NSString *)image;
- (void)setTitleWidth:(CGFloat)titleWidth;
- (void)setMaxInputLength:(NSInteger)maxInputLength;
- (void)setKeyboardType:(UIKeyboardType)keyboardType;
/**
 textField 到右侧的距离
 
 @param space 右侧的距离
 */
- (void)setTextFieldRightSpace:(CGFloat)space;
- (void)setPlaceholder:(NSString *)placeholder;

@end
