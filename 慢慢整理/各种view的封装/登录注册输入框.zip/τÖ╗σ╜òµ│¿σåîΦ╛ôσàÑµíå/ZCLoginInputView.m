//
//  ZCLoginInputView.m
//  WFAPP
//
//  Created by HFY on 2018/7/3.
//  Copyright © 2018年 GZC. All rights reserved.
//

#import "ZCLoginInputView.h"

@interface ZCLoginInputView ()

@property (nonatomic, strong) UIView *line;
/**
 标题宽度
 */
@property (nonatomic, assign) CGFloat titleWidth;
@property (nonatomic, assign) CGFloat rightSpace;
@property (nonatomic, strong) UILabel *labelTitle;
@property (nonatomic, strong) UIImageView *imgVIcon;
@property (nonatomic, strong) UITextField *textField;
@property (nonatomic, assign) NSInteger  maxInputLength;
@end

@implementation ZCLoginInputView

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self addSubview:self.labelTitle];
        [self addSubview:self.textField];
        [self addSubview:self.imgVIcon];
        [self addSubview:self.line];
        _maxInputLength = 12;
        _titleWidth = ZCWidth(45);
//        self.labelTitle.backgroundColor = self.textField.backgroundColor = self.btnEvent.backgroundColor = ZCRandomColor;
    }
    return self;
}

#pragma mark - =======Public 对外接口=========
- (void)setEdit:(BOOL)edit
{
    self.textField.enabled = edit;
}
- (void)setKeyboardType:(UIKeyboardType)keyboardType
{
    self.textField.keyboardType = keyboardType;
}

- (void)setPlaceholder:(NSString *)placeholder
{
    self.textField.placeholder = placeholder;
}

- (void)setImage:(NSString *)image
{
    self.imgVIcon.image = ZCImageNamed(image);
//    [[UIImageView alloc] initWithImage:<#(nullable UIImage *)#>];
}

- (void)setTitle:(NSString *)title
{
    self.labelTitle.text = title;
}

- (void)setText:(NSString *)text
{
    self.textField.text = text;
}

- (NSString *)text
{
    return self.textField.text;
}

/**
 textField 到右侧的距离

 @param space 右侧的距离
 */
- (void)setTextFieldRightSpace:(CGFloat)space
{
    _rightSpace = space;
}

/**
 标题宽度

 @param titleWidth 标题宽度
 */
- (void)setTitleWidth:(CGFloat)titleWidth
{
    _titleWidth = titleWidth;
}


- (void)layoutSubviews
{
    [super layoutSubviews];
    CGFloat margin = ZCWidth(8);
    if (self.inputType == ZCInputBoardTypeTitle) {//左侧显示文字
        
//        CGFloat width = [self.labelTitle.text widthForFont:ZCFont(15)] + 5;
//        ZCLog(@"%@ %.2f",self.labelTitle.text,width);
        [self.labelTitle mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.top.equalTo(self);
            make.left.equalTo(self).offset(margin);
            make.width.mas_equalTo(self.titleWidth);
        }];
        
        [self.textField mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.top.equalTo(self);
            make.left.equalTo(self.labelTitle.mas_right).offset(margin);
            make.right.equalTo(self).offset(- MAX(margin, self.rightSpace));
        }];
    } else {//左侧显示图片
        [self.imgVIcon mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(self);
            make.left.equalTo(self).offset(margin);
        }];
        [self.textField mas_makeConstraints:^(MASConstraintMaker *make) {
            make.bottom.top.equalTo(self);
            make.left.equalTo(self.imgVIcon.mas_right).offset(margin);
            make.right.equalTo(self).offset(- MAX(margin, self.rightSpace));
        }];
    }
    //分割线
    [self.line mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.right.left.equalTo(self);
        make.height.mas_equalTo(LineBorderWidth);
    }];
}

#pragma mark - =======字数限制=========
- (void)textFieldDidChange:(UITextField *)textField
{
    if (textField.text.length > _maxInputLength) {
        textField.text = [textField.text substringToIndex:_maxInputLength];
    }
}


#pragma mark - =======Getter=========
- (UILabel *)labelTitle
{
    if (!_labelTitle) {
        _labelTitle = [UILabel labelWithFontSize:ZCFont(15) textAlignment:NSTextAlignmentCenter titleColor:ZCColorTitle];
    }
    return _labelTitle;
}

- (UITextField *)textField
{
    if (!_textField) {
        _textField = [[UITextField alloc] init];
        _textField.textAlignment = NSTextAlignmentLeft;
        _textField.clearButtonMode = UITextFieldViewModeWhileEditing;
        [_textField addTarget:self action:@selector(textFieldDidChange:) forControlEvents:UIControlEventEditingChanged];
    }
    return _textField;
}

- (UIImageView *)imgVIcon
{
    if (!_imgVIcon) {
        _imgVIcon = [[UIImageView alloc] init];
    }
    return _imgVIcon;
}

- (UIView *)line
{
    if (!_line) {
        _line = [[UIView alloc] init];
        _line.backgroundColor = ZCColorSeperate;
    }
    return _line;
}

@end
