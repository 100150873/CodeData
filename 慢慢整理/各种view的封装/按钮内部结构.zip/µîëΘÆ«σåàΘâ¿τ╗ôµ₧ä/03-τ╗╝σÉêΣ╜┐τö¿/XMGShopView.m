//
//  XMGShopView.m
//  03-综合使用
//
//  Created by xiaomage on 15/5/28.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

#import "XMGShopView.h"
#import "XMGShop.h"

@interface XMGShopView()
@end

@implementation XMGShopView

+ (instancetype)shopView
{
    return [self shopViewWithShop:nil];
}

+ (instancetype)shopViewWithShop:(XMGShop *)shop
{
    XMGShopView *shopView = [[self alloc] init];
    shopView.backgroundColor = [UIColor redColor];
    shopView.shop = shop;
    return shopView;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        self.titleLabel.textAlignment = NSTextAlignmentCenter;
        self.titleLabel.font = [UIFont systemFontOfSize:11];
    }
    return self;
}

- (void)setShop:(XMGShop *)shop
{
    _shop = shop;
    
    // 设置子控件的数据
    if (shop.icon) {
        [self setImage:[UIImage imageNamed:shop.icon] forState:UIControlStateNormal];
    }
    
    [self setTitle:shop.name forState:UIControlStateNormal];
    
    // 不要直接拿出按钮内部的子控件，来修改文字、图片属性
//    self.titleLabel.text = shop.name;
//    self.imageView.image = [UIImage imageNamed:@"shop.icon"];
}

//- (CGRect)imageRectForContentRect:(CGRect)contentRect
//{
//    return CGRectMake(0, 0, contentRect.size.width, contentRect.size.height);
//}
//
//- (CGRect)titleRectForContentRect:(CGRect)contentRect
//{
//    return CGRectMake(0, 30, 70, 30);
//}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    CGFloat buttonW = self.frame.size.width;
    CGFloat buttonH = self.frame.size.height;
    
    CGFloat imageH = buttonW - 10;
    self.imageView.frame = CGRectMake(0, 0, buttonW, imageH);
    
    self.titleLabel.frame = CGRectMake(0, imageH, buttonW, buttonH - imageH);
}

@end
