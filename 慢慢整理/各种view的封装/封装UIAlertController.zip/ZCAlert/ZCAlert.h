//
//  ZCAlert.h
//  XWAlert
//
//  Created by Apple on 2017/4/3.
//  Copyright © 2017年 xuxiwen. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
#import "UIAlertController+extension.h"
typedef void(^ZCAlertConfirmHandle)();
typedef void(^ZCAlertCancelHandle)();
typedef void(^ZCAlertManager)(UIAlertController *manager);

//typedef NS_ENUM(NSInteger, ZCAlertStyle) {
//    ZCAlertStyleActionSheet,
//    ZCAlertStyleAlert
//}NS_ENUM_AVAILABLE_IOS(8_0);
@interface ZCAlert : NSObject

/**
 仅展示有取消和确定按钮的ZCAlertStyleAlert样式
 当取消和确定按钮标题为nil时仅作为一个默认2秒钟消失的提示
 
 @param title - Alert's title
 @param message - any message you want to show
 @param confirmTitle - the title of confirm button
 @param cancelTitle - the title of cancel button
 @param confirmHandle - confirm opeartion
 @param cancelHandle - cancel opeartion
 */
+ (void)showAlertWithTitle:(NSString *)title
                   message:(NSString *)message
              confirmTitle:(NSString *)confirmTitle
               cancelTitle:(NSString *)cancelTitle
            preferredStyle:(UIAlertControllerStyle)preferredStyle
             confirmHandle:(ZCAlertConfirmHandle)confirmHandle
              cancleHandle:(ZCAlertCancelHandle)cancelHandle;

/**
 仅展示有取消按钮的ZCAlertStyleAlert样式
 当取消按钮标题为nil时仅作为一个默认2秒钟消失的提示
 
 @param title - Alert's title
 @param message - any message you want to show
 @param cancelTitle - the title of cancel button
  @param actionManager - to add UIAlertAction by actionManager
 */
+ (UIAlertController *)showAlertWithTitle:(NSString *)title
                   message:(NSString *)message
               cancelTitle:(NSString *)cancelTitle
            preferredStyle:(UIAlertControllerStyle)preferredStyle
               actionMaker:(ZCAlertManager)actionManager;


/**
 自定义Alert
 
 @param title - Alert's title
 @param message - any message you want to show
 @param preferredStyle - show style (ActionSheet / Alert)
 @param actionManager - to add UIAlertAction by actionManager
 */
+ (void)showAlertWithTitle:(NSString *)title
                   message:(NSString *)message
            preferredStyle:(UIAlertControllerStyle)preferredStyle
               actionMaker:(ZCAlertManager)actionManager;

/**
 仅作为消息提示 设定消失时间
 
 @param title - Alert's title
 @param message - any message you want to show
 @param preferredStyle - show style (ActionSheet / Alert)
 @param autoDismissTime alert will auto dismiss after autoDismissTime
 */
+ (void)showAlertWithTitle:(NSString *)title
                   message:(NSString *)message
            preferredStyle:(UIAlertControllerStyle)preferredStyle
           autoDismissTime:(int)autoDismissTime;

@end
