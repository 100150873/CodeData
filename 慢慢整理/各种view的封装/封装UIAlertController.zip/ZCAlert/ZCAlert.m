//
//  ZCAlert.m
//  XWAlert
//
//  Created by Apple on 2017/4/3.
//  Copyright © 2017年 xuxiwen. All rights reserved.
//

#import "ZCAlert.h"
#import "ZCToolHelp.h"
@implementation ZCAlert

+ (void)showAlertWithTitle:(NSString *)title
                   message:(NSString *)message
              confirmTitle:(NSString *)confirmTitle
               cancelTitle:(NSString *)cancelTitle
            preferredStyle:(UIAlertControllerStyle)preferredStyle
             confirmHandle:(ZCAlertConfirmHandle)confirmHandle
              cancleHandle:(ZCAlertCancelHandle)cancelHandle
{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:preferredStyle];

    if (confirmTitle) {
        UIAlertAction *confirmAction = [UIAlertAction actionWithTitle:confirmTitle style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
            confirmHandle();
        }];
        [alertController addAction:confirmAction];
    }
    if (cancelTitle) {
        UIAlertAction *canleAction = [UIAlertAction actionWithTitle:cancelTitle style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            cancelHandle();
        }];
        [alertController addAction:canleAction];
    }
    
    __weak typeof(alertController) weakSelf = alertController;
    [[ZCToolHelp getCurrentScreenViewController] presentViewController:alertController animated:YES completion:^{
        if (confirmTitle == nil && cancelTitle == nil) {//当两个按钮都没有标题的时候2秒后自动消失
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [weakSelf dismissViewControllerAnimated:YES completion:nil];
            });
        }
    }];
}


+ (UIAlertController *)showAlertWithTitle:(NSString *)title
                   message:(NSString *)message
               cancelTitle:(NSString *)cancelTitle
            preferredStyle:(UIAlertControllerStyle)preferredStyle
               actionMaker:(ZCAlertManager)actionManager

{
    
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:preferredStyle];
    
    if (actionManager) {
        actionManager(alertController);
    }
    if (cancelTitle) {
        UIAlertAction *canleAction = [UIAlertAction actionWithTitle:cancelTitle style:UIAlertActionStyleCancel handler:^(UIAlertAction * _Nonnull action) {
            __weak typeof(alertController) weakSelf = alertController;
            
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2.0 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [weakSelf dismissViewControllerAnimated:YES completion:nil];
            });
        }];
        [alertController addAction:canleAction];
    }
    
    __weak typeof(alertController) weakSelf = alertController;
    [[ZCToolHelp getCurrentScreenViewController] presentViewController:alertController animated:YES completion:^{
        if ( cancelTitle == nil) {//当取消按钮都没有标题的时候2秒后自动消失
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [weakSelf dismissViewControllerAnimated:YES completion:nil];
            });
        }
    }];
    return alertController;
}


+ (void)showAlertWithTitle:(NSString *)title
                   message:(NSString *)message
            preferredStyle:(UIAlertControllerStyle)preferredStyle
               actionMaker:(ZCAlertManager)actionManager
{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:preferredStyle];
    if (actionManager) {
        actionManager(alertController);
    }
    [[ZCToolHelp getCurrentScreenViewController] presentViewController:alertController animated:YES completion:^{
        __weak typeof(alertController) weakSelf = alertController;
        if (!actionManager || alertController.actions.count == 0) {
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(2 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                [weakSelf dismissViewControllerAnimated:YES completion:nil];
            });
        }

    }];
    
}

+ (void)showAlertWithTitle:(NSString *)title
                   message:(NSString *)message
            preferredStyle:(UIAlertControllerStyle)preferredStyle
           autoDismissTime:(int)autoDismissTime
{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:preferredStyle];
    [[ZCToolHelp getCurrentScreenViewController] presentViewController:alertController animated:YES completion:^{
        __weak typeof(alertController) weakSelf = alertController;
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(autoDismissTime * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [weakSelf dismissViewControllerAnimated:YES completion:nil];
        });
        
        
    }];
    
}


@end
