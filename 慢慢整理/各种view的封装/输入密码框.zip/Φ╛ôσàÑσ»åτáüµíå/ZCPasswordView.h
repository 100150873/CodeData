//
//  ZCPasswordView.h
//  GTTemplateAPP
//
//  Created by yixin on 2017/5/19.
//  Copyright © 2017年 GZC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZCPasswordView : UIView<UITextFieldDelegate>

@property(nonatomic,copy)void (^inputDidChangeBlock)(NSInteger length,NSString *text);

- (NSString *)psw;

/**
 *  清除密码
 */
- (void)clearUpPassword;
- (void)showKeyboard;
- (void)dismisssKeyboard;
@end
