//
//  ZCPopView.m
//  HBPopView
//
//  Created by yixin on 17/3/31.
//  Copyright © 2017年 mingboJob. All rights reserved.
//

#import "ZCPopView.h"
#import "UIView+ZCExtension.h"
#define SCREEN_WIDTH            ([[UIScreen mainScreen] bounds].size.width)
#define SCREEN_HEIGHT           ([[UIScreen mainScreen] bounds].size.height)
@interface ZCPopView ()
{
    UIView *_superView;
}
@property(nonatomic,strong)UIButton *buttonDetail;
@property(nonatomic,strong)UIButton *buttonCancel;
@end

@implementation ZCPopView

#pragma mark - Public Method
- (instancetype)initWithFrame:(CGRect)frame withSuperView:(UIView *)superView
{
    
    self = [super initWithFrame:frame];
    if (self)
    {
        _superView = superView;
        [self addSubview:self.buttonCancel];
        [self addSubview:self.buttonDetail];
    }
    return self;
}

- (void)show
{
    /**
     
     UIViewAnimationOptionCurveEaseInOut        动画刚开始和要结束的时候,是缓慢的
     
     UIViewAnimationOptionCurveEaseIn            动画刚开始,是缓慢的
     
     UIViewAnimationOptionCurveEaseOut          动画要结束的时候,是缓慢的
     
     UIViewAnimationOptionCurveLinear          匀速
     
     */
    /**
     usingSpringWithDamping 弹簧动画的阻尼值 值从0.0到1.0之间 值越小  震动越大
     */
    
    /**
     initialSpringVelocity 形变的速度 velocity速度越大，那么形变会越快 幅度越大
     */
    self.backgroundColor = [UIColor grayColor];
    [_superView addSubview:self];
    [UIView animateWithDuration:0.5f delay:0.2 usingSpringWithDamping:0.45f initialSpringVelocity:9.0f options:UIViewAnimationOptionCurveEaseInOut animations:^{
        self.buttonCancel.y = 80;
        self.buttonDetail.y = 200;
    } completion:^(BOOL finished) {
        
    }];
}

- (void)dismiss
{
    [UIView animateWithDuration:0.5 delay:0 options:UIViewAnimationOptionCurveEaseInOut animations:^{
        
        self.buttonDetail.y = SCREEN_HEIGHT;
        self.buttonCancel.y = - 40;
    } completion:^(BOOL finished) {
        self.alpha = 0;
        [self removeFromSuperview];
    }];
}

#pragma mark - Event Response

- (void)clickedDetailButton:(UIButton *)calcelButton
{
    NSLog(@"点击了详情按钮");
}
#pragma mark - Getter and Setter
- (UIButton *)buttonCancel
{
    if (!_buttonCancel)
    {
        _buttonCancel = [[UIButton alloc]initWithFrame:CGRectMake(SCREEN_WIDTH - 80, -40, 40, 40)];     [_buttonCancel setBackgroundColor:[UIColor yellowColor]];
        [_buttonCancel setTitle:@"取消" forState:UIControlStateNormal];
        [_buttonCancel setTitleColor:[UIColor blueColor] forState:UIControlStateNormal];
        [_buttonCancel addTarget:self action:@selector(dismiss) forControlEvents:UIControlEventTouchDown];
    }
    return _buttonCancel;
}

- (UIButton *)buttonDetail
{
    if (!_buttonDetail)
    {
        _buttonDetail = [[UIButton alloc]initWithFrame:CGRectMake(50,SCREEN_HEIGHT , SCREEN_WIDTH - 100, SCREEN_WIDTH - 100)];     [_buttonDetail setBackgroundColor:[UIColor redColor]];
        [_buttonDetail setTitle:@"点击进入详情" forState:UIControlStateNormal];
        [_buttonDetail addTarget:self action:@selector(clickedDetailButton:) forControlEvents:UIControlEventTouchDown];
    }
    return _buttonDetail;
}


@end
