//
//  AppDelegate.h
//  HBPopView
//
//  Created by aplle on 2016/12/12.
//  Copyright © 2016年 mingboJob. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

