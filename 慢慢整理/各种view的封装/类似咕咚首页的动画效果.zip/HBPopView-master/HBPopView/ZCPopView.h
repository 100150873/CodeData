//
//  ZCPopView.h
//  HBPopView
//
//  Created by yixin on 17/3/31.
//  Copyright © 2017年 mingboJob. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZCPopView : UIView

- (instancetype)initWithFrame:(CGRect)frame withSuperView:(UIView *)superView;

- (void)show;
@end
