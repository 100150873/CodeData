//
//  ZCPostTopInfoView.m
//  GTTemplateAPP
//
//  Created by yixin on 2018/2/27.
//  Copyright © 2018年 GZC. All rights reserved.
//

#import "ZCPostTopInfoView.h"
#import "UIButton+WebCache.h"

@interface ZCPostTopInfoView ()

/**
 右侧按钮点击是否需要登录 才响应
 */
@property(nonatomic,assign)BOOL  needLogin;
@property (nonatomic, strong) UILabel *labelName,*labelDate;
@property (nonatomic, copy) dispatch_block_t clickCollectBlock;
@property (nonatomic, strong) UIButton *buttonIcon,*buttonRight;
/**
 左侧头像 和 右侧按钮默认的比例
 */
@property(nonatomic,assign)CGFloat  iconScale,btnHScale,btnWScale;
@end

@implementation ZCPostTopInfoView

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        _iconScale = 0.9;
        _btnHScale = 0.4;_btnWScale = 1.4;
        [self addSubview:self.labelDate];
        [self addSubview:self.labelName];
        [self addSubview:self.buttonIcon];
        [self addSubview:self.buttonRight];
        self.backgroundColor = ZCColorWhite;
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    CGFloat margin = ZCHeight(10);
    CGFloat iconWH = self.height * self.iconScale;
    [self.buttonIcon mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.left.equalTo(self);
        make.size.equalTo([NSValue valueWithCGSize:CGSizeMake(iconWH, iconWH)]);
    }];
    //右侧按钮
    CGFloat btnW = self.height * self.btnWScale;
    CGFloat btnH = btnW * self.btnHScale;
    [self.buttonRight mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.right.equalTo(self);
        make.size.equalTo([NSValue valueWithCGSize:CGSizeMake(btnW, btnH)]);
    }];
    [self.buttonRight addcornerRadius:btnH * 0.5];
    //标题
    [self.labelName mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.buttonIcon.mas_centerY);
        make.left.equalTo(self.buttonIcon.mas_right).offset(margin);
        make.right.equalTo(self.buttonRight.mas_left).offset(- margin);
        make.height.mas_equalTo(ZCHeight(25));
    }];
    //日期
    [self.labelDate mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.buttonIcon.mas_centerY);
        make.right.left.equalTo(self.labelName);
        make.height.mas_equalTo(ZCHeight(20));
    }];
    
}

#pragma mark - =======Public 对外接口=========
- (void)setDate:(NSString *)date
{
    self.labelDate.text = date;
}
- (void)setCollect:(BOOL)collect
{
    self.buttonRight.selected = collect;
    [self.buttonRight addBorderWidth:LineBorderWidth WithColor:collect ? ZCColorMain : ZCColorSeperate];
}
- (void)setPoster:(NSString *)poster
{
    self.labelName.text = poster;
}
- (void)setPosterIcon:(NSURL *)posterIcon
{
    [self.buttonIcon sd_setImageWithURL:posterIcon forState:normal placeholderImage:ZCImageNamed(@"share_logo_icon")];
}
- (void)clickCollectButton:(UIButton *)button
{
    if (self.needLogin) {//需要登录
        ZCWeakSelf;
        [[ZCUserInfoManager shareZCUserInfoManager] setLoginSuccessBlock:^{
            !weakSelf.clickCollectBlock ? : weakSelf.clickCollectBlock();
        }];
    }else {//不需要登录
        !_clickCollectBlock ? : _clickCollectBlock();
    }
}
/**
 设置右侧按钮选中状态、一般状态下的图片、标题
 
 @param selectedTitle 选中标题
 @param normalTitle 一般标题
 @param selectedImage 选中图片
 @param normalImage 一般图片
 */
- (void)setSelectedTitle:(NSString *)selectedTitle
             normalTitle:(NSString *)normalTitle
           selectedImage:(NSString *)selectedImage
             normalImage:(NSString *)normalImage
{
    //图片
    if ([normalImage isNotBlank]) {
        [self.buttonRight setImage:ZCImageNamed(normalImage) forState:UIControlStateNormal];
    }
    if ([normalImage isNotBlank]) {
        [self.buttonRight setImage:ZCImageNamed(selectedImage) forState:UIControlStateSelected];
    }
    //标题
    [self.buttonRight setTitle:normalTitle forState:UIControlStateNormal];
    [self.buttonRight setTitle:selectedTitle forState:UIControlStateSelected];
    //标题颜色
    [self.buttonRight setTitleColor:ZCColorSubTitle forState:UIControlStateNormal];
    [self.buttonRight setTitleColor:ZCColorMain forState:UIControlStateSelected];
    //字体大小 间距
    self.buttonRight.titleLabel.font = ZCFont(13);
    if (normalImage.length || selectedImage.length ) {
        [self.buttonRight setButtonImageTitleStyle:ZCButtonImageTitleStyleLeft spacing:ZCHeight(2)];
    }
}

/**
 设置右侧按钮选中状态、一般状态下的标题 只有标题
 
 @param selectedTitle 选中标题
 @param normalTitle 一般标题
 */
- (void)setSelectedTitle:(NSString *)selectedTitle
             normalTitle:(NSString *)normalTitle
{
    [self setSelectedTitle:selectedTitle normalTitle:normalTitle selectedImage:nil normalImage:nil];
}

#pragma mark - =======Getter=========
- (UILabel *)labelName
{
    if (!_labelName) {
        _labelName = [UILabel labelWithFontSize:ZCFont(16) title:@"" textAlignment:NSTextAlignmentLeft titleColor:ZCColorMainTitle];
    }
    return _labelName;
}
- (UILabel *)labelDate
{
    if (!_labelDate) {
        _labelDate = [UILabel labelWithFontSize:ZCFont(12) title:@"" textAlignment:NSTextAlignmentLeft titleColor:ZCColorSubTitle];
    }
    return _labelDate;
}
- (UIButton *)buttonIcon
{
    if (!_buttonIcon) {
        _buttonIcon = [[UIButton alloc] init];
        [_buttonIcon addcornerRadius:SmallButtonCornerRadius];
    }
    return _buttonIcon;
}
- (UIButton *)buttonRight
{
    if (!_buttonRight) {
        _buttonRight = [[UIButton alloc] init];
         [_buttonRight addTarget:self action:@selector(clickCollectButton:) forControlEvents:UIControlEventTouchDown];
    }
    return _buttonRight;
}
@end
