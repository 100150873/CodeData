//
//  ZCPostTopInfoView.h
//  GTTemplateAPP
//
//  Created by yixin on 2018/2/27.
//  Copyright © 2018年 GZC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZCPostTopInfoView : UIView
 /*--------------------- 顶部比例 -----------------------*/
- (void)setBtnWScale:(CGFloat)btnWScale;//宽度比例
- (void)setBtnHScale:(CGFloat)btnHScale;//高度度比例
- (void)setIconScale:(CGFloat)iconScale;//头像宽高比例

#pragma mark - =======Public 对外接口=========

- (void)setDate:(NSString *)date;
- (void)setCollect:(BOOL)collect;
- (void)setNeedLogin:(BOOL)needLogin;
- (void)setPoster:(NSString *)poster;
- (void)setPosterIcon:(NSURL *)posterIcon;
- (void)setClickCollectBlock:(dispatch_block_t)clickCollectBlock;
/**
 设置右侧按钮选中状态、一般状态下的图片、标题 按钮样式 标题+图片

 @param selectedTitle 选中标题
 @param normalTitle 一般标题
 @param selectedImage 选中图片
 @param normalImage 一般图片
 */
- (void)setSelectedTitle:(NSString *)selectedTitle
             normalTitle:(NSString *)normalTitle
           selectedImage:(NSString *)selectedImage
             normalImage:(NSString *)normalImage;

/**
 设置右侧按钮选中状态、一般状态下的标题 只有标题

 @param selectedTitle 选中标题
 @param normalTitle 一般标题
 */
- (void)setSelectedTitle:(NSString *)selectedTitle
             normalTitle:(NSString *)normalTitle;
@end
