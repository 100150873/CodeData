//
//  ZCTakerSelfCell.m
//  GTTemplateAPP
//
//  Created by yixin on 2018/3/9.
//  Copyright © 2018年 GZC. All rights reserved.
//

#import "ZCTakerSelfCell.h"
#import "ZCLookDetailView.h"

@interface ZCTakerSelfCell ()

@property(nonatomic,strong)UILabel *labelStatic;
@property(nonatomic,strong)UIButton *buttonStatus;
@property(nonatomic,strong)ZCLookDetailView *viewDetail;
@property(nonatomic,copy)dispatch_block_t clickBtnBlock;
@property(nonatomic,copy)dispatch_block_t clickNextBlock;

@end

@implementation ZCTakerSelfCell

- (void)setup
{
    [super setup];
    [self addSubview:self.labelStatic];
    [self addSubview:self.buttonStatus];
    [self addSubview:self.viewDetail];
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    NSInteger margin = ZCHeight(10);
    CGFloat labelH = ZCHeight(20);
    [self.labelStatic mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.mas_centerY).offset(-margin);
        make.left.equalTo(self).offset(margin);
        make.height.equalTo(@(labelH));
    }];
    CGFloat iconWH = ZCHeight(16);
    [self.buttonStatus mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.labelStatic);
        make.right.equalTo(self).offset(- ZCHeight(13));
        make.size.equalTo([NSValue valueWithCGSize:CGSizeMake(iconWH, iconWH)]);
    }];
    
    [self.viewDetail mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.mas_centerY).offset(margin);
        make.right.left.equalTo(self);
        make.height.equalTo(@(labelH));
    }];
}

#pragma mark - =======Action=========
- (void)clickBtn:(UIButton *)button
{
    !_clickBtnBlock ? : _clickBtnBlock();
}

#pragma mark - =======Public Method=========
- (void)setTitle:(NSString *)title
{
    self.labelStatic.text = title;
}

- (void)setSelectedStatus:(BOOL)selectedStatus
{
    self.buttonStatus.selected = selectedStatus;
}

- (void)setSelectedImage:(NSString *)selectedImage normalImage:(NSString *)normalImage
{
    [self.buttonStatus setSelectedImage:selectedImage normalImage:normalImage];
}

- (void)setDetailTitle:(NSString *)detailTitle
{
    self.viewDetail.title = detailTitle;
}

#pragma mark - =======Getter and Setter=========
- (UIButton *)buttonStatus {
    if (!_buttonStatus) {
        _buttonStatus = [[UIButton alloc] init];
         [_buttonStatus addTarget:self action:@selector(clickBtn:) forControlEvents:UIControlEventTouchDown];
    }
    return _buttonStatus;
}
- (UILabel *)labelStatic
{
    if (!_labelStatic) {
        _labelStatic = [UILabel labelWithFontSize:ZCFont(15) title:@"" textAlignment:NSTextAlignmentLeft titleColor:ZCColorMainTitle];
    }
    return _labelStatic;
}
- (ZCLookDetailView *)viewDetail
{
    if (!_viewDetail) {
        _viewDetail = [ZCLookDetailView lookDetailViewWithFrame:CGRectZero type:ZCAccessoryTypeDisclosureIndicator];
        _viewDetail.rightImage = @"accessory_indicator_icon";
        ZCWeakSelf;
        _viewDetail.clickMoreBlock = ^{
            !weakSelf.clickNextBlock ? : weakSelf.clickNextBlock();
        };
    }
    return _viewDetail;
}

@end
