//
//  ZCTakerSelfCell.h
//  GTTemplateAPP
//
//  Created by yixin on 2018/3/9.
//  Copyright © 2018年 GZC. All rights reserved.
//

#import "ZCBaseTableViewCell.h"

@interface ZCTakerSelfCell : ZCBaseTableViewCell

- (void)setTitle:(NSString *)title;
- (void)setSelectedStatus:(BOOL)selectedStatus;
- (void)setDetailTitle:(NSString *)detailTitle;
- (void)setClickBtnBlock:(dispatch_block_t)clickBtnBlock;
- (void)setClickNextBlock:(dispatch_block_t)clickNextBlock;
- (void)setSelectedImage:(NSString *)selectedImage
             normalImage:(NSString *)normalImage;

@end
