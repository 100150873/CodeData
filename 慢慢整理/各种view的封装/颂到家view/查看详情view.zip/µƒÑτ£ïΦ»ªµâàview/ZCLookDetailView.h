//
//  ZCLookDetailView.h
//  GTTemplateAPP
//
//  Created by yixin on 2017/5/22.
//  Copyright © 2017年 GZC. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef NS_ENUM(NSInteger, ZCViewAccessoryType) {
    ZCAccessoryTypeNone,                   // 没有右边的箭头
    ZCAccessoryTypeDisclosureIndicator,    // 有右边的箭头
};
@interface ZCLookDetailView : UIView

PropertyString(title);
PropertyString(subTitle);
@property(nonatomic,strong)UIColor *colorSubTitle;

- (void)setClickMoreBlock:(dispatch_block_t)clickMoreBlock;
- (void)setLeftFont:(UIFont *)leftFont rightFont:(UIFont *)rightFont;
- (void)setLeftColor:(UIColor *)leftColor rightColor:(UIColor *)rightColor;

+ (instancetype)lookDetailViewWithFrame:(CGRect)frame
                                   type:(ZCViewAccessoryType)type;
@end
