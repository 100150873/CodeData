//
//  ZCLookDetailView.m
//  GTTemplateAPP
//
//  Created by yixin on 2017/5/22.
//  Copyright © 2017年 GZC. All rights reserved.
//

#import "ZCLookDetailView.h"

@interface ZCLookDetailView ()

@property(nonatomic,strong)UILabel *labelDetail;
@property(nonatomic,strong)UILabel *labelGoodInfo;
@property(nonatomic,assign)ZCViewAccessoryType type;
/**
 点击更多的回调
 */
@property(nonatomic,copy)dispatch_block_t clickMoreBlock;
@property(nonatomic,strong)UIImageView *imageViewAccessary;
@end

@implementation ZCLookDetailView

#pragma mark - =======Over Write=========

- (void)setTitle:(NSString *)title
{
    self.labelGoodInfo.text = title;
}

- (void)setSubTitle:(NSString *)subTitle
{
    self.labelDetail.text = subTitle;
}

- (void)setColorSubTitle:(UIColor *)colorSubTitle
{
    self.labelDetail.textColor = colorSubTitle;
}


#pragma mark - =======Public Method=========
+ (instancetype)lookDetailViewWithFrame:(CGRect)frame
                                   type:(ZCViewAccessoryType)type
{
    ZCLookDetailView *lookDetailView = [[ZCLookDetailView alloc] initWithFrame:frame];
    [lookDetailView addTapAction];
    lookDetailView.type = type;
    return lookDetailView;
}

- (void)addTapAction
{
    [self jk_addTapActionWithBlock:^(UIGestureRecognizer *gestureRecoginzer) {
        !_clickMoreBlock ? : _clickMoreBlock();
    }];
}

- (void)setLeftFont:(UIFont *)leftFont rightFont:(UIFont *)rightFont
{
    if (leftFont) self.labelGoodInfo.font = leftFont;
    if (rightFont) self.labelDetail.font = rightFont;
}
- (void)setLeftColor:(UIColor *)leftColor rightColor:(UIColor *)rightColor
{
    if (leftColor) self.labelGoodInfo.textColor = leftColor;
    if (rightColor) self.labelDetail.textColor = rightColor;
}

#pragma mark - =======Getter and Setter=========
- (UIImageView *)imageViewAccessary
{
    if (!_imageViewAccessary) {
        _imageViewAccessary = [UIImageView imageViewWithImageName:@"accessory_w_icon"];
        [self addSubview:_imageViewAccessary];
        [_imageViewAccessary mas_makeConstraints:^(MASConstraintMaker *make) {
            make.centerY.equalTo(self);
            make.right.equalTo(self).offset(- ZCSpaceConst_10);
            make.height.equalTo(@12.5);
            make.width.equalTo(@6.5);
        }];
    }
    return _imageViewAccessary;
}

- (UILabel *)labelDetail
{
    if (!_labelDetail) {
        _labelDetail = [UILabel labelWithFontSize:ZCFont_14_GeneralText title:@"" textAlignment:NSTextAlignmentRight titleColor:ZCColorMain];
         [self addSubview:_labelDetail];
        
        [_labelDetail mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self);
            if (self.type == ZCAccessoryTypeNone) {
                make.right.equalTo(self).offset(- ZCSpaceConst_10);
            }else{
                make.right.equalTo(self.imageViewAccessary.mas_left).offset(- ZCSpaceConst_5);
            }
            make.width.equalTo(@120);
            make.bottom.equalTo(self);
        }];
    }
    return _labelDetail;
}

- (UILabel *)labelGoodInfo
{
    if (!_labelGoodInfo) {
        _labelGoodInfo = [UILabel labelWithFontSize:ZCFont_14_GeneralText title:@"" textAlignment:NSTextAlignmentLeft titleColor:ZCColorSubTitle];
        [self addSubview:_labelGoodInfo];
        [_labelGoodInfo mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self);
            make.left.equalTo(self).offset(ZCSpaceConst_10);
            make.right.equalTo(self.labelDetail.mas_right);
            make.bottom.equalTo(self);
        }];
    }
    return _labelGoodInfo;
}

@end
