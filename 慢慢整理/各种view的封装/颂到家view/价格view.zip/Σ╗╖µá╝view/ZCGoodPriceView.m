//
//  ZCGoodPriceView.m
//  GTTemplateAPP
//
//  Created by yixin on 2017/5/22.
//  Copyright © 2017年 GZC. All rights reserved.
//

#import "ZCGoodPriceView.h"

@interface ZCViewNotice : UIView

@property(nonatomic,strong)UIImageView *imageVRight;
@property(nonatomic,strong)UILabel *labelLeft,*labelRight;

+ (ZCViewNotice *)viewNoticeWithFrame:(CGRect)frame
                            leftTitle:(NSString *)leftTitle
                           rightTitle:(NSString *)rightTitle
                            imageName:(NSString *)imageName;
@end
@implementation ZCViewNotice
+ (ZCViewNotice *)viewNoticeWithFrame:(CGRect)frame
                            leftTitle:(NSString *)leftTitle
                           rightTitle:(NSString *)rightTitle
                            imageName:(NSString *)imageName
{
    ZCViewNotice *viewNotice = [[ZCViewNotice alloc] initWithFrame:frame];
    [viewNotice setLeftTitle:leftTitle rightTitle:rightTitle imageName:imageName];
    return viewNotice;
}
- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self addSubviews];
    }
    return self;
}
- (void)addSubviews
{
    [self addSubview:self.labelLeft];
    [self addSubview:self.labelRight];
    [self addSubview:self.imageVRight];
}
- (void)layoutSubviews
{
    [super layoutSubviews];
    CGFloat margin = ZCHeight(10);
    [self.labelLeft mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self);
        make.bottom.equalTo(self);
        make.left.equalTo(self).offset(margin);
    }];
    [self.imageVRight mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self);
        make.right.equalTo(self).offset(-margin);
        if (!self.imageVRight.image) {//没有图片
            make.width.equalTo(@0);
        }
        //        make.size.equalTo([NSValue valueWithCGSize:CGSizeMake(<#width#>, <#height#>)]);
    }];
    [self.labelRight mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self);
        make.bottom.equalTo(self);
        make.right.equalTo(self.imageVRight.mas_left).offset(- margin);
    }];
}
- (void)setLeftTitle:(NSString *)leftTitle
          rightTitle:(NSString *)rightTitle
           imageName:(NSString *)imageName
{
    self.labelLeft.text = leftTitle;
    self.labelRight.text = rightTitle;
    if ([imageName isNotBlank]) {
        [self.imageVRight setImage:ZCImageNamed(imageName)];
    }
}
#pragma mark - =======Getter=========
- (UILabel *)labelLeft
{
    if (!_labelLeft) {
        _labelLeft = [UILabel labelWithFontSize:ZCFont(15) title:@"" textAlignment:NSTextAlignmentLeft titleColor:ZCColorSubBtn];
    }
    return _labelLeft;
}
- (UILabel *)labelRight
{
    if (!_labelRight) {
        _labelRight = [UILabel labelWithFontSize:ZCFont(15) title:@"" textAlignment:NSTextAlignmentRight titleColor:ZCColorSubBtn];
    }
    return _labelRight;
}
- (UIImageView *)imageVRight
{
    if (!_imageVRight) {
        _imageVRight = [[UIImageView alloc] init];
    }
    return _imageVRight;
}
@end

@interface ZCGoodPriceView ()
@property(nonatomic,strong)NSMutableArray *arraryTemp;
@end

@implementation ZCGoodPriceView

#pragma mark - =======Public Method=========
- (void)setItemWithIndex:(NSInteger)itemIndex
               LeftColor:(UIColor *)leftColor
              rightColor:(UIColor *)rightColor
{
    if (itemIndex >= self.arraryTemp.count) {
        [SVProgressHUD showErrorWithStatus:@"数组越界了！"];
        return;
    }
    ZCViewNotice *viewTemp = self.arraryTemp[itemIndex];
    if (leftColor) {
        viewTemp.labelLeft.textColor = leftColor;
    }
    if (rightColor) {
        viewTemp.labelRight.textColor = rightColor;
    }
}
- (void)setLeftContentData:(NSArray *)arrayLeft rightContentData:(NSArray *)arrayRight
{
    if (arrayLeft.count != arrayRight.count) {
        [SVProgressHUD showErrorWithStatus:@"两边个数不相等！"];
        return;
    }
    for (NSInteger i = 0; i < arrayLeft.count; i ++) {
        ZCViewNotice *viewTemp = [ZCViewNotice viewNoticeWithFrame:CGRectMake(0, 100, SCREEN_WIDTH, ZCNomalLableHeight) leftTitle:arrayLeft[i] rightTitle:arrayRight[i] imageName:nil];
        [self addSubview:viewTemp];
        [viewTemp mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self).offset(i * ZCNomalLableHeight);
            make.left.equalTo(self);
            make.right.equalTo(self);
            make.height.equalTo(@(ZCNomalLableHeight));
        }];
        [self.arraryTemp addObject:viewTemp];
    }
}

/**
 设置左边内容数据
 
 @param arrayLeft 左边的数据源
 */
- (void)setLeftContentData:(NSArray *)arrayLeft
{
    if (arrayLeft.count == 0) return;
    for (NSInteger i = 0; i < arrayLeft.count; i ++) {
        ZCViewNotice *viewTemp = [ZCViewNotice viewNoticeWithFrame:CGRectMake(0, 100, SCREEN_WIDTH, ZCNomalLableHeight) leftTitle:arrayLeft[i] rightTitle:nil imageName:nil];
        [self addSubview:viewTemp];
        [viewTemp mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self).offset(i * ZCNomalLableHeight);
            make.left.equalTo(self);
            make.right.equalTo(self);
            make.height.equalTo(@(ZCNomalLableHeight));
        }];
        [self.arraryTemp addObject:viewTemp];
    }
}

#pragma mark - =======Getter and Setter=========
- (NSMutableArray *)arraryTemp
{
    if (!_arraryTemp) {
        _arraryTemp = [[NSMutableArray alloc] init];
    }
    return _arraryTemp;
}
@end

