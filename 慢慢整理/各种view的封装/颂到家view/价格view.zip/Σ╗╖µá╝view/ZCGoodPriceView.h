//
//  ZCGoodPriceView.h
//  GTTemplateAPP
//
//  Created by yixin on 2017/5/22.
//  Copyright © 2017年 GZC. All rights reserved.
//
/**************************************************************
 Description:
专门做的下面的样式的view的封装  最左边一个label  右边一个label和icon
商品总额：        259.00
运费：             9.00
应付金额：        259.00
 或者
选择代金券进行抵扣        >(这种样式)
 ******************************************************************/
#import <UIKit/UIKit.h>

@interface ZCGoodPriceView : UIView
/**
 设置左边和右边显示的内容数据
 
 @param arrayLeft 左边的数据源
 @param arrayRight 右边的数据源
 */
- (void)setLeftContentData:(NSArray *)arrayLeft rightContentData:(NSArray *)arrayRight;
/**
 设置左边内容数据

 @param arrayLeft 左边的数据源
 */
- (void)setLeftContentData:(NSArray *)arrayLeft;
/**
 设置第index个Item左边、右边label的字体颜色
 
 @param itemIndex 要设置的item的在数组中的下标
 @param leftColor 左边label字体颜色 不设置时置为nil
 @param rightColor 右边label自提颜色 不设置时置为nil
 */
- (void)setItemWithIndex:(NSInteger)itemIndex
               LeftColor:(UIColor *)leftColor
              rightColor:(UIColor *)rightColor;

@end

