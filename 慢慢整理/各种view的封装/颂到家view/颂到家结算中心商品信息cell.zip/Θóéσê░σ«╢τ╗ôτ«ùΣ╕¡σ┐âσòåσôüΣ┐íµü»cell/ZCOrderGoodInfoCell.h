//
//  ZCOrderGoodInfoCell.h
//  GTTemplateAPP
//
//  Created by yixin on 2018/3/5.
//  Copyright © 2018年 GZC. All rights reserved.
//

#import "ZCBaseTableViewCell.h"

@interface ZCOrderGoodInfoCell : ZCBaseTableViewCell

- (void)setGoodIcon:(NSURL *)goodIcon;
- (void)setGoodName:(NSString *)goodName;
- (void)setGoodPrice:(NSString *)goodPrice;
- (void)setGoodCount:(NSString *)goodCount;
@end
