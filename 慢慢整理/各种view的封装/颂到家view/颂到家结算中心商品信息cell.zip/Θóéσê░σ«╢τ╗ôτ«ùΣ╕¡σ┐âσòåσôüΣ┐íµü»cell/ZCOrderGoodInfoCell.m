//
//  ZCOrderGoodInfoCell.m
//  GTTemplateAPP
//
//  Created by yixin on 2018/3/5.
//  Copyright © 2018年 GZC. All rights reserved.
//

#import "ZCOrderGoodInfoCell.h"
@interface ZCOrderGoodInfoCell ()

@property(nonatomic,strong)UIImageView *imageViewIcon;
@property(nonatomic,strong)UILabel *labelTitle,*labelPrice,*labelCount;
@end
@implementation ZCOrderGoodInfoCell

- (void)setup
{
    [super setup];
    [self addSubview:self.imageViewIcon];
    [self addSubview:self.labelTitle];
    [self addSubview:self.labelPrice];
    [self addSubview:self.labelCount];
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    CGFloat margin = ZCHeight(10);
    CGFloat iconWH = ZCHeight(75);
    [self.imageViewIcon mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self).offset(margin);
        make.left.equalTo(self).offset( margin);
        make.height.equalTo(@(iconWH));
        make.width.equalTo(@(iconWH));
    }];
    
    [self.labelTitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.imageViewIcon);
        make.left.equalTo(self.imageViewIcon.mas_right).offset(margin);
        make.right.equalTo(self).offset(- margin);
    }];
    
    [self.labelPrice mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.equalTo(@(ZCNomalLableHeight));
        make.left.equalTo(self.labelTitle);
        make.bottom.equalTo(self.imageViewIcon);
    }];
    
    [self.labelCount mas_makeConstraints:^(MASConstraintMaker *make) {
        make.height.equalTo(@(ZCNomalLableHeight));
        make.right.equalTo(self.labelTitle);
        make.top.equalTo(self.labelPrice);
    }];
}
#pragma mark - =======Public 对外接口=========
- (void)setGoodIcon:(NSURL *)goodIcon
{
    [self.imageViewIcon sd_setImageWithURL:goodIcon];
}
- (void)setGoodName:(NSString *)goodName
{
    self.labelTitle.text = goodName;
}
- (void)setGoodPrice:(NSString *)goodPrice
{
    self.labelPrice.text = goodPrice;
}
- (void)setGoodCount:(NSString *)goodCount
{
    self.labelCount.text = goodCount;
}
#pragma mark - =======Getter=========
- (UIImageView *)imageViewIcon {
    if (!_imageViewIcon) {
        _imageViewIcon = [UIImageView imageViewWithImageName:@""];
        
    }
    return _imageViewIcon;
}

- (UILabel *)labelTitle {
    if (!_labelTitle) {
        _labelTitle = [UILabel labelWithFontSize:ZCFont(16) title:@"" textAlignment:NSTextAlignmentLeft titleColor:ZCColorMainTitle];
        _labelTitle.numberOfLines = 2;
        
    }
    return _labelTitle;
}

- (UILabel *)labelPrice {
    if (!_labelPrice) {
        _labelPrice = [UILabel labelWithFontSize:ZCFont(14) title:@"" textAlignment:NSTextAlignmentLeft titleColor:ZCColorRed];
        
    }
    return _labelPrice;
}

- (UILabel *)labelCount {
    if (!_labelCount) {
        _labelCount = [UILabel labelWithFontSize:ZCFont(14)
                                           title:@""
                                   textAlignment:NSTextAlignmentRight
                                      titleColor:ZCColorSubBtn];
        
    }
    return _labelCount;
}
@end
