//
//  ZCShoppingCarButton.m
//  GTTemplateAPP
//
//  Created by yixin on 2018/3/13.
//  Copyright © 2018年 GZC. All rights reserved.
//

#import "UIButton+JKBadge.h"
#import "ZCShoppingCarButton.h"

@interface ZCShoppingCarButton ()

@end

@implementation ZCShoppingCarButton

#pragma mark - =======Public 对外接口=========

+ (instancetype)shoppingCarButton
{
    ZCShoppingCarButton *btn = [[ZCShoppingCarButton alloc] init];
    btn.jk_badgeValue = @"0";
    btn.jk_shouldAnimateBadge = YES;
    btn.jk_shouldHideBadgeAtZero = YES;
    btn.jk_badgeOriginX = -2;
    btn.jk_badgeOriginY = -2;
    btn.jk_badgePadding = 2;
    btn.jk_badgeMinSize = 10;
    btn.jk_badgeBGColor = ZCColorRed;
    btn.jk_badgeTextColor = ZCColorWhite;
    return btn;
}

- (void)setGoodsNum:(NSInteger)goodsNum
{
    self.jk_badgeValue = ZCString(@"%ld",goodsNum);
}
- (void)setShoppingCarImage:(NSString *)shoppingCarImage
{
    [self setImage:ZCImageNamed(shoppingCarImage) forState:UIControlStateNormal];
}

@end
