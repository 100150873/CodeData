//
//  ZCTakeSelfSearchView.m
//  GTTemplateAPP
//
//  Created by ham on 2018/1/26.
//  Copyright © 2018年 GZC. All rights reserved.
//


#import "ZCTakeSelfSearchView.h"
#import "NSObject+WHC_Extension.h"
@interface ZCTakeSelfSearchView ()<UISearchBarDelegate>

@property (nonatomic, strong) UIButton *backBtn;
/**
 白色背景搜索框view
 */
@property(nonatomic,strong)UIView *viewSearchBG;
@property (nonatomic, strong) UISearchBar *searchBar;
@property(nonatomic,copy)dispatch_block_t clickBackBlock;
@property(nonatomic,copy)dispatch_block_t clickRightBlock;
@property(nonatomic,copy)dispatch_block_t clickSearchBlock;
@property(nonatomic,strong)UIView *viewNavBG,*viewStatusBG;
@property(nonatomic,strong)ZCShoppingCarButton *buttonRight;
@end
@implementation ZCTakeSelfSearchView

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self addSubviews];
    }
    return self;
}

- (void)addSubviews
{
    //最底部的两个
    [self addSubview:self.viewStatusBG];
    [self addSubview:self.viewNavBG];
    
    [self.viewNavBG addSubview:self.backBtn];
    [self.viewNavBG addSubview:self.searchBar];
    [self.viewNavBG addSubview:self.buttonRight];
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    [self.viewStatusBG mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.top.equalTo(self);
        make.height.mas_equalTo(ZCStatusBarHeight);
    }];
    NSInteger navH = 44;
    [self.viewNavBG mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.viewStatusBG.mas_bottom);
        make.right.left.equalTo(self);
        make.height.mas_equalTo(navH);
    }];
    
    
    CGFloat margin = ZCHeight(10);
    [self.backBtn mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.viewNavBG);
        make.left.equalTo(self.viewNavBG).offset(margin);
        make.width.mas_equalTo(ZCHeight(30));
    }];
    [self.searchBar mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.viewNavBG);
        make.centerX.equalTo(self.viewNavBG).offset(ZCHeight(10));
        make.height.mas_equalTo(navH * 0.75);
        make.width.mas_equalTo(SCREEN_WIDTH * 0.6);
    }];
    [self.buttonRight mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.viewNavBG);
        make.right.equalTo(self.viewNavBG).offset(- margin);
        make.height.width.mas_equalTo(ZCHeight(30));
    }];
}

#pragma mark - =======Public 对外接口=========
/**
 设置搜索框的背景色
 
 @param backGColor 背景色
 */
- (void)setSearchViewBackGColor:(UIColor *)backGColor
{
    self.viewNavBG.backgroundColor = backGColor;
    self.viewStatusBG.backgroundColor = backGColor;
}

- (void)setPlaceholder:(NSString *)placeholder
{
    self.searchBar.placeholder = placeholder;
}

#pragma mark - =======Action=========
- (void)clickBackButton:(UIButton *)btn
{
    !_clickBackBlock ? : _clickBackBlock();
}
- (void)clickRightButton:(UIButton *)btn
{
    !_clickRightBlock ? : _clickRightBlock();
}
#pragma mark - =======Getter=========
- (UIButton *)backBtn {
    if (!_backBtn) {
        _backBtn = [UIButton buttonWithImageName:@"newBack"];
         [_backBtn addTarget:self action:@selector(clickBackButton:) forControlEvents:UIControlEventTouchDown];
    }
    return _backBtn;
}
//- (UIButton *)buttonRight
//{
//    if (!_buttonRight) {
//        _buttonRight = [UIButton buttonWithImageName:@"car_btn_icon"];
//        [_buttonRight addTarget:self action:@selector(clickRightButton:) forControlEvents:UIControlEventTouchDown];
//        _buttonRight.jk_badgeValue = @"0";
//        _buttonRight.jk_shouldAnimateBadge = YES;
//        _buttonRight.jk_shouldHideBadgeAtZero = YES;
//        _buttonRight.jk_badgeOriginX = 0;
//        _buttonRight.jk_badgeOriginY = 0;
//        _buttonRight.jk_badgePadding = 0.2;
//        _buttonRight.jk_badgeMinSize = 8;
//        _buttonRight.jk_badgeBGColor = ZCColorMain;
//        _buttonRight.jk_badgeTextColor = ZCColorRed;
//    }
//    return _buttonRight;
//}

- (ZCShoppingCarButton *)buttonRight
{
    if (!_buttonRight) {
        _buttonRight = [ZCShoppingCarButton shoppingCarButton];
        _buttonRight.shoppingCarImage = @"car_btn_icon";
        _buttonRight.goodsNum = [ZCShoppingCartNumManager shoppingCartNumberWithType:ZCShoppingCartCommonNumber];
    }
    return _buttonRight;
}

- (UISearchBar *)searchBar {
    if (!_searchBar) {
        _searchBar = [UISearchBar new];
        _searchBar.backgroundColor = ZCColorWhite;
        for (UIView *view in _searchBar.subviews) {
            if ([view isKindOfClass:NSClassFromString(@"UIView")] &&view.subviews.count>0) {
                view.backgroundColor = ZCColorWhite;
                [[view.subviews objectAtIndex:0] removeFromSuperview];
                break;
            }
        }
        _searchBar.delegate = self;
        _searchBar.layer.cornerRadius = 15;
        _searchBar.clipsToBounds = YES;
    }
    return _searchBar;
}
- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar
{
    !_clickSearchBlock ? : _clickSearchBlock();
    return NO;
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    self.text = searchBar.text.length > 0 ? searchBar.text : @"";
    [searchBar resignFirstResponder];
}

- (UIView *)viewStatusBG
{
    if (!_viewStatusBG) {
        _viewStatusBG = [[UIView alloc] init];
        _viewStatusBG.backgroundColor = [UIColor clearColor];
    }
    return _viewStatusBG;
}

- (UIView *)viewNavBG
{
    if (!_viewNavBG) {
        _viewNavBG = [[UIView alloc] init];
        _viewNavBG.backgroundColor = [UIColor clearColor];
    }
    return _viewNavBG;
}
@end
