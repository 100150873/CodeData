//
//  ZCTakeSelfSearchView.h
//  GTTemplateAPP
//
//  Created by ham on 2018/1/26.
//  Copyright © 2018年 GZC. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "UIButton+JKBadge.h"
#import "ZCShoppingCarButton.h"

@interface ZCTakeSelfSearchView : UIView

@property (nonatomic, strong) NSString *text;


- (void)setPlaceholder:(NSString *)placeholder;
- (ZCShoppingCarButton *)buttonRight;
/**
 设置搜索框的背景色

 @param backGColor 背景色
 */
- (void)setSearchViewBackGColor:(UIColor *)backGColor;

- (void)setClickBackBlock:(dispatch_block_t)clickBackBlock;
- (void)setClickRightBlock:(dispatch_block_t)clickRightBlock;
/**
 点击了搜索框的回调

 @param clickSearchBlock <#clickSearchBlock description#>
 */
- (void)setClickSearchBlock:(dispatch_block_t)clickSearchBlock;
@end
