//
//  ZCShoppingCarButton.h
//  GTTemplateAPP
//
//  Created by yixin on 2018/3/13.
//  Copyright © 2018年 GZC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZCShoppingCarButton : UIButton

+ (instancetype)shoppingCarButton;
- (void)setGoodsNum:(NSInteger)goodsNum;
- (void)setShoppingCarImage:(NSString *)shoppingCarImage;
@end
