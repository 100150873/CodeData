//
//  ZCTopicButtonView.m
//  GTTemplateAPP
//
//  Created by yixin on 2018/2/27.
//  Copyright © 2018年 GZC. All rights reserved.
//

#import "ZCTopicButtonView.h"
@interface ZCTopicButtonView ()

@property(nonatomic,strong)UIImageView *imageV;
@property(nonatomic,strong)UILabel *labelTitle;
@end
@implementation ZCTopicButtonView
+ (instancetype)topicButtonViewWithTitle:(NSString *)title imageUrl:(NSString *)imageUrl
{
    ZCTopicButtonView * button = [[ZCTopicButtonView alloc] init];
    [button setTitle:title imageUrl:imageUrl];
    return button;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self addSubview:self.imageV];
        [self addSubview:self.labelTitle];
    }
    return self;
}

- (void)setTitle:(NSString *)title imageUrl:(NSString *)imageUrl
{
    [self.imageV sd_setImageWithURL:ZCURLWithString(imageUrl)];
    self.labelTitle.text = title;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    self.imageV.frame = self.bounds;
    self.labelTitle.frame = CGRectMake(0, self.height * 4 / 5, self.width, self.height / 5);
}

- (UIImageView *)imageV
{
    if (!_imageV) {
        _imageV = [[UIImageView alloc] init];
        _imageV.contentMode = UIViewContentModeScaleAspectFit;
    }
    return _imageV;
}
- (UILabel *)labelTitle
{
    if (!_labelTitle) {
        _labelTitle = [UILabel labelWithFontSize:ZCFont(13) title:@"" textAlignment:NSTextAlignmentLeft titleColor:ZCColorWhite];
        _labelTitle.backgroundColor = [[UIColor blackColor]colorWithAlphaComponent:0.3f];
    }
    return _labelTitle;
}
@end
