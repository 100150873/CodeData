//
//  ZCTopicButtonView.h
//  GTTemplateAPP
//
//  Created by yixin on 2018/2/27.
//  Copyright © 2018年 GZC. All rights reserved.
//

#import <UIKit/UIKit.h>
/**************************************************************
 Description:
 社区模块 热门话题 自定义的button
 层级结构
 ZCTopicButtonView
 │
 └── UIImageView
 │
 ├── UILabel
 ******************************************************************/
@interface ZCTopicButtonView : UIButton

/**
 初始化 自定义按钮

 @param title 标题
 @param imageUrl 图片地址
 @return 实例对象
 */
+ (instancetype)topicButtonViewWithTitle:(NSString *)title imageUrl:(NSString *)imageUrl;

- (void)setTitle:(NSString *)title imageUrl:(NSString *)imageUrl;
@end
