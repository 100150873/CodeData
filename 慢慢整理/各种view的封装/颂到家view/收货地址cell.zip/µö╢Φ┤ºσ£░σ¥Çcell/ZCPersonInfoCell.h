//
//  ZCPersonInfoCell.h
//  GTTemplateAPP
//
//  Created by yixin on 2017/5/17.
//  Copyright © 2017年 GZC. All rights reserved.
//

#import "ZCBaseTableViewCell.h"
#import "ZCSearchShopCell.h"

@interface ZCPersonInfoCell : ZCBaseTableViewCell

/**
 显示右侧指示箭头
 */
- (void)showAccessory;

/**
 详细地址  省市区+详细地址
 
 @param address 省市区+详细地址
 */
- (void)setAddress:(NSString *)address;
/**
 收货人信息
 
 @param takerInfo 电话+名字
 */
- (void)setTakerInfo:(NSString *)takerInfo;

@end
