//
//  ZCPersonInfoCell.m
//  GTTemplateAPP
//
//  Created by yixin on 2017/5/17.
//  Copyright © 2017年 GZC. All rights reserved.
//

#import "ZCPersonInfoCell.h"

@interface ZCPersonInfoCell ()

@property(nonatomic,assign)CGFloat  rightSpace;
@property(nonatomic,strong)UILabel *labelAddress,*labelPerson;
@property(nonatomic,strong)UIImageView *imageAccessory,*imageIcon;
@end
@implementation ZCPersonInfoCell

#pragma mark - =======Init UIView=========
- (void)setup
{
    [super setup];
    self.rightSpace = ZCHeight(10);
    [self addSubview:self.labelPerson];
    [self addSubview:self.imageAccessory];
    [self addSubview:self.imageIcon];
    [self addSubview:self.labelAddress];
    self.labelAddress.numberOfLines = 0;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    CGFloat margin = ZCHeight(10);
    CGFloat iconW = ZCHeight(14);CGFloat iconH = ZCHeight(18);
    [self.imageIcon mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self).offset(margin);
        make.size.equalTo([NSValue valueWithCGSize:CGSizeMake(iconW, iconH)]);
    }];
    
    [@[self.labelPerson,self.labelAddress] mas_distributeViewsAlongAxis:MASAxisTypeVertical withFixedSpacing:0 leadSpacing:margin tailSpacing:margin];
    
    [@[self.labelPerson,self.labelAddress] mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.imageIcon.mas_right).offset(5);
        make.right.equalTo(self).offset(- self.rightSpace);
    }];
    
    
    [self.imageIcon mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.labelAddress);
    }];
}


#pragma mark - =======Public=========
/**
显示右侧指示箭头
 */
- (void)showAccessory
{
    CGFloat accessW = 6.5;
    [self.imageAccessory mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self);
        make.right.equalTo(self).offset(- ZCHeight(10));
        make.height.equalTo(@12.5);
        make.width.equalTo(@(accessW));
    }];
    self.rightSpace += accessW;
    [self layoutIfNeeded];
}

/**
 详细地址  省市区+详细地址
 
 @param address 省市区+详细地址
 */
- (void)setAddress:(NSString *)address
{
    self.labelAddress.text = address;
}
/**
 收货人信息
 
 @param takerInfo 电话+名字
 */
- (void)setTakerInfo:(NSString *)takerInfo
{
    self.labelPerson.text = takerInfo;
}


#pragma mark - =======Getter and Setter=========
- (UILabel *)labelPerson
{
    if (!_labelPerson) {
        _labelPerson = [UILabel labelWithFontSize:kFont_15
                                            title:@""
                                    textAlignment:NSTextAlignmentLeft
                                       titleColor:ZCColorMainTitle];
    }
    return _labelPerson;
}

- (UIImageView *)imageIcon {
    if (!_imageIcon) {
        _imageIcon = [UIImageView imageViewWithImageName:@"shop_adress_icon"];
    }
    return _imageIcon;
}

- (UIImageView *)imageAccessory {
    if (!_imageAccessory) {
        _imageAccessory = [UIImageView imageViewWithImageName:@"accessory_indicator_icon"];
        
    }
    return _imageAccessory;
}

- (UILabel *)labelAddress
{
    if (!_labelAddress) {
        _labelAddress = [UILabel labelWithFontSize:ZCFont(12)
                                              title:@""
                                      textAlignment:NSTextAlignmentLeft
                                         titleColor:ZCColorSubTitle];
        
    }
    return _labelAddress;
}

@end
