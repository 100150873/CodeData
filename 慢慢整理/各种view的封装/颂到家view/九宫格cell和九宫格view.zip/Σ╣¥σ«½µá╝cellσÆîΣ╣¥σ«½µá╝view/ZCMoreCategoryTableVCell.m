//
//  ZCMoreCategoryTableVCell.m
//  GTTemplateAPP
//
//  Created by yixin on 2018/4/11.
//  Copyright © 2018年 GZC. All rights reserved.
//

#import "ZCSudokView.h"
#import "ZCMoreCategoryTableVCell.h"

@interface ZCMoreCategoryTableVCell ()

@property(nonatomic,strong)ZCSudokView *viewSudoku;
@end

@implementation ZCMoreCategoryTableVCell

- (void)setup
{
    [super setup];
    self.separatorInset = UIEdgeInsetsMake(0, SCREEN_HIGHT, 0, 0);
    self.backgroundColor = ZCBackGroudColor;
    [self addSubview:self.viewSudoku];
}
- (void)layoutSubviews
{
    [super layoutSubviews];
    [self.viewSudoku mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self).insets(UIEdgeInsetsMake(0,0,10,0));
    }];
}
#pragma mark - =======Public=========

- (void)setClickFuncBlock:(void (^)(NSInteger index))clickFuncBlock
{
    self.viewSudoku.clickFuncBlock = clickFuncBlock;
}

/**
 每行 item 的个数，默认为4个
 
 @param rowCount 个数
 */
- (void)setRowCount:(NSInteger)rowCount
{
    self.viewSudoku.rowCount = rowCount;
}
/**
 item：高度
 
 @param itemHeight 高度
 */
- (void)setItemHeight:(CGFloat)itemHeight
{
    self.viewSudoku.itemHeight = itemHeight;
}
- (void)setupWithTitles:(NSArray *)titles imageUrls:(NSArray *)imageUrls
{
    [self.viewSudoku setupWithTitles:titles imageUrls:imageUrls];
}

#pragma mark - =======Getter=========
- (ZCSudokView *)viewSudoku
{
    if (!_viewSudoku) {
        _viewSudoku = [ZCSudokView sudokuView];
        _viewSudoku.rowCount = 4;
        _viewSudoku.itemHeight = ZCHeight(120);
    }
    return _viewSudoku;
}
@end
