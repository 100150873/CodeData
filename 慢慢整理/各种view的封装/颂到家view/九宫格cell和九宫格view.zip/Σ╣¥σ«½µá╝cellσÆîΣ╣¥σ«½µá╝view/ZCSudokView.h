//
//  ZCSudokView.h
//  GTTemplateAPP
//
//  Created by yixin on 2018/4/11.
//  Copyright © 2018年 GZC. All rights reserved.
//

#import <UIKit/UIKit.h>
/**************************************************************
 Description:
 九宫格view
 ******************************************************************/
@interface ZCSudokView : UIView

+ (instancetype)sudokuView;

/**
 每行 item 的个数，默认为4个
 
 @param rowCount 个数
 */
- (void)setRowCount:(NSInteger)rowCount;
/**
 item：高度
 
 @param itemHeight 高度
 */
- (void)setItemHeight:(CGFloat)itemHeight;
- (void)setClickFuncBlock:(void (^)(NSInteger index))clickFuncBlock;
- (void)setupWithTitles:(NSArray *)titles imageUrls:(NSArray *)imageUrls;
@end
