//
//  ZCMoreCategoryTableVCell.h
//  GTTemplateAPP
//
//  Created by yixin on 2018/4/11.
//  Copyright © 2018年 GZC. All rights reserved.
//

/**************************************************************
 Description:
 九宫格样式的TableViewCell
 ******************************************************************/

#import "ZCBaseTableViewCell.h"

@interface ZCMoreCategoryTableVCell : ZCBaseTableViewCell


/**
 每行 item 的个数，默认为4个
 
 @param rowCount 个数
 */
- (void)setRowCount:(NSInteger)rowCount;
/**
 item：高度
 
 @param itemHeight 高度
 */
- (void)setItemHeight:(CGFloat)itemHeight;
- (void)setClickFuncBlock:(void (^)(NSInteger index))clickFuncBlock;
- (void)setupWithTitles:(NSArray *)titles imageUrls:(NSArray *)imageUrls;

@end
