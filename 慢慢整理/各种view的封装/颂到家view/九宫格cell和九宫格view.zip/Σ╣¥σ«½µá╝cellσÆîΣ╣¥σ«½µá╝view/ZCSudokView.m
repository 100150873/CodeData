//
//  ZCSudokView.m
//  GTTemplateAPP
//
//  Created by yixin on 2018/4/11.
//  Copyright © 2018年 GZC. All rights reserved.
//
#import "BAGridView.h"
#import "ZCSudokView.h"
#import "BAGridItemModel.h"

@interface ZCSudokView ()

@property(nonatomic,strong)BAGridView *gridView;
@property(nonatomic,copy)void (^clickFuncBlock)(NSInteger index);
@end

@implementation ZCSudokView

+ (instancetype)sudokuView
{
    return [[self alloc] init];
}

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self addSubview:self.gridView];
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    [self.gridView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self);
    }];
}

#pragma mark - =======Public=========

- (void)setupWithTitles:(NSArray *)titles imageUrls:(NSArray *)imageUrls
{
    NSMutableArray *arrayModel = [[NSMutableArray alloc] init];
    for (NSInteger i = 0; i < titles.count ; i ++) {
        BAGridItemModel *model = [[BAGridItemModel alloc] init];
        model.imageName = imageUrls[i];
        model.titleString = titles[i];
        [arrayModel addObject:model];
    }
    self.gridView.dataArray = arrayModel;
}


/**
 每行 item 的个数，默认为4个

 @param rowCount 个数
 */
- (void)setRowCount:(NSInteger)rowCount
{
    self.gridView.ba_gridView_rowCount = rowCount;
}

/**
 item：高度

 @param itemHeight 高度
 */
- (void)setItemHeight:(CGFloat)itemHeight
{
    self.gridView.ba_gridView_itemHeight = itemHeight;
}

#pragma mark - =======Getter=========
- (BAGridView *)gridView
{
    if (!_gridView)
    {
        _gridView = [BAGridView ba_creatGridViewWithGridViewType:BAGridViewTypeImageTitle dataArray:@[] configurationBlock:^(BAGridView *tempView) {
            
            tempView.ba_gridView_titleFont = ZCFont(14);
            tempView.ba_gridView_titleColor = ZCColorMainTitle;
            
            
        } block:^(BAGridItemModel *model, NSIndexPath *indexPath) {
            
            ! _clickFuncBlock  ? : _clickFuncBlock(indexPath.row);
            
        }];
        _gridView.backgroundColor = ZCColorWhite;
    }
    return _gridView;
}
@end
