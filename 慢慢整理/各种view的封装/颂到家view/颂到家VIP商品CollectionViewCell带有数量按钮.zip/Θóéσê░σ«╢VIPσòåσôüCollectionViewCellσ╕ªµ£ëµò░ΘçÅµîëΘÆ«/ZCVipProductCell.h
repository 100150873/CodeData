//
//  ZCVipProductCell.h
//  GTTemplateAPP
//
//  Created by yixin on 2017/6/20.
//  Copyright © 2017年 GZC. All rights reserved.
//

#import "PPNumberButton.h"
#import <UIKit/UIKit.h>

@interface ZCVipProductCell : UICollectionViewCell

- (void)setGoodIcon:(NSURL *)goodIcon;
- (void)setGoodName:(NSString *)goodName;
- (void)setLabelCountHidden:(BOOL)labelCountHidden;
- (void)setGoodCount:(NSString *)goodCount;
- (void)setGoodPrice:(NSString *)goodPrice;

@property(nonatomic,strong)PPNumberButton *buttonNumber;
@end
