//
//  ZCVipProductCell.m
//  GTTemplateAPP
//
//  Created by yixin on 2017/6/20.
//  Copyright © 2017年 GZC. All rights reserved.
//

#import "ZCVipProductCell.h"

@interface ZCVipProductCell ()

@property(nonatomic,strong)UIImageView *imageIcon;
@property(nonatomic,strong)UILabel *labelTitle,*labelCount,*labelPrice;

@end

@implementation ZCVipProductCell

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        [self addSubview:self.imageIcon];
        [self addSubview:self.labelTitle];
        [self addSubview:self.labelCount];
        [self addSubview:self.labelPrice];
        [self addSubview:self.buttonNumber];
        self.backgroundColor = ZCColorWhite;
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    NSInteger margin = ZCHeight(10);
    CGFloat itemH = self.width;
    [self.imageIcon mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.top.equalTo(self);
        make.height.equalTo(@(itemH));
    }];
    
    CGFloat labelH = ZCHeight(25);
    [self.labelTitle mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.imageIcon.mas_bottom).offset(margin);
        make.left.equalTo(self).offset(margin);
        make.right.equalTo(self).offset(- margin);
        make.height.equalTo(@(labelH));
    }];
    
    [self.labelCount mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.labelTitle.mas_bottom);
        make.left.equalTo(self.labelTitle);
        make.height.equalTo(@(labelH));
    }];
    
    [self.labelPrice mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.labelCount.mas_bottom);
        make.left.equalTo(self.labelTitle);
        make.height.equalTo(@(labelH));
    }];
    
    CGFloat btnW = ZCHeight(70);CGFloat btnH = ZCHeight(20);
    [self.buttonNumber mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.labelCount.mas_bottom);
        make.right.equalTo(self).offset(- margin);
        make.size.equalTo([NSValue valueWithCGSize:CGSizeMake(btnW, btnH)]);
    }];
}
#pragma mark - =======Over Write=========
- (void)setGoodIcon:(NSURL *)goodIcon
{
    [self.imageIcon sd_setImageWithURL:goodIcon];
}
- (void)setGoodName:(NSString *)goodName
{
    self.labelTitle.text = goodName;
}
- (void)setLabelCountHidden:(BOOL)labelCountHidden
{
    self.labelCount.hidden = labelCountHidden;
}
- (void)setGoodCount:(NSString *)goodCount
{
    self.labelCount.text = goodCount;
}
- (void)setGoodPrice:(NSString *)goodPrice
{
    self.labelPrice.text = goodPrice;
}

#pragma mark - =======Getter=========

- (UIImageView *)imageIcon {
    if (!_imageIcon) {
        _imageIcon = [UIImageView imageViewWithImageName:@""];
    }
    return _imageIcon;
}

- (UILabel *)labelTitle {
    if (!_labelTitle) {
        _labelTitle = [UILabel
                       labelWithFontSize:kFont_15
                       title:@""
                       textAlignment:NSTextAlignmentLeft
                       titleColor:ZCColorMainTitle];
    }
    return _labelTitle;
}

- (UILabel *)labelPrice {
    if (!_labelPrice) {
        _labelPrice = [UILabel
                          labelWithFontSize:ZCFont_14_GeneralText
                          title:@""
                          textAlignment:NSTextAlignmentLeft
                          titleColor:ZCColorRed];
    }
    return _labelPrice;
}

- (UILabel *)labelCount {
    if (!_labelCount) {
        _labelCount = [UILabel
                       labelWithFontSize:ZCFont_12_DescritionText
                       title:@""
                       textAlignment:NSTextAlignmentLeft
                       titleColor:ZCColorSubBtn];
    }
    return _labelCount;
}

- (PPNumberButton *)buttonNumber {
    if (!_buttonNumber) {
        _buttonNumber = [[PPNumberButton alloc] init];
        // 开启抖动动画
        _buttonNumber.shakeAnimation = YES;
        // 设置最小值
        _buttonNumber.minValue = 0;
        // 设置输入框中的字体大小
        _buttonNumber.inputFieldFont = 15;
        _buttonNumber.borderColor = ZCColorSeperate;
        _buttonNumber.increaseTitle = @"＋";
        _buttonNumber.decreaseTitle = @"－";
        
    }
    return _buttonNumber;
}
@end
