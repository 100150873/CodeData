//
//  ZCCustomSearchView.h
//  GTTemplateAPP
//
//  Created by yixin on 2018/1/27.
//  Copyright © 2018年 GZC. All rights reserved.
//
/**************************************************************
 Description:
 联盟商家首页顶部自定义搜索view
 ******************************************************************/
#import <UIKit/UIKit.h>

@interface ZCCustomSearchView : UIView

- (NSString *)searchContent;
- (CGFloat)buttonKindCenterX;
- (UITextField *)textFieldSearch;
- (void)setPlaceholder:(NSString *)placeholder;
- (void)setClickBackBlock:(dispatch_block_t)clickBackBlock;
- (void)setClickRightBlock:(dispatch_block_t)clickRightBlock;
- (void)setClickDeleteBlock:(dispatch_block_t)clickDeleteBlock;
- (void)setClickSearchTFBlock:(dispatch_block_t)clickSearchTFBlock;

/**
 类方法实例化对象

 @param superView 父类view
 @param rightBtn 右侧自定义按钮
 @param constraintBlock 约束
 @return 返回自定义的搜索对象
 */
+ (instancetype)searchWithSuperView:(UIView *)superView
                           rightBtn:(UIButton *)rightBtn
                        constraints:(void (^) (MASConstraintMaker *make))constraintBlock;


@end
