//
//  ZCCustomSearchView.m
//  GTTemplateAPP
//
//  Created by yixin on 2018/1/27.
//  Copyright © 2018年 GZC. All rights reserved.
//

#import "ZCCustomSearchView.h"

@interface ZCCustomSearchView ()<UITextFieldDelegate>

/**
 白色背景搜索框view
 */
@property(nonatomic,strong)UIImageView *viewSearchBG;
@property(nonatomic,strong)UIView *viewNavBG,*viewStatusBG;
/**
 搜索icon
 */
@property(nonatomic,strong)UIImageView *imgViewSearch;
/**
 搜索框
 */
@property(nonatomic,strong)UITextField *textFieldSearch;
/**
 左侧返回按钮 右侧搜索按钮
 */
@property(nonatomic,strong)UIButton *buttonBack,*buttonRight;

@property(nonatomic,copy)dispatch_block_t clickBackBlock;
@property(nonatomic,copy)dispatch_block_t clickRightBlock;
@property(nonatomic,copy)dispatch_block_t clickDeleteBlock;
@property(nonatomic,copy)dispatch_block_t clickSearchTFBlock;
@end

@implementation ZCCustomSearchView

/**
 类方法实例化对象
 
 @param superView 父类view
 @param rightBtn 右侧自定义按钮
 @param constraintBlock 约束
 @return 返回自定义的搜索对象
 */
+ (instancetype)searchWithSuperView:(UIView *)superView
                           rightBtn:(UIButton *)rightBtn
                        constraints:(void (^) (MASConstraintMaker *make))constraintBlock
{
    ZCCustomSearchView *searchView = [[ZCCustomSearchView alloc] init];
    [rightBtn addTarget:searchView action:@selector(clickRightBtn:) forControlEvents:UIControlEventTouchDown];
    searchView.buttonRight = rightBtn;
    searchView.backgroundColor = ZCColorMain;
    [searchView addSubviews];
    [superView addSubview:searchView];
    if (superView&&constraintBlock) {
        [searchView mas_makeConstraints:^(MASConstraintMaker *make) {
            constraintBlock(make);
        }];
    }
    return searchView;
}

#pragma mark - =======Public 对外接口=========
- (void)setPlaceholder:(NSString *)placeholder
{
    self.textFieldSearch.placeholder = placeholder;
}

- (CGFloat)buttonKindCenterX
{
    [self layoutIfNeeded];
    CGPoint point = [self convertPoint:CGPointMake(self.imgViewSearch.centerX, ZCStatusBarAndNavigationBarHeight) fromView:self.viewSearchBG];
    ZCLog(@"转换后的类别按钮的X值 === %@",@(point.x));
    return point.x;
}

- (NSString *)searchContent
{
    return self.textFieldSearch.text;
}
#pragma mark - =======Init UIView=========
- (void)addSubviews
{
    //最底部的两个
    [self addSubview:self.viewStatusBG];
    [self addSubview:self.viewNavBG];
    
    //导航条
    [self.viewNavBG addSubview:self.buttonBack];
    [self.viewNavBG addSubview:self.buttonRight];
    [self.viewNavBG addSubview:self.viewSearchBG];
    //搜索框
    [self.viewSearchBG addSubview:self.imgViewSearch];
    [self.viewSearchBG addSubview:self.textFieldSearch];
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    [self.viewStatusBG mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.right.top.equalTo(self);
        make.height.mas_equalTo(ZCStatusBarHeight);
    }];
    [self.viewNavBG mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.viewStatusBG.mas_bottom);
        make.right.left.equalTo(self);
        make.height.mas_equalTo(44);
    }];
    
    CGFloat margin = ZCHeight(5);
    CGFloat buttonH = ZCHeight(30);
    CGFloat buttonW = ZCHeight(55);
    
    [self.buttonBack mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.centerY.equalTo(self.viewNavBG);
        make.size.equalTo([NSValue valueWithCGSize:CGSizeMake(buttonW, buttonH)]);
    }];
    [self.buttonRight mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.viewNavBG);
        make.right.equalTo(self.viewNavBG).offset(-margin);
        make.size.equalTo([NSValue valueWithCGSize:CGSizeMake(buttonW, buttonH)]);
    }];
    //搜索背景图片
    [self.viewSearchBG mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.viewNavBG);
        make.left.equalTo(self.buttonBack.mas_right).offset(- ZCHeight(1));
        make.right.equalTo(self.buttonRight.mas_left).offset(- margin);
        make.height.equalTo(@(buttonH));
    }];
    //搜索图标
    CGFloat iconWH = 18;
    [self.imgViewSearch mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.viewSearchBG);
        make.left.equalTo(self.viewSearchBG).offset(ZCHeight(8));
        make.width.equalTo(@(iconWH));
        make.height.equalTo(@(iconWH));
    }];
    //搜索框
    [self.textFieldSearch mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.top.equalTo(self.viewSearchBG);
        make.left.equalTo(self.imgViewSearch.mas_right).offset(3);
        make.right.equalTo(self.viewSearchBG).offset(- ZCHeight(5));
    }];
    
}

#pragma mark - =======UITextFieldDelegate=========
//- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
//{
//    ZCLog(@"textField将要开始编辑");
//    !_clickSearchTFBlock ? : _clickSearchTFBlock();
//    return YES;
//}

- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    !_clickSearchTFBlock ? : _clickSearchTFBlock();
}

- (BOOL)textFieldShouldClear:(UITextField *)textField
{
    !_clickDeleteBlock ? : _clickDeleteBlock();
    return YES;
}

- (BOOL)textFieldShouldReturn:(UITextField *)textField
{
    !_clickRightBlock ? : _clickRightBlock();
    return YES;
}

#pragma mark - =======Action=========
/**
 点击返回到上一页

 @param btn 返回按钮
 */
- (void)clickBack:(UIButton *)btn
{
    !_clickBackBlock ? : _clickBackBlock();
}

/**
 点击了右侧按钮

 @param btn 按钮
 */
- (void)clickRightBtn:(UIButton *)btn
{
    !_clickRightBlock ? : _clickRightBlock();
}

#pragma mark - =======Getter and Setter=========
- (UIButton *)buttonBack
{
    if (!_buttonBack) {
        _buttonBack = [UIButton buttonWithImageName:@"newBack"];
         [_buttonBack addTarget:self action:@selector(clickBack:) forControlEvents:UIControlEventTouchDown];
    }
    return _buttonBack;
}
- (UIButton *)buttonRight
{
    if (!_buttonRight) {
        _buttonRight = [[UIButton alloc] init];
    }
    return _buttonRight;
}

- (UIImageView *)viewSearchBG
{
    if (!_viewSearchBG) {
        _viewSearchBG = [UIImageView imageViewWithImageName:@"searchBg_navigation_icon"];
        _viewSearchBG.userInteractionEnabled = YES;
    }
    return _viewSearchBG;
}
- (UITextField *)textFieldSearch
{
    if (!_textFieldSearch) {
        _textFieldSearch = [[UITextField alloc] init];
        _textFieldSearch.font = ZCFont(13);
        _textFieldSearch.placeholder = @" ";
        [_textFieldSearch setValue:ZCColorWhite forKeyPath:@"_placeholderLabel.textColor"];
        [_textFieldSearch setValue:ZCFont(13) forKeyPath:@"_placeholderLabel.font"];
        _textFieldSearch.delegate = self;
        _textFieldSearch.clearButtonMode = UITextFieldViewModeAlways;
    }
    return _textFieldSearch;
}

- (UIView *)viewStatusBG
{
    if (!_viewStatusBG) {
        _viewStatusBG = [[UIView alloc] init];
        _viewStatusBG.backgroundColor = ZCColorMain;
    }
    return _viewStatusBG;
}
- (UIView *)viewNavBG
{
    if (!_viewNavBG) {
        _viewNavBG = [[UIView alloc] init];
        _viewNavBG.backgroundColor = ZCColorMain;
    }
    return _viewNavBG;
}

- (UIImageView *)imgViewSearch
{
    if (!_imgViewSearch) {
        _imgViewSearch = [UIImageView imageViewWithImageName:@"search_navigation_icon"];
    }
    return _imgViewSearch;
}

@end
