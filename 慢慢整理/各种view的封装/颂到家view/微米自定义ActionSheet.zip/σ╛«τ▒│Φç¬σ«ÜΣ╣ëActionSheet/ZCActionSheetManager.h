//
//  ZCActionSheetManager.h
//  GTTemplateAPP
//
//  Created by yixin on 2018/4/17.
//  Copyright © 2018年 GZC. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ZCActionSheetManager : NSObject

- (void)showActionSheetWithTitle:(NSString *)title
                    actionTitles:(NSArray *)actionTitles
                  clickItemBlock:(void (^) (NSString *title, NSInteger index))clickItemBlock;
@end
