//
//  ZCActionSheetManager.m
//  GTTemplateAPP
//
//  Created by yixin on 2018/4/17.
//  Copyright © 2018年 GZC. All rights reserved.
//

#import "ZCActionSheetManager.h"

@interface ZCActionSheetManager ()

@end

@implementation ZCActionSheetManager

- (void)showActionSheetWithTitle:(NSString *)title
                    actionTitles:(NSArray *)actionTitles
                  clickItemBlock:(void (^) (NSString *title, NSInteger index))clickItemBlock
{
    if (actionTitles.count == 0) return;
    [ZCAlert showAlertWithTitle:@"" message:title preferredStyle:UIAlertControllerStyleActionSheet actionMaker:^(UIAlertController *manager) {
        for (NSString *item in actionTitles) {
            UIAlertAction *action = [UIAlertAction actionWithTitle:item style:UIAlertActionStyleDestructive handler:^(UIAlertAction * action) {
                //点击了哪一行
                NSInteger row = [actionTitles indexOfObject:item];
                !clickItemBlock ? : clickItemBlock(item,row);
            }];
            [action setValue:ZCColorMainTitle forKey:@"titleTextColor"];
            [manager addAction:action];
        }
        
        UIAlertAction *canleAction = [UIAlertAction actionWithTitle:@"取消" style:UIAlertActionStyleCancel handler:nil];
        [manager addAction:canleAction];
        
        
        [manager addMessageAttributedStringWithFontSize:ZCFont(16) titleColor:ZCColorSubTitle];
    }];
}




@end
