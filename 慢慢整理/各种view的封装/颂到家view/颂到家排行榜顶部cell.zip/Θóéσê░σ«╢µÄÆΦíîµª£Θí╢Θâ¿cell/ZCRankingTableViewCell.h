//
//  ZCRankingTableViewCell.h
//  GTTemplateAPP
//
//  Created by yixin on 2018/3/3.
//  Copyright © 2018年 GZC. All rights reserved.
//

#import "ZCBaseTableViewCell.h"

@interface ZCRankingTableViewCell : ZCBaseTableViewCell

/**
 排序

 @param sortUp YES 升序 NO 降序
 */
- (void)setSortUp:(BOOL)sortUp;
- (void)setUserIcon:(NSURL *)userIcon;
- (void)setUserName:(NSString *)userName;
- (void)setCostValue:(NSString *)costValue;
- (void)setRankingNum:(NSString *)rankingNum;
@end
