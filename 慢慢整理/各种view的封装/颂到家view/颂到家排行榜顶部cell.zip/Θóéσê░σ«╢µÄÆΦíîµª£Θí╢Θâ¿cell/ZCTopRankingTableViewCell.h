//
//  ZCTopRankingTableViewCell.h
//  GTTemplateAPP
//
//  Created by yixin on 2018/3/3.
//  Copyright © 2018年 GZC. All rights reserved.
//

#import "ZCBaseTableViewCell.h"

@interface ZCTopRankingTableViewCell : ZCBaseTableViewCell

@end
