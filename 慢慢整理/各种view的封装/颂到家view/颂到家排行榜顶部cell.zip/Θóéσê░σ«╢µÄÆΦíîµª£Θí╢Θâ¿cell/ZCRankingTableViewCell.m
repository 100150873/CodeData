//
//  ZCRankingTableViewCell.m
//  GTTemplateAPP
//
//  Created by yixin on 2018/3/3.
//  Copyright © 2018年 GZC. All rights reserved.
//

#import "ZCRankingTableViewCell.h"
@interface ZCRankingTableViewCell ()

@property(nonatomic,strong)UILabel *labelLeft;
@property(nonatomic,strong)UILabel *labelName,*labelDetail;
@property(nonatomic,strong)UIImageView *imageIcon,*imageSort;
@end
@implementation ZCRankingTableViewCell
- (void)setup
{
    [super setup];
    [self addSubview:self.labelName];
    [self addSubview:self.labelDetail];
    [self addSubview:self.labelLeft];
    [self addSubview:self.imageSort];
    [self addSubview:self.imageIcon];
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    CGFloat margin = ZCHeight(10);
    [self.labelLeft mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.top.equalTo(self);
        make.left.equalTo(self).offset(margin);
        make.width.mas_equalTo(ZCHeight(20));
    }];
    
    CGFloat iconWH = self.height * 0.8;
    [self.imageIcon mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self);
        make.left.equalTo(self.labelLeft.mas_right).offset(margin);
        make.size.equalTo([NSValue valueWithCGSize:CGSizeMake(iconWH, iconWH)]);
    }];
    [self.imageIcon addBorderWidth:2 WithColor:ZCColorMain cornerRadius:iconWH * 0.5];
    
    [self.imageSort mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self);
        make.right.equalTo(self).offset(- margin);
        make.size.equalTo([NSValue valueWithCGSize:CGSizeMake(ZCHeight(15), ZCHeight(15))]);
    }];
    
    [self.labelDetail mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.top.equalTo(self);
        make.right.equalTo(self.imageSort.mas_left).offset(- margin * 1.2);
    }];
    
    [self.labelName mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.top.equalTo(self);
        make.left.equalTo(self.imageIcon.mas_right).offset(margin);
        make.right.equalTo(self.labelDetail.mas_left).offset(- margin);
    }];
}

#pragma mark - =======Public=========
- (void)setRankingNum:(NSString *)rankingNum
{
    self.labelLeft.text = rankingNum;
}
- (void)setUserIcon:(NSURL *)userIcon
{
    [self.imageIcon sd_setImageWithURL:userIcon placeholderImage:ZCImageNamed(@"my_default_icon")];
}
- (void)setUserName:(NSString *)userName
{
    self.labelName.text = userName;
}
- (void)setCostValue:(NSString *)costValue
{
    self.labelDetail.text = costValue;
}
- (void)setSortUp:(BOOL)sortUp
{
    self.imageSort.image = ZCImageNamed(sortUp ? @"sort_up_icon" : @"sort_down_icon" );
}

#pragma mark - =======Getter=========
- (UILabel *)labelLeft
{
    if (!_labelLeft) {
        _labelLeft = [UILabel labelWithFontSize:ZCFont(13) title:@"" textAlignment:NSTextAlignmentCenter titleColor:ZCColorMainTitle];
    }
    return _labelLeft;
}
- (UILabel *)labelDetail
{
    if (!_labelDetail) {
        _labelDetail = [UILabel labelWithFontSize:ZCFont(14) title:@"" textAlignment:NSTextAlignmentRight titleColor:ZCColorMainTitle];
    }
    return _labelDetail;
}
- (UILabel *)labelName
{
    if (!_labelName) {
        _labelName = [UILabel labelWithFontSize:ZCFont(15) title:@"" textAlignment:NSTextAlignmentLeft titleColor:ZCColorMainTitle];
    }
    return _labelName;
}
- (UIImageView *)imageIcon
{
    if (!_imageIcon) {
        _imageIcon = [[UIImageView alloc] init];
    }
    return _imageIcon;
}
- (UIImageView *)imageSort
{
    if (!_imageSort) {
        _imageSort = [[UIImageView alloc] init];
    }
    return _imageSort;
}
@end
