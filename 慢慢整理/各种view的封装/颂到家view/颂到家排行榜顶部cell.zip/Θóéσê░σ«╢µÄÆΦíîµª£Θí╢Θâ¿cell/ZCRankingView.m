//
//  ZCRankingView.m
//  GTTemplateAPP
//
//  Created by yixin on 2018/3/3.
//  Copyright © 2018年 GZC. All rights reserved.
//

#import "ZCRankingView.h"

@interface ZCRankingView ()

@property(nonatomic,strong)UILabel *labelName,*labelDetail;
@property(nonatomic,strong)UIImageView *imageIcon,*imageSort,*imageBG;
@end
@implementation ZCRankingView

- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self addSubview:self.labelName];
        [self addSubview:self.labelDetail];
        [self addSubview:self.imageBG];
        [self.imageBG addSubview:self.imageIcon];
        [self addSubview:self.imageSort];
    }
    return self;
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    CGFloat bgWH = self.height * 0.45;
    [self.imageBG mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerX.equalTo(self);
        make.centerY.equalTo(self).offset(- self.height * 0.1);
        make.size.equalTo([NSValue valueWithCGSize:CGSizeMake(bgWH, bgWH)]);
    }];
    CGFloat iconWH = self.height * 0.3;
    [self.imageIcon mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.centerX.equalTo(self.imageBG);
        make.size.equalTo([NSValue valueWithCGSize:CGSizeMake(iconWH, iconWH)]);
    }];
    
    [self.labelName mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.imageIcon.mas_bottom).offset(ZCHeight(3));
        make.right.left.equalTo(self);
        make.height.mas_equalTo(ZCHeight(30));
    }];
    
    [self.imageSort mas_makeConstraints:^(MASConstraintMaker *make) {
        make.right.equalTo(self.imageIcon);
        make.size.equalTo([NSValue valueWithCGSize:CGSizeMake(ZCHeight(18), ZCHeight(18))]);
    }];
    
    [self.labelDetail mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self.labelName.mas_bottom);
        make.left.equalTo(self);
        make.right.equalTo(self.imageSort.mas_left).offset(- ZCHeight(3));
        make.height.mas_equalTo(ZCHeight(20));
    }];
    //写在这里为了和labelDetail中心对齐
    [self.imageSort mas_makeConstraints:^(MASConstraintMaker *make) {
        make.centerY.equalTo(self.labelDetail);
    }];
}
#pragma mark - =======Public 对外接口=========
//ranking_0_icon
- (void)setBImage:(NSString *)bImage
{
    self.imageBG.image = ZCImageNamed(bImage);
}

- (void)setUserIcon:(NSURL *)userIcon
{
    [self.imageIcon sd_setImageWithURL:userIcon placeholderImage:ZCImageNamed(@"my_default_icon")];
}
- (void)setUserName:(NSString *)userName
{
    self.labelName.text = userName;
}
- (void)setCostValue:(NSString *)costValue
{
    self.labelDetail.text = costValue;
}
- (void)setSortUp:(BOOL)sortUp
{
    self.imageSort.image = ZCImageNamed(sortUp ? @"sort_up_icon" : @"sort_down_icon" );
}
#pragma mark - =======Getter=========
- (UILabel *)labelDetail
{
    if (!_labelDetail) {
        _labelDetail = [UILabel labelWithFontSize:ZCFont(15) title:@"" textAlignment:NSTextAlignmentRight titleColor:ZCColorMainTitle];
    }
    return _labelDetail;
}
- (UILabel *)labelName
{
    if (!_labelName) {
        _labelName = [UILabel labelWithFontSize:ZCFont(18) title:@"" textAlignment:NSTextAlignmentCenter titleColor:ZCColorMainTitle];
    }
    return _labelName;
}
- (UIImageView *)imageIcon
{
    if (!_imageIcon) {
        _imageIcon = [[UIImageView alloc] init];
    }
    return _imageIcon;
}
- (UIImageView *)imageBG
{
    if (!_imageBG) {
        _imageBG = [[UIImageView alloc] init];
    }
    return _imageBG;
}
- (UIImageView *)imageSort
{
    if (!_imageSort) {
        _imageSort = [[UIImageView alloc] init];
    }
    return _imageSort;
}
@end
