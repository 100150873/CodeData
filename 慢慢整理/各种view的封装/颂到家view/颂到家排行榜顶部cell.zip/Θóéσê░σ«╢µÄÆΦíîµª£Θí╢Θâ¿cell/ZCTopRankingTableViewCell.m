//
//  ZCTopRankingTableViewCell.m
//  GTTemplateAPP
//
//  Created by yixin on 2018/3/3.
//  Copyright © 2018年 GZC. All rights reserved.
//

#import "ZCRankingView.h"
#import "ZCTopRankingTableViewCell.h"

@interface ZCTopRankingTableViewCell ()

@property(nonatomic,strong)UIStackView *viewStack;
@end

@implementation ZCTopRankingTableViewCell

- (void)setup
{
    [super setup];
    [self addSubview:self.viewStack];
}
- (void)layoutSubviews
{
    [super layoutSubviews];
    [self.viewStack mas_makeConstraints:^(MASConstraintMaker *make) {
        make.edges.equalTo(self);
    }];
}

#pragma mark - =======Getter=========
- (UIStackView *)viewStack
{
    if (!_viewStack) {
        NSMutableArray *arrayTemp = [[NSMutableArray alloc] init];
        for (NSInteger i = 0; i < 2; i ++) {
            ZCRankingView *viewItem = [[ZCRankingView alloc] init];
            viewItem.sortUp = i % 2;
            viewItem.userIcon = @"";
            viewItem.userName = @"ceshizhuanyong";
            viewItem.costValue = @"124元";
            viewItem.bImage = @"ranking_0_icon";
            [arrayTemp addObject:viewItem];
        }
        _viewStack = [[UIStackView alloc] initWithArrangedSubviews:arrayTemp];
        _viewStack.axis = UILayoutConstraintAxisHorizontal;
        _viewStack.alignment = UIStackViewAlignmentFill;
        _viewStack.distribution = UIStackViewDistributionFillEqually;
    }
    return _viewStack;
}

@end
