//
//  ZCRankingView.h
//  GTTemplateAPP
//
//  Created by yixin on 2018/3/3.
//  Copyright © 2018年 GZC. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ZCRankingView : UIView

/**
 排序
 
 @param sortUp YES 升序 NO 降序
 */
- (void)setSortUp:(BOOL)sortUp;
- (void)setBImage:(NSString *)bImage;
- (void)setUserIcon:(NSURL *)userIcon;
- (void)setUserName:(NSString *)userName;
- (void)setCostValue:(NSString *)costValue;
@end
