//
//  CDWebView.m
//  TestDemo
//
//  Created by Cindy on 15/11/9.
//  Copyright © 2015年 Cindy. All rights reserved.
//

#import <JavaScriptCore/JavaScriptCore.h>
#import <WebKit/WebKit.h>

#import "CDWebView.h"


NSString *const CDLoadingExceptionLableDecription = @"网络不给力，加载失败啦！";
NSString *const CDLoadingExceptionButtonDecription = @"重新加载";

@interface CDWebView() <WKNavigationDelegate,WKScriptMessageHandler,UIWebViewDelegate>
{
    @private
    UIView *_superView;
    
    UIWebView *_webView;
    WKWebView *_wkWebView;
}
@property (nonatomic,assign) id<CDWebViewDelegate> delegate;
@property (nonatomic,strong) NSArray *jsFunctionNameArray;
@property (nonatomic,strong) JSContext *jsContext;
@end

@implementation CDWebView

- (instancetype)init
{
    return nil;
}

- (instancetype)initWithDelegate:(id<CDWebViewDelegate>) delegate andView:(UIView *)view
{
    self = [super init];
    if (self) {
        self.delegate = delegate;
        _superView = view;
        
        [self initViewAndData];
    }
    return self;
}

- (void)initViewAndData
{
    /**
     * 初始化web   、设置web代理
     */
    if (SDK_VERSION >= 8.0) {
        _wkWebView = [[WKWebView alloc] initWithFrame:self.bounds];
        [self addSubview:_wkWebView];
        _wkWebView.navigationDelegate = self;
        _wkWebView.backgroundColor = [UIColor whiteColor];
        [_wkWebView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self);
            make.left.equalTo(self);
            make.right.equalTo(self);
            make.bottom.equalTo(self);
        }];
        
    } else {
        _webView = [[UIWebView alloc] initWithFrame:self.bounds];
        [self addSubview:_webView];
        _webView.delegate = self;
        _webView.backgroundColor = [UIColor whiteColor];
        [_webView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self);
            make.left.equalTo(self);
            make.right.equalTo(self);
            make.bottom.equalTo(self);
        }];
    }
    
    /**
     *  初始化js
     */
    if ([self.delegate respondsToSelector:@selector(arrayOfRegisterToJSFunctionNameWithWebController:)]) {
        self.jsFunctionNameArray = [self.delegate arrayOfRegisterToJSFunctionNameWithWebController:self];
        
        if (SDK_VERSION >= 8.0 && [_jsFunctionNameArray count] > 0) {
            WKWebViewConfiguration* webViewConfig = [[WKWebViewConfiguration alloc] init];
            for (NSString *name in _jsFunctionNameArray) {
                [webViewConfig.userContentController addScriptMessageHandler:self name:name];
            }
            
            [_wkWebView  removeFromSuperview];
            _wkWebView = nil;
            _wkWebView = [[WKWebView alloc] initWithFrame:self.bounds configuration:webViewConfig];
            [self addSubview:_wkWebView];
            _wkWebView.navigationDelegate = self;
            _wkWebView.backgroundColor = [UIColor whiteColor];
        }
    } else {
        _jsFunctionNameArray = @[];
    }
    
}

#pragma mark - Public Method -
- (void)reloadRequestWebData
{
    if (self.request == nil) {
        return;
    } else {
        if (SDK_VERSION >= 8.0) {
            MGDetailLog(@"【 WKWeb 】 --> URL=%@",self.request.URL.absoluteString);
            if (self.request.URL.isFileURL) {
                NSString * htmlCont = [NSString stringWithContentsOfFile:self.request.URL.path encoding:NSUTF8StringEncoding error:nil];
                [_wkWebView loadHTMLString:htmlCont baseURL:nil];
            } else {
                [_wkWebView loadRequest:self.request];
            }
            
        } else {
            MGDetailLog(@"【 UIWeb 】 --> URL=%@",self.request.URL.absoluteString);
            [_webView loadRequest:self.request];
        }
    }
}

- (BOOL)canGoBack
{
    if (SDK_VERSION >= 8.0) {
        return [_wkWebView canGoBack];
    } else {
        return [_webView canGoBack];
    }
}

- (BOOL)canGoForward
{
    if (SDK_VERSION >= 8.0) {
        return [_wkWebView canGoForward];
    } else {
        return [_webView canGoForward];
    }
}

- (void)goBack
{
    if (SDK_VERSION >= 8.0) {
        if ([_wkWebView canGoBack]) {
            [_wkWebView goBack];
        }
    } else {
        if ([_webView canGoBack]) {
            [_webView goBack];
        }
    }
}

- (void)goForward
{
    if (SDK_VERSION >= 8.0) {
        if ([_wkWebView canGoForward]) {
            [_wkWebView goForward];
        }
    } else {
        if ([_webView canGoForward]) {
            [_webView goForward];
        }
    }
}

- (void)reload
{
    if (SDK_VERSION >= 8.0) {
        [_wkWebView reload];
    } else {
        [_wkWebView reload];
    }
}

#pragma mark  oc  called  js
- (void)evaluateJavaScriptWith:(NSString *)scriptString
{
    if (scriptString == nil || scriptString.length == 0) {
        return;
    } else {
        if (SDK_VERSION >= 8.0) {
            [_wkWebView evaluateJavaScript:scriptString completionHandler:^(id _Nullable returnValue, NSError * _Nullable error) {
                MGDetailLog(@"evaluateJavaScript result : \n error : %@  \nreturnValue:%@",error,returnValue);
            }];
        } else {
            NSString *result = [_webView stringByEvaluatingJavaScriptFromString:scriptString];
            MGDetailLog(@"stringByEvaluatingJavaScriptFromString result : \n error : %@",result);
        }
    }
}

#pragma mark - view
//- (void)layoutSubviews
//{
//    if (SDK_VERSION >= 8.0) {
//        _wkWebView.frame = self.bounds;
//    } else {
//        _webView.frame = self.bounds;
//    }
//}


#pragma mark - web view delegate
- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    if ([self.delegate respondsToSelector:@selector(cdWebView:shouldStartLoadWithRequest:navigationType:)]) {
        return [self.delegate cdWebView:self shouldStartLoadWithRequest:request navigationType:(CDWebViewNavigationType)navigationType];
    } else {
        return YES;
    }
}

//  已经开始加载网页内容
- (void)webViewDidStartLoad:(UIWebView *)webView
{
    if ([self.delegate respondsToSelector:@selector(cdWebViewDidStartLoad:)]) {
        [self.delegate cdWebViewDidStartLoad:self];
    }
}

//  网页内容加载完毕
- (void)webViewDidFinishLoad:(UIWebView *)webView
{
    if ([self.delegate respondsToSelector:@selector(cdWebViewDidFinishLoad:)]) {
        [self.delegate cdWebViewDidFinishLoad:self];
    }
    
    
    //  更新 js 的执行环境变量
    _jsContext = [webView valueForKeyPath:CDJSContextPathKey];
    MGDetailLog(@"JSContext         %@",_jsContext);
    _jsContext.exceptionHandler = ^(JSContext *context, JSValue *exception) {
        MGDetailLog(@"JSContext  Exception Handler Info : \n%@", exception);
        context.exception = exception;
    };
    _jsContext[@"log"] = ^() {
        MGDetailLog(@"+++++++Begin  Js  Log+++++++");
        NSArray *args = [JSContext currentArguments];
        for (JSValue *jsVal in args) {
            MGDetailLog(@"%@", jsVal);
        }
        JSValue *this = [JSContext currentThis];
        MGDetailLog(@"this: %@",this);
        MGDetailLog(@"-------End  Js  Log-------");
    };
    
    //  向 js 注入 oc 的 代码
    __weak CDWebView *weakSelf = self;
    for (NSString *name in _jsFunctionNameArray) {
        _jsContext[name] = ^(id jsonParam){
            MGDetailLog(@"%@ ---> called back : %@",name,jsonParam);
            if ([weakSelf.delegate respondsToSelector:@selector(cdWebView:didCalledJSFunctionName:andParam:)]) {
                [weakSelf.delegate cdWebView:weakSelf didCalledJSFunctionName:name andParam:jsonParam];
            }
        };
    }
    
}

//  网页内容加载失败
- (void)webView:(UIWebView *)webView didFailLoadWithError:(NSError *)error
{
    if ([self.delegate respondsToSelector:@selector(cdWebView:didLoadFailedWithError:)]) {
        [self.delegate cdWebView:self didLoadFailedWithError:error];
    }
}

//  ios 8.0 以上的版本
#pragma mark  - WKWebView  NavigationDelegate
- (void)webView:(WKWebView *)webView decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler
{
    if ([self.delegate respondsToSelector:@selector(cdWebView:shouldStartLoadWithRequest:navigationType:)]) {
        if ([self.delegate cdWebView:self shouldStartLoadWithRequest:navigationAction.request navigationType:(CDWebViewNavigationType)navigationAction.navigationType]) {
            decisionHandler(WKNavigationActionPolicyAllow);
        } else {
            decisionHandler(WKNavigationActionPolicyCancel);
        }
    } else {
        decisionHandler(WKNavigationActionPolicyAllow);
    }
}

- (void)webView:(WKWebView *)webView didStartProvisionalNavigation:(null_unspecified WKNavigation *)navigation
{
    MGDetailLog(@"didStartProvisionalNavigation");
    if ([self.delegate respondsToSelector:@selector(cdWebViewDidStartLoad:)]) {
        [self.delegate cdWebViewDidStartLoad:self];
    }
}

- (void)webView:(WKWebView *)webView didFinishNavigation:(null_unspecified WKNavigation *)navigation
{
    MGDetailLog(@"didFinishNavigation");
    if ([self.delegate respondsToSelector:@selector(cdWebViewDidFinishLoad:)]) {
        [self.delegate cdWebViewDidFinishLoad:self];
    }
}

//  请求开始时发生错误
- (void)webView:(WKWebView *)webView didFailProvisionalNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)error
{
    MGDetailLog(@"didFailProvisionalNavigation  Error:%@",error);
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if ([self.delegate respondsToSelector:@selector(cdWebView:didLoadFailedWithError:)]) {
            [self.delegate cdWebView:self didLoadFailedWithError:error];
        }
    });
}

//  请求期间发生错误
- (void)webView:(WKWebView *)webView didFailNavigation:(null_unspecified WKNavigation *)navigation withError:(NSError *)error
{
    MGDetailLog(@"didFailNavigation   Error:%@",error);
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        if ([self.delegate respondsToSelector:@selector(cdWebView:didLoadFailedWithError:)]) {
            [self.delegate cdWebView:self didLoadFailedWithError:error];
        }
    });
}

#pragma mark   wkWebView   js  called oc  (ScriptMessage Handler)
- (void)userContentController:(WKUserContentController *)userContentController didReceiveScriptMessage:(WKScriptMessage *)message
{
    MGDetailLog(@"message.body : %@ \nmessage.name:%@",message.body,message.name);
    if ([self.delegate respondsToSelector:@selector(cdWebView:didCalledJSFunctionName:andParam:)]) {
        [self.delegate cdWebView:self didCalledJSFunctionName:message.name andParam:message.body];
    }
}

@end
