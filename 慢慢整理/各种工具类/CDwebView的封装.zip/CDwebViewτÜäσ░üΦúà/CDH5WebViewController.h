//
//  CDH5WebViewController.h
//  MangocityTravel
//
//  Created by Cindy on 16/8/30.
//  Copyright © 2016年 Mangocity. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CDH5WebViewController : UIViewController

@property (nonatomic,strong) NSString *titleString;

- (instancetype)initWithOpenURL:(NSString *)urlString;

@end
