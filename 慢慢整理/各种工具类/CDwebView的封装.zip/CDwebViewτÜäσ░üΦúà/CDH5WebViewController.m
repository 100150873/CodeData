//
//  CDH5WebViewController.m
//  MangocityTravel
//
//  Created by Cindy on 16/8/30.
//  Copyright © 2016年 Mangocity. All rights reserved.
//

#import "CDH5WebViewController.h"
#import "CDWebView.h"

 NSString *const LoadingViewTitle = @"正在加载";

@interface CDH5WebViewController () <CDWebViewDelegate>
{
    NSTimer *_timerProgress;
    UIProgressView *_progress;
    BOOL _isLoading;
}
@property (nonatomic,strong) NSString *url;
@property (nonatomic,strong) CDWebView *webView;
@property (nonatomic,strong) UIView *bottomView;
@property (nonatomic,strong) UILabel *labelTitle;
@end

@implementation CDH5WebViewController

- (instancetype)initWithOpenURL:(NSString *)urlString
{
    self = [super init];
    if (self) {
        self.url = urlString;
    }
    return self;
}

#pragma mark
- (void)startLoadingWeb
{
    NSURL *URL = [NSURL URLWithString:[_url stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:URL
                                                           cachePolicy:NSURLRequestUseProtocolCachePolicy
                                                       timeoutInterval:6];
    self.webView.request = request;
    [self.webView reloadRequestWebData];
}

#pragma mark - view
- (void)viewWillLayoutSubviews
{
    [super viewWillLayoutSubviews];
    [self.view bringSubviewToFront:self.bottomView];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.view.backgroundColor = [UIColor whiteColor];
    [self setAutomaticallyAdjustsScrollViewInsets:NO];
    
//    [self showLoadingView:LoadingViewTitle];
    self.bottomView.backgroundColor = [UIColor redColor];
    
    // 开始请求数据
    [self startLoadingWeb];
    
    // 加载进度条
    _timerProgress = [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(updateLoadingProgress:) userInfo:nil repeats:YES];
}

#pragma mark - CDWebView Delegate
- (void)cdWebViewDidStartLoad:(CDWebView *)webView
{
//    [self showLoadingView:LoadingViewTitle];
    _progress.hidden = NO;
    _isLoading = YES;
    _timerProgress = [NSTimer scheduledTimerWithTimeInterval:0.5 target:self selector:@selector(updateLoadingProgress:) userInfo:nil repeats:YES];
    _progress.progress = 0.4;
    
}

- (void)cdWebViewDidFinishLoad:(CDWebView *)webView
{
//    [self hiddenLoadingView];
    [_timerProgress invalidate];
    _isLoading = NO;
    _progress.progress = 1.0;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        _progress.hidden = YES;
    });
}

- (void)cdWebView:(CDWebView *)webView  didLoadFailedWithError:(NSError *)error
{
//    [self hiddenLoadingView];
    [_timerProgress invalidate];
    _isLoading = NO;
    _progress.progress = 1.0;
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        _progress.hidden = YES;
    });
}

#pragma mark - IBAction
- (void)closeBottonClickedEvent:(UIButton *)buton
{
    [self.navigationController popViewControllerAnimated:YES];
}

- (void)reloadTheWebPage:(UIButton *)button
{
    [self.webView reload];
}

- (void)updateLoadingProgress:(NSTimer *)timer
{
    if (_progress.progress < 0.4) {
        _progress.progress = _progress.progress + 0.08;
    } else if (_progress.progress < 0.8) {
        if (_isLoading) {
            _progress.progress = _progress.progress + 0.08;
        } else {
            [_timerProgress invalidate];
        }
    } else {
        if (_progress.progress >= 1.0) {
            _progress.hidden = YES;
            [_timerProgress invalidate];
        } else {
            _progress.progress = _progress.progress + 0.1;
        }
    }
}

#pragma mark - Setter Method
- (void)setTitleString:(NSString *)titleString
{
    _titleString = titleString;
    _labelTitle.text = titleString;
}

#pragma mark  Getter Method
- (CDWebView *)webView
{
    if (_webView == nil) {
        // 初始化 webView
        _webView = [[CDWebView alloc] initWithDelegate:self andView:self.view];
        [self.view addSubview:_webView];
        [_webView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.view).offset(20.0);
            make.left.equalTo(self.view);
            make.right.equalTo(self.view);
            make.bottom.equalTo(self.view).offset(-45.0);
        }];
    }
    return _webView;
}

- (UIView *)bottomView
{
    if (_bottomView == nil) {
        _bottomView = [[UIView alloc] init];
        _bottomView.layer.shadowColor = DefineColorRGB(200.0, 200.0, 200.0, 1.0).CGColor;
        _bottomView.layer.shadowOffset = CGSizeMake(0.0,-1.0);
        _bottomView.layer.shadowOpacity = 0.7;
        _bottomView.layer.shadowRadius = 1.0f;
        [self.view addSubview:_bottomView];
        [_bottomView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.webView.mas_bottom);
            make.left.equalTo(self.view);
            make.right.equalTo(self.view);
            make.bottom.equalTo(self.view);
        }];
        
        // 进度条
        _progress = [[UIProgressView alloc] init];
        [_progress setProgressTintColor:[UIColor orangeColor]];
        [_progress setTrackTintColor:[UIColor whiteColor]];
        [_bottomView addSubview:_progress];
        [_progress mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(_bottomView);
            make.left.equalTo(_bottomView);
            make.right.equalTo(_bottomView);
            make.height.equalTo(@(1.5));
        }];
        
        // 关闭web
        UIButton *close = [[UIButton alloc] init];
        [close setImage:[UIImage imageNamed:@"web_view_navigation_close"] forState:UIControlStateNormal];
        [close addTarget:self action:@selector(closeBottonClickedEvent:) forControlEvents:UIControlEventTouchUpInside];
        [_bottomView addSubview:close];
        [close mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(_progress.mas_bottom);
            make.left.equalTo(_bottomView);
            make.bottom.equalTo(_bottomView);
            make.width.equalTo(@(60.0));
        }];
        
        //  重新加载、刷新
        UIButton *reload = [[UIButton alloc] init];
        [reload setImage:[UIImage imageNamed:@"web_view_navigation_reloaded"] forState:UIControlStateNormal];
        [reload setTitleColor:[UIColor orangeColor] forState:UIControlStateNormal];
        [reload addTarget:self action:@selector(reloadTheWebPage:) forControlEvents:UIControlEventTouchUpInside];
        [_bottomView addSubview:reload];
        [reload mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(_progress.mas_bottom);
            make.right.equalTo(_bottomView);
            make.bottom.equalTo(_bottomView);
            make.width.equalTo(@(70.0));
        }];
        
        //  title文本
        _labelTitle = [[UILabel alloc] init];
        _labelTitle.textColor = [UIColor darkGrayColor];
        _labelTitle.font = FONT_14;
        _labelTitle.text = _titleString ? _titleString : @"";
        _labelTitle.textAlignment = NSTextAlignmentCenter;
        [_bottomView addSubview:_labelTitle];
        [_labelTitle mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(close.mas_right);
            make.right.equalTo(reload.mas_left);
            make.top.equalTo(_bottomView);
            make.bottom.equalTo(_bottomView);
        }];
    }
    return _bottomView;
}

@end
