//
//  Util.m
//  MangoCity
//
//  Created by liu jianfeng on 11-4-2.
//  Copyright 2011 mangocity. All rights reserved.
//

#import "Util.h"
#import "NSString+Extern.h"
static NSMutableArray *guestInfoArray;

const int factor[] = { 7, 9, 10, 5, 8, 4, 2, 1, 6, 3, 7, 9, 10, 5, 8, 4, 2 };//加权因子
const int checktable[] = { 1, 0, 10, 9, 8, 7, 6, 5, 4, 3, 2 };//校验值对应表

@implementation Util

+(NSMutableArray *)guestInfoArray
{
    if (!guestInfoArray) {
        guestInfoArray = (NSMutableArray*)[[[NSUserDefaults standardUserDefaults] stringForKey:@"GuestInfo"] retain];
    }
    return guestInfoArray;
}

+(void)setGuestInfo
{
    if (guestInfoArray) {
        [[NSUserDefaults standardUserDefaults] setObject:guestInfoArray forKey:@"GuestInfo"];
    }
    
}
//调用方法[util checkIDfromchar:(char *)[string UTF8String]]
+(BOOL)checkIDfromchar:(char *)ID
{
    if (StrLength(ID)==18) {//验证18位
        return 0;
    }
    char IDNumber[19];
    //    NSMutableArray *IDNumber=[[NSMutableArray alloc] init];
    for ( int i = 0; i < 18; i ++ )//相当于类型转换
        IDNumber[i] = ID[i] - 48;
    return [self checkID:IDNumber IDchar:ID];
}

+(int)checkID:(char *)IDNumber IDchar:(char *)IDchar
{
    int i = 0;//i为计数
    int checksum = 0;
    for (; i < 17; i ++ )
        checksum += IDNumber[i] * factor[i];
    
    if ( IDNumber[ 17 ] == checktable[ checksum % 11 ] || ( (IDchar[ 17 ] == 'x'||IDchar[ 17 ] == 'X') && checktable[ checksum % 11 ] == 10 ))
        return 1;
    else
        return 0;
}


+ (BOOL)isNilOrEmptyString:(NSString *)string{
	NSString *nilString = @"null";
	return !string || [string length] <= 0 || [nilString isEqualToString:string];
}

//判断是否是一个正确的手机号码
+ (BOOL)isVerificationMobileNo:(NSString *)string{
    
	if([Util isNilOrEmptyString:string]){
		return NO;
	} 
    
//    NSString *trimmedString = [string stringByTrimmingCharactersInSet:                                   [NSCharacterSet whitespaceAndNewlineCharacterSet]];
//
//    NSString *regex = @"^(1(3|4|5|8))[0-9]{9}$";
//    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES%@",regex];
//    if ([predicate evaluateWithObject:trimmedString] == YES) {
//        return YES;
//    }
//	return NO;
    BOOL flag = [CommonCode isMobileNumber:string];
    return flag;
}

//判断是否是数字
+ (BOOL)isVerificationNumber:(NSString *)string{
    if([Util isNilOrEmptyString:string]){
		return NO;
	} 
    
    NSString *trimmedString = [string stringByTrimmingCharactersInSet:                                   [NSCharacterSet whitespaceAndNewlineCharacterSet]]; 
    NSString *regex = @"[0-9a-zA-z]+";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES%@",regex];
    if ([predicate evaluateWithObject:trimmedString] == YES) {
        return YES;
    }
	return NO;
}
+ (BOOL)validateIDCardNumber:(NSString *)value {
    
    value = [value stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    
    
    int length =0;
    
    if (!value) {
        
        return NO;
        
    }else {
        
        length = value.length;
        
        
        
        if (length !=15 && length !=18) {
            
            return NO;
            
        }
        
    }
    
    // 省份代码
    
    NSArray *areasArray =@[@"11",@"12", @"13",@"14", @"15",@"21", @"22",@"23", @"31",@"32", @"33",@"34", @"35",@"36", @"37",@"41", @"42",@"43", @"44",@"45", @"46",@"50", @"51",@"52", @"53",@"54", @"61",@"62", @"63",@"64", @"65",@"71", @"81",@"82", @"91"];
    
    
    
    NSString *valueStart2 = [value substringToIndex:2];
    
    BOOL areaFlag =NO;
    
    for (NSString *areaCode in areasArray) {
        
        if ([areaCode isEqualToString:valueStart2]) {
            
            areaFlag =YES;
            
            break;
            
        }
        
    }
    
    
    
    if (!areaFlag) {
        
        return false;
        
    }
    
    
    
    
    
    NSRegularExpression *regularExpression;
    
    NSUInteger numberofMatch;
    
    
    
    int year =0;
    
    switch (length) {
            
        case15:
            
            year = [value substringWithRange:NSMakeRange(6,2)].intValue +1900;
            
            
            
            if (year %4 ==0 || (year %100 ==0 && year %4 ==0)) {
                
                
                
                regularExpression = [[NSRegularExpression alloc]initWithPattern:@"^[1-9][0-9]{5}[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))[0-9]{3}$"
                                     
                                                                       options:NSRegularExpressionCaseInsensitive
                                     
                                                                         error:nil];//测试出生日期的合法性
                
            }else {
                
                regularExpression = [[NSRegularExpression alloc]initWithPattern:@"^[1-9][0-9]{5}[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|1[0-9]|2[0-8]))[0-9]{3}$"
                                     
                                                                       options:NSRegularExpressionCaseInsensitive
                                     
                                                                         error:nil];//测试出生日期的合法性
                
            }
            
            numberofMatch = [regularExpression numberOfMatchesInString:value
                             
                                                              options:NSMatchingReportProgress
                             
                                                                range:NSMakeRange(0, value.length)];
            
            
            
            [regularExpression release];
            
            
            
            if(numberofMatch >0) {
                
                return YES;
                
            }else {
                
                return NO;
                
            }
            
        case18:
            
            
            year = [value substringWithRange:NSMakeRange(6,4)].intValue;
            
            if (year %4 ==0 || (year %100 ==0 && year %4 ==0)) {
                
                
                
                regularExpression = [[NSRegularExpression alloc]initWithPattern:@"^[1-9][0-9]{5}19[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|[1-2][0-9]))[0-9]{3}[0-9Xx]$"
                                     
                                                                       options:NSRegularExpressionCaseInsensitive
                                     
                                                                         error:nil];//测试出生日期的合法性
                
            }else {
                
                regularExpression = [[NSRegularExpression alloc]initWithPattern:@"^[1-9][0-9]{5}19[0-9]{2}((01|03|05|07|08|10|12)(0[1-9]|[1-2][0-9]|3[0-1])|(04|06|09|11)(0[1-9]|[1-2][0-9]|30)|02(0[1-9]|1[0-9]|2[0-8]))[0-9]{3}[0-9Xx]$"
                                     
                                                                       options:NSRegularExpressionCaseInsensitive
                                     
                                                                         error:nil];//测试出生日期的合法性
                
            }
            
            numberofMatch = [regularExpression numberOfMatchesInString:value
                             
                                                              options:NSMatchingReportProgress
                             
                                                                range:NSMakeRange(0, value.length)];
            
            
            
            [regularExpression release];
            
            
            
            if(numberofMatch >0) {
                
                int S = ([value substringWithRange:NSMakeRange(0,1)].intValue + [value substringWithRange:NSMakeRange(10,1)].intValue) *7 + ([value substringWithRange:NSMakeRange(1,1)].intValue + [value substringWithRange:NSMakeRange(11,1)].intValue) *9 + ([value substringWithRange:NSMakeRange(2,1)].intValue + [value substringWithRange:NSMakeRange(12,1)].intValue) *10 + ([value substringWithRange:NSMakeRange(3,1)].intValue + [value substringWithRange:NSMakeRange(13,1)].intValue) *5 + ([value substringWithRange:NSMakeRange(4,1)].intValue + [value substringWithRange:NSMakeRange(14,1)].intValue) *8 + ([value substringWithRange:NSMakeRange(5,1)].intValue + [value substringWithRange:NSMakeRange(15,1)].intValue) *4 + ([value substringWithRange:NSMakeRange(6,1)].intValue + [value substringWithRange:NSMakeRange(16,1)].intValue) *2 + [value substringWithRange:NSMakeRange(7,1)].intValue *1 + [value substringWithRange:NSMakeRange(8,1)].intValue *6 + [value substringWithRange:NSMakeRange(9,1)].intValue *3;
                
                int Y = S %11;
                
                NSString *M =@"F";
                
                NSString *JYM =@"10X98765432";
                
                M = [JYM substringWithRange:NSMakeRange(Y,1)];// 判断校验位
                
                if ([M isEqualToString:[value substringWithRange:NSMakeRange(17,1)]]) {
                    
                    return YES;// 检测ID的校验位
                    
                }else {
                    
                    return NO;
                    
                }
                
                
            }else {
                
                return NO;
                
            }
            
        default:
            
            return false;
            
    }
}
//判断是否是大于等于6小于等于12的正确密码
+ (BOOL)isVerificationPwd:(NSString *)string{
	if([Util isNilOrEmptyString:string]){
		return NO;
	} 
    
    NSString *trimmedString = [string stringByTrimmingCharactersInSet:                                   [NSCharacterSet whitespaceAndNewlineCharacterSet]]; 
    
    
	NSInteger length = [trimmedString length];
	
	if (length < 6 || length > 12) {
		return NO;
	}
	
    return YES;
}

//判断是否是有效的信用卡号码
+ (BOOL)isValidateCreditCardNo:(NSString *)string{
    if ([string length]<16 || [string length]>30) {
        return NO;
    }
    
    int sum = 0;
    int digit = 0;
    int addend = 0;
    BOOL timesTwo = NO;
    
    for(int i  = [string length] - 1; i >= 0; i--){
        digit = [[string substringWithRange:NSMakeRange(i, 1)] intValue];
        if(timesTwo){
            addend = digit * 2;
            if(addend > 9){
                addend -= 9;
            }
        } else {
            addend = digit;
        }
        sum = sum + addend;
        timesTwo = !timesTwo;
    }
    return (sum % 10) == 0;
}

//判断是否是中文或中文加拼音或接音加中文或英文/英文
+ (BOOL)isVerificationCardHolder:(NSString *)string{
    
	if([Util isNilOrEmptyString:string]){
		return NO;
	} 
    
    NSString *trimmedString = [string stringByTrimmingCharactersInSet:                                   [NSCharacterSet whitespaceAndNewlineCharacterSet]]; 
    NSString *regex = @"([\u4e00-\u9fa5]+[a-zA-z]+)|([\u4e00-\u9fa5]+)|([a-zA-z]+/[a-zA-z]+)";// |([a-zA-z]+[\u4e00-\u9fa5]+)
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES%@",regex];
    if ([predicate evaluateWithObject:trimmedString] == YES) {
        return YES;
    }
	return NO;
}
//判断是否是只包含中文 、英文 、/
+ (BOOL)isUseFullNameHolder:(NSString *)string{
    
    if([Util isNilOrEmptyString:string]){
        return NO;
    }
    
    NSString *trimmedString = [string stringByTrimmingCharactersInSet:                                   [NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *regex = @"(/[\u4e00-\u9fa5]+[a-zA-z]+)|(/[a-zA-z]+[\u4e00-\u9fa5]+)|(/[\u4e00-\u9fa5]+)|(/[a-zA-z]+)|([a-zA-z]+/[\u4e00-\u9fa5]+)|([\u4e00-\u9fa5]+/[a-zA-z]+)|([a-zA-z]+/[a-zA-z]+)|([\u4e00-\u9fa5]+/[\u4e00-\u9fa5]+)|([\u4e00-\u9fa5]+[a-zA-z]+/)|([a-zA-z]+[\u4e00-\u9fa5]+/)|([\u4e00-\u9fa5]+/)|([a-zA-z]+/)|(/[\u4e00-\u9fa5]+)|(/[a-zA-z]+)|([\u4e00-\u9fa5]+)|([a-zA-z]+)|([\u4e00-\u9fa5]+[a-zA-z]+)|([a-zA-z]+[\u4e00-\u9fa5]+)";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES%@",regex];
    if ([predicate evaluateWithObject:trimmedString] == YES) {
        return YES;
    }
    return NO;
}
//判断是否是中文
+ (BOOL)isChineseCardHolder:(NSString *)string{
    
    if([Util isNilOrEmptyString:string]){
        return NO;
    }
    
    NSString *trimmedString = [string stringByTrimmingCharactersInSet:                                   [NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *regex = @"([\u4e00-\u9fa5]+)";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES%@",regex];
    if ([predicate evaluateWithObject:trimmedString] == YES) {
        return YES;
    }
    return NO;
}
//判断是否是英文
+ (BOOL)isEnglishCardHolder:(NSString *)string{
    
    if([Util isNilOrEmptyString:string]){
        return NO;
    }
    
    NSString *trimmedString = [string stringByTrimmingCharactersInSet:                                   [NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *regex = @"([a-zA-z]+/[a-zA-z]+)";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES%@",regex];
    if ([predicate evaluateWithObject:trimmedString] == YES) {
        return YES;
    }
    return NO;
}
//判断是否是中文+英文
+ (BOOL)isChineseAndEnglishCardHolder:(NSString *)string{
    
    if([Util isNilOrEmptyString:string]){
        return NO;
    }
    
    NSString *trimmedString = [string stringByTrimmingCharactersInSet:                                   [NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *regex = @"([\u4e00-\u9fa5]+[a-zA-z]+)";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES%@",regex];
    if ([predicate evaluateWithObject:trimmedString] == YES) {
        return YES;
    }
    return NO;
}
//判断是否是英文 + 中文
+ (BOOL)isEnglishAndChineseCardHolder:(NSString *)string{
    
    if([Util isNilOrEmptyString:string]){
        return NO;
    }
    
    NSString *trimmedString = [string stringByTrimmingCharactersInSet:                                   [NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *regex = @"([a-zA-z]+[\u4e00-\u9fa5]+)";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES%@",regex];
    if ([predicate evaluateWithObject:trimmedString] == YES) {
        return YES;
    }
    return NO;
}
//判断是否是 中文/中文 或/中文 或中文/
+ (BOOL)isChineseAndChineseCardHolder:(NSString *)string{
    
    if([Util isNilOrEmptyString:string]){
        return NO;
    }
    
    NSString *trimmedString = [string stringByTrimmingCharactersInSet:                                   [NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *regex = @"([\u4e00-\u9fa5]+\\/|\\/[\u4e00-\u9fa5]+)";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES%@",regex];
    if ([predicate evaluateWithObject:trimmedString] == YES) {
        return YES;
    }
    return NO;
}
//判断是否是 /英文
+ (BOOL)isEnglishErrorTypeOneHolder:(NSString *)string{
    
    if([Util isNilOrEmptyString:string]){
        return NO;
    }
    
    NSString *trimmedString = [string stringByTrimmingCharactersInSet:                                   [NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *regex = @"(/[a-zA-z]+)|([a-zA-z]+/)";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES%@",regex];
    if ([predicate evaluateWithObject:trimmedString] == YES) {
        return YES;
    }
    return NO;
}
//判断是否是 /中文+英文 或 中文/英文 或中文+英文/
+ (BOOL)isEnglishAndChineseErrorTypeOneHolder:(NSString *)string{
    
    if([Util isNilOrEmptyString:string]){
        return NO;
    }
    
    NSString *trimmedString = [string stringByTrimmingCharactersInSet:                                   [NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *regex = @"([\u4e00-\u9fa5]+[a-zA-z]+)";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES%@",regex];
    if ([predicate evaluateWithObject:trimmedString] == YES) {
        return YES;
    }
    return NO;
}
//判断是否是 英文+中文
+ (BOOL)isEnglishAndChineseErrorTypeTowHolder:(NSString *)string{
    
    if([Util isNilOrEmptyString:string]){
        return NO;
    }
    
    NSString *trimmedString = [string stringByTrimmingCharactersInSet:                                   [NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *regex = @"([a-zA-z]+[\u4e00-\u9fa5]+)|([a-zA-z]+[\u4e00-\u9fa5]+\\/)";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES%@",regex];
    if ([predicate evaluateWithObject:trimmedString] == YES) {
        return YES;
    }
    return NO;
}

//判断是否只包含字母和数字
+ (BOOL)isOnlyLetterAndNum:(NSString *)string{
    
    if([Util isNilOrEmptyString:string]){
        return NO;
    }
    NSCharacterSet*cs;
    cs = [[NSCharacterSet characterSetWithCharactersInString:kAlphaNum]invertedSet];
    NSString*filtered =
    [[string componentsSeparatedByCharactersInSet:cs]componentsJoinedByString:@""];
    BOOL basic = [string isEqualToString:filtered];
    return basic;
}
//判断是否只包含字母
+ (BOOL)isOnlyLetter:(NSString *)string{
    
    if([Util isNilOrEmptyString:string]){
        return NO;
    }
    NSString *regex = @"([a-zA-z]+)";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", regex];
    
    if ([predicate evaluateWithObject:string] == YES) {
        return YES;
    }
    
    return NO;
}
//判断是否只包含数字
+ (BOOL)isOnlyNum:(NSString *)string{
    
    if([Util isNilOrEmptyString:string]){
        return NO;
    }
    NSCharacterSet*cs;
    cs = [[NSCharacterSet characterSetWithCharactersInString:kNum]invertedSet];
    NSString*filtered =
    [[string componentsSeparatedByCharactersInSet:cs]componentsJoinedByString:@""];
    BOOL basic = [string isEqualToString:filtered];
    return basic;
    
    return NO;
}
+ (NSString *)getStringFromString:(NSString *)string indexOf:(NSInteger)index{
	return nil;
}
+ (NSString *)getStringReplaceNil:(NSString *)string toString:(NSString *)stuff{
	if ([Util isNilOrEmptyString:string]) {
		return ![Util isNilOrEmptyString:stuff] ? stuff : @"";
	}
    return string;
}


+ (BOOL)iOs4OrGreater{
    static BOOL didCheckIfOnOS4 = NO;
    static BOOL runningOnOS4OrBetter = NO;
    
    if (!didCheckIfOnOS4) {
        NSString *systemVersion = [UIDevice currentDevice].systemVersion;
        NSInteger majorSystemVersion = 3;
        
        if (systemVersion != nil && [systemVersion length] > 0) { //Can't imagine it would be empty, but.
            NSString *firstCharacter = [systemVersion substringToIndex:1];
            majorSystemVersion = [firstCharacter integerValue];			
        }
        
        runningOnOS4OrBetter = (majorSystemVersion >= 4);
        didCheckIfOnOS4 = YES;
    }
    return runningOnOS4OrBetter;
}

//判断是否是有效的身份证号码
+ (BOOL)isValidateIDCardNo:(NSString *)string{
    if ([string length]!=18) {
        return NO;
    }
    
    for (int i=0; i<[string length]-1; i++) {
        if (![Util isVerificationNumber:[string substringWithRange:NSMakeRange(i, 1)]]) {
            return NO;
        }
    }
    
    return YES;
}
+ (BOOL)isValidateChild:(NSString *)string{
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat: @"yyyyMMdd"];
    NSString *today = [dateFormatter stringFromDate:[NSDate date]];
    int year = [[today substringToIndex:4] intValue];
    NSDate *minDate = [dateFormatter dateFromString:[NSString stringWithFormat:@"%i%@",(year-12),[today substringFromIndex:4]]];
    NSDate *maxDate = [dateFormatter dateFromString:[NSString stringWithFormat:@"%i%@",(year-2),[today substringFromIndex:4]]];
    NSDate *birthday = [dateFormatter dateFromString:[string substringWithRange:NSMakeRange(6, 8)]];
    if ([[birthday laterDate:minDate] isEqualToDate:birthday]&&[[birthday earlierDate:maxDate] isEqualToDate:birthday]) {
        return YES;
    }
    return NO;
}

+ (NSString *)returnSeatNumStatus:(NSString *)str{
    NSString *newStr;
    if ([str isEqualToString:@"0"]) {
        newStr=@"售罄";
    }else if([str isEqualToString:@"1"]) {
        newStr=str;
    }else if ([str isEqualToString:@"2"]) {
        newStr=str;
    }else if ([str isEqualToString:@"3"]) {
        newStr=str;
    }else if ([str isEqualToString:@"4"]) {
        newStr=str;
    }else if ([str isEqualToString:@"5"]) {
        newStr=str;
    }else if ([str isEqualToString:@"6"]) {
        newStr=str;
    }else if ([str isEqualToString:@"7"]) {
        newStr=str;
    }else if ([str isEqualToString:@"8"]) {
        newStr=str;
    }else if ([str isEqualToString:@"9"]) {
        newStr=str;
    }else{
        newStr=@">9";
    }
    newStr=[NSString stringWithFormat:@"%@张",newStr];
    return newStr;
}

+ (NSString *)returnAirCraft:(NSString *)str{
    NSString *newStr;
    NSMutableSet *bigAirCraft = [[NSMutableSet alloc] initWithObjects:@"77W",@"747",@"741",@"742",@"74M",@"74C",@"743",@"74D",@"744",@"74E",@"74L",@"74R",@"767",@"76A",@"762",@"763",@"764",@"777",@"77B",@"772",@"77S",@"773",@"77A",@"788",@"789",@"783",@"787",@"330",@"336",@"300",@"AB3",@"AB6",@"310",@"33A",@"330",@"332",@"334",@"333",@"335",@"340",@"342",@"343",@"345",@"346",@"380",@"388",@"M11", @"ILW", nil];
    NSMutableSet *middleAirCraft = [[NSMutableSet alloc] initWithObjects:@"190",@"E90",@"70M",@"717",@"703",@"707",@"72M",@"721",@"722",@"72S",@"737",@"731",@"73S",@"73M",@"732",@"733",@"734",@"735",@"736",@"73G",@"73H",@"738",@"739",@"73L",@"757",@"752",@"75B",@"753",@"323",@"310",@"32A",@"312",@"313",@"318",@"319",@"325",@"320",@"321",@"M82",@"M90",@"TU5",@"TU54",@"YK2",@"727",@"146",@"141",@"142",@"143", nil];
    NSMutableSet *smallAirCraft = [[NSMutableSet alloc] initWithObjects:@"EMB",@"AN4",@"CRJ",@"SF3",@"ATR", @"YN7", nil];
    if ([bigAirCraft containsObject:str]) {
        newStr=@"大";
    }else if([middleAirCraft containsObject:str]) {
        newStr=@"中";
    }else if ([smallAirCraft containsObject:str]) {
        newStr=@"小";
    }else{
        newStr=@"";
    }
    [bigAirCraft release];
    [middleAirCraft release];
    [smallAirCraft release];
    return newStr;
}

+(int)returnFinalNumber:(int)i{
    int r;
    r = i%10;
    i-=r;
    if(r>=5)
    {
        i+=10;
    }
    return i;
}

+(NSString *)readDataFromFile:(NSString *)fileName{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *filep=[documentsDirectory stringByAppendingPathComponent:fileName];
    if (MANGOCITY_DEBUG_FLAG) {
        NSLog(@"paths:%@ ,%@",paths,filep);
    }
    NSFileManager *fileManager=[[NSFileManager alloc] init];
    if ([fileManager fileExistsAtPath:filep]) {
        NSFileHandle *file = [NSFileHandle fileHandleForReadingAtPath:  filep];
        NSData *data = [file readDataToEndOfFile];
        NSString* aStr;
        aStr = [[NSString alloc] initWithData: data encoding: NSUTF8StringEncoding];
        return aStr;
    }
    return @"";
}

+(NSString *)writeDataToFile:(NSString *)fileName writeData:(NSString *)dataString{
    //确认数据已经接收正确，开始写文件
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *documentsDirectory = [paths objectAtIndex:0];
    NSString *filep=[documentsDirectory stringByAppendingPathComponent:fileName];
    NSFileManager *fileManager=[[NSFileManager alloc] init];
    [fileManager createFileAtPath:filep contents:nil attributes:nil];
    if ([dataString writeToFile:filep atomically:YES encoding:NSUTF8StringEncoding error:nil]) {
        return @"successed!";
    }else{
        return @"Failed!";
    }
}

/**
 *  判断年龄
 *
 *  @param string 身份证号
 *  @param time   需要和身份证对比的时间
 *
 *  @return 返回对比出来的年龄
 */
+ (NSInteger)isValidateChild:(NSString *)string buyTime:(NSString*)time
{
    
    time = [time stringByReplacingOccurrencesOfString:@"-" withString:@""];
    NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
    [dateFormatter setDateFormat:@"yyyyMMdd"];
    NSRange monthRang = NSMakeRange(6, 8);
    NSString *monthStr = [string substringWithRange:monthRang];
    NSDate *birthday = [dateFormatter dateFromString:monthStr];
    NSDate *buyDate = [dateFormatter dateFromString:time];
    NSCalendar *userCalendar = [NSCalendar currentCalendar];
    unsigned int unitFlags = NSYearCalendarUnit;
    NSDateComponents *components = [userCalendar components:unitFlags fromDate:birthday toDate:buyDate options:0];
    CGFloat years = [components year];
    return years;
}
/**
 * 常用信用卡卡号规则
 * Issuer Identifier  Card Number                            Length
 * Diner's Club       300xxx-305xxx, 3095xx, 36xxxx, 38xxxx  14
 * American Express   34xxxx, 37xxxx                         15
 * VISA               4xxxxx                                 13, 16
 * MasterCard         51xxxx-55xxxx                          16
 * JCB                3528xx-358xxx                          16
 * Discover           6011xx                                 16
 * 银联                622126-622925                          16
 *
 * 信用卡号验证基本算法：
 * 偶数位卡号奇数位上数字*2，奇数位卡号偶数位上数字*2。
 * 大于10的位数减9。
 * 全部数字加起来。
 * 结果不是10的倍数的卡号非法。*  判断信用卡
 */
+ (BOOL) isValidCreditNumber:(NSString*)value
{
    BOOL result = TRUE;
    NSInteger length = [value length];
    if (length >= 13)
    {
        result = [self isValidNumber:value];
        if (result)
        {
            NSInteger twoDigitBeginValue = [[value substringWithRange:NSMakeRange(0, 2)] integerValue];
            NSInteger threeDigitBeginValue = [[value substringWithRange:NSMakeRange(0, 3)] integerValue];
            NSInteger fourDigitBeginValue = [[value substringWithRange:NSMakeRange(0, 4)] integerValue];
            //Diner's Club
            if (((threeDigitBeginValue >= 300 && threeDigitBeginValue <= 305)||
                 fourDigitBeginValue == 3095||twoDigitBeginValue==36||twoDigitBeginValue==38) && (14 != length))
            {
                result = FALSE;
            }
            //VISA
            else if([value isStartWithString:@"4"] && !(13 == length||16 == length))
            {
                result = FALSE;
            }
            //MasterCard
            else if((twoDigitBeginValue >= 51||twoDigitBeginValue <= 55) && (16 != length))
            {
                result = FALSE;
            }
            //American Express
            else if(([value isStartWithString:@"34"]||[value isStartWithString:@"37"]) && (15 != length))
            {
                result = FALSE;
            }
            //Discover
            else if([value isStartWithString:@"6011"] && (16 != length))
            {
                result = FALSE;
            }
            else
            {
                NSInteger begin = [[value substringWithRange:NSMakeRange(0, 6)] integerValue];
                //CUP
                if ((begin >= 622126 && begin <= 622925) && (16 != length))
                {
                    result = FALSE;
                }
                //other
                else
                {
                    result = TRUE;
                }
            }
        }
        if (result)
        {
            NSInteger digitValue;
            NSInteger checkSum = 0;
            NSInteger index = 0;
            NSInteger leftIndex;
            //even length, odd index
            if (0 == length%2)
            {
                index = 0;
                leftIndex = 1;
            }
            //odd length, even index
            else
            {
                index = 1;
                leftIndex = 0;
            }
            while (index < length)
            {
                digitValue = [[value substringWithRange:NSMakeRange(index, 1)] integerValue];
                digitValue = digitValue*2;
                if (digitValue >= 10)
                {
                    checkSum += digitValue/10 + digitValue%10;
                }
                else
                {
                    checkSum += digitValue;
                }
                digitValue = [[value substringWithRange:NSMakeRange(leftIndex, 1)] integerValue];
                checkSum += digitValue;
                index += 2;
                leftIndex += 2;
            }
            result = (0 == checkSum%10) ? TRUE:FALSE;
        }
    }
    else
    {
        result = FALSE;
    }
    return result;
}
+ (BOOL) isValidNumber:(NSString*)value{
    const char *cvalue = [value UTF8String];
    int len = (int)strlen(cvalue);
    for (int i = 0; i < len; i++) {
        if(!isnumber(cvalue[i])){
            return FALSE;
        }
    }
    return TRUE;
}
@end
