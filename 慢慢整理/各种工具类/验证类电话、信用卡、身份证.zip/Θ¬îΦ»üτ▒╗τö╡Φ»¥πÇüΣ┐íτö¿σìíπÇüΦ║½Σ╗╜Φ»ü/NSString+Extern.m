//
//  NSString+Extern.m
//  CIOS
//
//  Created by xh on 13-9-5.
//  Copyright (c) 2013年 xh. All rights reserved.
//

#import "NSString+Extern.h"
#import <commoncrypto/CommonDigest.h>
#import "QFSystemInfo.h"

@implementation NSString (Extern)

- (BOOL)isEmptyString
{
    return (nil == self) || (self.length == 0);
}

- (BOOL)isEmptyStringTrim
{
    return [[self trim] isEmptyString];
}

- (NSString *)trim
{
   return [self stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
}

- (NSString *)removeLast
{
    if (self.length > 1)
    {
        self = [self substringWithRange:NSMakeRange(0, self.length - 1)];
    }
    
    return self;
}

#pragma mark -
#pragma mark - http://

- (NSString *)httpUrl
{
    if ([self isEmptyStringTrim])
    {
        return nil;
    }
    
    if ([self hasPrefix:@"http://"])
    {
        return self;
    }
    else
    {
        return [NSString stringWithFormat:@"http://%@", [self trim]];
    }
}

#pragma mark -
#pragma mark -- has substring
// options yes 忽略大小写
- (BOOL)hasSubString:(NSString *)aString options:(BOOL)bIgnore
{
    if ([aString isEmptyString])
    {
        return NO;
    }
    
    NSRange range;
    if (bIgnore)
    {
       range = [self rangeOfString:aString options:NSCaseInsensitiveSearch
         | NSNumericSearch];
    }
    else
    {
        range = [self rangeOfString:aString];
    }
    
    if (range.length == 0)
    {
        return NO;
    }
    
    return YES;
}

// 检查中文
- (BOOL)containChinese
{
    NSString *Chinese = @"^[\\u4e00-\\u9fa5]+$";
    NSPredicate *regextestct = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", Chinese];
    
    if ([regextestct evaluateWithObject:self] == YES)
    {
        return YES;
    }
    
    return NO;
}

- (NSString*)md5
{
    if(nil == self)
        return nil;
    
    const char*cStr =[self UTF8String];
    unsigned char result[16];
    CC_MD5(cStr, strlen(cStr), result);
    return[NSString stringWithFormat:@"%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X%02X",
           result[0], result[1], result[2], result[3],
           result[4], result[5], result[6], result[7],
           result[8], result[9], result[10], result[11],
           result[12], result[13], result[14], result[15]
           ];
}


// 检查是否为中英文混合 或者中文 英文
- (BOOL)isChineseEnglish
{
    if([CommonCode NSStringIsNULL:self])
    {
        return NO;
    }
    
    NSString *trimmedString = [self stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *regex = @"([\u4e00-\u9fa5]+[a-zA-z]+)|([a-zA-z]+[\u4e00-\u9fa5]+)|([\u4e00-\u9fa5]+)|([a-zA-z]+)";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES%@",regex];
    if ([predicate evaluateWithObject:trimmedString] == YES)
    {
        return YES;
    }
    
    return NO;
}

// 纯中文
- (BOOL)isChinese
{
    if([CommonCode NSStringIsNULL:self])
    {
        return NO;
    }
    
    NSString *trimmedString = [self stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *regex = @"([\u4e00-\u9fa5]+)";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES%@",regex];
    if ([predicate evaluateWithObject:trimmedString] == YES)
    {
        return YES;
    }
    
    return NO;
}

// 检查是否为汉字或者汉字加拼音
- (BOOL)isChineseOrEnglish
{
    if([CommonCode NSStringIsNULL:self])
    {
        return NO;
    }
    
    NSString *trimmedString = [self stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *regex = @"([\u4e00-\u9fa5]+[a-zA-z]+)|([\u4e00-\u9fa5]+)";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES%@",regex];
    if ([predicate evaluateWithObject:trimmedString] == YES)
    {
        return YES;
    }
    
    return NO;
}

// 中英文混合
- (BOOL)isChineseAndEnglish
{
    if([CommonCode NSStringIsNULL:self])
    {
        return NO;
    }
    
    NSString *trimmedString = [self stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *regex = @"([\u4e00-\u9fa5]+[a-zA-z]+)";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES%@",regex];
    if ([predicate evaluateWithObject:trimmedString] == YES)
    {
        return YES;
    }
    
    return NO;
}

// 检查是否为英文+汉字
- (BOOL)isEnglishChinese
{
    if([CommonCode NSStringIsNULL:self])
    {
        return NO;
    }
    
    NSString *trimmedString = [self stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *regex = @"([a-zA-z]+[\u4e00-\u9fa5]+)";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES%@",regex];
    if ([predicate evaluateWithObject:trimmedString] == YES)
    {
        return YES;
    }
    
    return NO;
}

// 检查是否为纯英文
- (BOOL)isEnglish
{
    if([CommonCode NSStringIsNULL:self])
    {
        return NO;
    }
    
    NSString *trimmedString = [self stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *regex = @"([a-zA-z]+)";
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF MATCHES%@",regex];
    if ([predicate evaluateWithObject:trimmedString] == YES)
    {
        return YES;
    }
    
    return NO;
}


- (BOOL)isIPAddress
{
    NSArray *			components = [self componentsSeparatedByString:@"."];
    NSCharacterSet *	invalidCharacters = [[NSCharacterSet characterSetWithCharactersInString:@"1234567890"] invertedSet];
    
    if ( [components count] == 4 )
    {
        NSString *part1 = [components objectAtIndex:0];
        NSString *part2 = [components objectAtIndex:1];
        NSString *part3 = [components objectAtIndex:2];
        NSString *part4 = [components objectAtIndex:3];
        
        if ( 0 == [part1 length] ||
            0 == [part2 length] ||
            0 == [part3 length] ||
            0 == [part4 length] )
        {
            return NO;
        }
        
        if ( [part1 rangeOfCharacterFromSet:invalidCharacters].location == NSNotFound &&
            [part2 rangeOfCharacterFromSet:invalidCharacters].location == NSNotFound &&
            [part3 rangeOfCharacterFromSet:invalidCharacters].location == NSNotFound &&
            [part4 rangeOfCharacterFromSet:invalidCharacters].location == NSNotFound )
        {
            if ( [part1 intValue] <= 255 &&
                [part2 intValue] <= 255 &&
                [part3 intValue] <= 255 &&
                [part4 intValue] <= 255 )
            {
                return YES;
            }
        }
    }
    
    return NO;
}

// 字符串包含
- (BOOL)containAString:(NSString *)aString
{
    if([CommonCode NSStringIsNULL:aString]) return NO;
    
    if (IOS8_OR_LATER)
    {
        return [self containsString:aString];
    }
    
    NSRange range = [self rangeOfString:aString];
    if (range.length > 0)
    {
        return YES;
    }
    return NO;
}
// 匹配头部字符
- (BOOL)isStartWithString:(NSString *)str {
    if (str.length>self.length) {
        return NO;
    }
    if ([[self substringToIndex:str.length-1] isEqualToString:str]) {
        return YES;
    }
    return NO;
}
@end
