//
//  NSString+Extern.h
//  CIOS
//
//  Created by xh on 13-9-5.
//  Copyright (c) 2013年 xh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Extern)

- (NSString *)trim;// 去掉前后空格
- (BOOL)isEmptyStringTrim;
- (BOOL)isEmptyString;

- (NSString *)removeLast;

// http://
- (NSString *)httpUrl;

// 包含字串
// options yes 忽略大小写
- (BOOL)hasSubString:(NSString *)aString options:(BOOL)bIgnore;

- (BOOL)containChinese;

- (NSString*)md5;


// 检查是否为中英文混合 或中文、英文
- (BOOL)isChineseEnglish;

// 纯中文
- (BOOL)isChinese;

// 中英文混合
- (BOOL)isChineseAndEnglish;

// 检查是否为汉字或者汉字加拼音
- (BOOL)isChineseOrEnglish;

// 检查是否为纯英文
- (BOOL)isEnglish;

// 检查是否为英文+汉字
- (BOOL)isEnglishChinese;

// 检查是否为ip地址
- (BOOL)isIPAddress;

// 字符串包含
- (BOOL)containAString:(NSString *)aString;

// 匹配头部字符
- (BOOL)isStartWithString:(NSString *)str;
@end
