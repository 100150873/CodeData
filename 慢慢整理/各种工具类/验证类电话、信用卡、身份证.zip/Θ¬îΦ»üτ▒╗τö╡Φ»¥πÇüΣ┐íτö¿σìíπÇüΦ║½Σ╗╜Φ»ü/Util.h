//
//  Util.h
//  MangoCity
//
//  Created by liu jianfeng on 11-4-2.
//  Copyright 2011 mangocity. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Util : NSObject {

}

//完成guestInfo保存和读取操作
//+(id)loadGuestInfo;
+(void)setGuestInfo;
+(NSMutableArray *)guestInfoArray;

+ (BOOL)checkIDfromchar:(char *)ID;
+ (int)checkID:(char *)IDNumber IDchar:(char *)IDchar;
+ (BOOL)isNilOrEmptyString:(NSString *)string;
+ (BOOL)isVerificationMobileNo:(NSString *)string;
+ (BOOL)isVerificationNumber:(NSString *)string;
+ (BOOL)isVerificationPwd:(NSString *)string;
+ (BOOL)isValidateCreditCardNo:(NSString *)string;
+ (BOOL)isVerificationCardHolder:(NSString *)string;
+ (BOOL)isUseFullNameHolder:(NSString *)string;
+ (BOOL)isChineseCardHolder:(NSString *)string;
+ (BOOL)isEnglishCardHolder:(NSString *)string;
+ (BOOL)isChineseAndEnglishCardHolder:(NSString *)string;
+ (BOOL)isEnglishAndChineseCardHolder:(NSString *)string;
+ (BOOL)isChineseAndChineseCardHolder:(NSString *)string;
+ (BOOL)isEnglishErrorTypeOneHolder:(NSString *)string;
+ (BOOL)isEnglishAndChineseErrorTypeOneHolder:(NSString *)string;
+ (BOOL)isEnglishAndChineseErrorTypeTowHolder:(NSString *)string;
+ (BOOL)isOnlyLetterAndNum:(NSString *)string;
+ (BOOL)isOnlyLetter:(NSString *)string;
+ (BOOL)isOnlyNum:(NSString *)string;
+ (BOOL)isValidateIDCardNo:(NSString *)string;//身份证校验方法（旧）
+ (BOOL)validateIDCardNumber:(NSString *)value;//身份证校验方法
+ (NSString *)getStringFromString:(NSString *)string indexOf:(NSInteger)index;
+ (NSString *)getStringReplaceNil:(NSString *)string toString:(NSString *)stuff;
+ (BOOL)iOs4OrGreater;
+ (BOOL)isValidateChild:(NSString *)string;
+ (NSString *)returnSeatNumStatus:(NSString *)str;
+ (NSString *)returnAirCraft:(NSString *)str;
+(int)returnFinalNumber:(int)i;
+(NSString *)readDataFromFile:(NSString *)fileName;
+(NSString *)writeDataToFile:(NSString *)fileName writeData:(NSString *)dataString;

/**
 *  判断年龄
 *
 *  @param string 身份证号
 *  @param time   需要和身份证对比的时间
 *
 *  @return 返回对比出来的年龄
 */
+ (NSInteger)isValidateChild:(NSString *)string buyTime:(NSString*)time;
/**
 *  判断信用卡
 *
 */

+ (BOOL) isValidCreditNumber:(NSString*)value;
@end
