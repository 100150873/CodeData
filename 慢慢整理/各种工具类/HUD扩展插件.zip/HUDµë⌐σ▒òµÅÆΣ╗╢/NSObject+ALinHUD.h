//
//  NSObject+ALinHUD.h
//  MiaowShow
//
//  Created by ALin on 16/6/29.
//  Copyright © 2016年 ALin. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (ALinHUD)
- (void)showInfo:(NSString *)info;
@end
