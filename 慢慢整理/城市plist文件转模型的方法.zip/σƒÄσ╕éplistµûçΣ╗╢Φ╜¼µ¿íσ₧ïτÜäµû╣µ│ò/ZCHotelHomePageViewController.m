- (NSArray<CDGroupCity *> *)cdAllCityGroupsDataOnSelectedController:(CDCitySelectedViewController *)controller
{
    
    NSDictionary *hotelCityDictionary = [NSDictionary dictionaryWithContentsOfFile:[[NSBundle mainBundle] pathForResource:@"hotel-city" ofType:@"plist"]];
    NSArray *keyArray = [hotelCityDictionary allKeys];
    NSMutableArray *allGroups = [[NSMutableArray alloc] init];
    for (NSString *key in keyArray) {
        CDGroupCity *group = [[CDGroupCity alloc] init];
        group.key = key;
        NSMutableArray *citys = [[NSMutableArray alloc] init];
        NSArray *valueArray = [hotelCityDictionary objectForKey:key];
        for (NSString *descrip in valueArray) {
            CDCity *cityModel = [[CDCity alloc] init];
            cityModel.groupKey = key;
            NSArray *descripArray = [descrip componentsSeparatedByString:@","];
            cityModel.cityId = [descripArray objectAtIndex:0];
            cityModel.name = [descripArray objectAtIndex:1];
            cityModel.charCode = [descripArray objectAtIndex:2];
            cityModel.charCodeAbb = [descripArray objectAtIndex:3];
            [citys addObject:cityModel];
        }
        
        if ([citys count] > 0) {
            group.cityModels = [NSArray arrayWithArray:[citys sortedArrayUsingDescriptors:@[[NSSortDescriptor sortDescriptorWithKey:@"name" ascending:YES]]]];
            [allGroups addObject:group];
        }
        
    }
    
    NSMutableArray *tempAll = [NSMutableArray arrayWithArray:[allGroups sortedArrayUsingDescriptors:@[[NSSortDescriptor sortDescriptorWithKey:@"key" ascending:YES]]]];
    CDGroupCity *lastGroup = [tempAll lastObject];
    [tempAll insertObject:lastGroup atIndex:0];
    [tempAll removeLastObject];
    return tempAll;
    
}

