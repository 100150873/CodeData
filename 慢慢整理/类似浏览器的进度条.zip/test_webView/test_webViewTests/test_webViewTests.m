//
//  test_webViewTests.m
//  test_webViewTests
//
//  Created by wmh on 16/2/3.
//  Copyright © 2016年 APPlE. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface test_webViewTests : XCTestCase

@end

@implementation test_webViewTests

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample {
    // This is an example of a functional test case.
    // Use XCTAssert and related functions to verify your tests produce the correct results.
}

- (void)testPerformanceExample {
    // This is an example of a performance test case.
    [self measureBlock:^{
        // Put the code you want to measure the time of here.
    }];
}

@end
