//
//  ViewController.m
//  test_webView
//
//  Created by wmh on 16/2/3.
//  Copyright © 2016年 APPlE. All rights reserved.
//

#import "ViewController.h"
#import "NJKWebViewProgress.h"
#import "NJKWebViewProgressView.h"

@interface ViewController ()<UIWebViewDelegate,NJKWebViewProgressDelegate>

@end

@implementation ViewController
{
NJKWebViewProgressView *_webViewProgressView;
NJKWebViewProgress *_webViewProgress;
UIWebView *webView;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self setreturnBtn];
    [self setUpWebView];
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.navigationController.navigationBar addSubview:_webViewProgressView];
}
-(void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [_webViewProgressView removeFromSuperview];
}
-(void)setreturnBtn{
    UIButton *btn = [[UIButton alloc]initWithFrame:CGRectMake(15, 10, 50, 40)];
    [btn setTitle:@"返回" forState:UIControlStateNormal];
    [btn setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
    [btn addTarget:self action:@selector(getBack) forControlEvents:UIControlEventTouchUpInside];
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc]initWithCustomView:btn];
    self.navigationItem.leftBarButtonItem = leftItem;
}
-(void)getBack{
    [webView goBack];
}
-(void)setUpWebView{
    webView = [[UIWebView alloc] initWithFrame:CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height)];
    webView.frame = CGRectMake(0, 0, [UIScreen mainScreen].bounds.size.width, [UIScreen mainScreen].bounds.size.height);
    webView.delegate = self;
    [self.view addSubview:webView];
    
    _webViewProgress = [[NJKWebViewProgress alloc] init];
    webView.delegate = _webViewProgress;
    _webViewProgress.webViewProxyDelegate = self;
    _webViewProgress.progressDelegate = self;
    
    CGRect navBounds = self.navigationController.navigationBar.bounds;
    CGRect barFrame = CGRectMake(0,
                                 navBounds.size.height - 2,
                                 navBounds.size.width,
                                 2);
    _webViewProgressView = [[NJKWebViewProgressView alloc] initWithFrame:barFrame];
    _webViewProgressView.autoresizingMask = UIViewAutoresizingFlexibleWidth | UIViewAutoresizingFlexibleTopMargin;
    [_webViewProgressView setProgress:0 animated:YES];
    [self.navigationController.navigationBar addSubview:_webViewProgressView];
    
    [self loadWebData];
}
-(void)loadWebData{
    NSURLRequest *request =[NSURLRequest requestWithURL:[NSURL URLWithString:@"http://www.apple.com/cn"]];
    [webView loadRequest:request];
}
#pragma mark - NJKWebViewProgressDelegate
-(void)webViewProgress:(NJKWebViewProgress *)webViewProgress updateProgress:(float)progress
{
    [_webViewProgressView setProgress:progress animated:YES];
    self.title = [webView stringByEvaluatingJavaScriptFromString:@"document.title"];
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
