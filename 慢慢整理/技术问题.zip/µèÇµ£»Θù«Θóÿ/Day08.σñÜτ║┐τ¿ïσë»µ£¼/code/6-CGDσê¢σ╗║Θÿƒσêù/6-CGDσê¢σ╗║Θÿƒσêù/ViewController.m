//
//  ViewController.m
//  6-CGD创建队列
//
//  Created by qianfeng on 15/12/24.
//  Copyright (c) 2015年 李庆生. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //取得主队列
    dispatch_queue_t mainQueue =  dispatch_get_main_queue();
    
    //获取全局并行队列，唯一的并行队列，由系统开启
    dispatch_queue_t globalQueue =
    dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    
    //自定义的队列
    //DISPATCH_QUEUE_SERIAL: 串行队列
    //DISPATCH_QUEUE_CONCURRENT 并行队列
    dispatch_queue_t queue =
    dispatch_queue_create("create_queue", DISPATCH_QUEUE_SERIAL);
    

    //执行任务
    //dispatch_async 异步执行
    dispatch_async(globalQueue, ^{
        NSLog(@"1当前的线程: %@", [NSThread currentThread]);
        for (NSInteger i = 0; i < 10; i ++) {
            NSLog(@"任务 1");
            [NSThread sleepForTimeInterval:1.0];
        }
    });
    
    dispatch_async(globalQueue, ^{
        NSLog(@"2当前的线程 %@", [NSThread currentThread]);
        for (NSInteger i = 0; i < 10; i ++) {
            NSLog(@"任务 2");
            [NSThread sleepForTimeInterval:1];
        }
    });
    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end






