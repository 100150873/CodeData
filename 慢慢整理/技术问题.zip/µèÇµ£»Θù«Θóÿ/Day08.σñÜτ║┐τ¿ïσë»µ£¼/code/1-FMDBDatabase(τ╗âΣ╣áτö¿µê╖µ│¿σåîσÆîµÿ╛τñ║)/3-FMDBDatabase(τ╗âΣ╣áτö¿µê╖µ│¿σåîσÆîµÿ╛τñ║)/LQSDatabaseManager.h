//
//  LQSDatabaseManager.h
//  3-FMDBDatabase(练习用户注册和显示)
//
//  Created by qianfeng on 15/12/23.
//  Copyright (c) 2015年 李庆生. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "UserModel.h"

@interface LQSDatabaseManager : NSObject


+ (instancetype)shareInstance;

//+ (instancetype)defaultInstance;


//插入数据
- (BOOL)insertDatabaseWithUser:(UserModel *)user;

//删除数据
- (BOOL)deleteDatabaseWithUserName:(NSString *)userName;

//更新数据
- (BOOL)updateDateBaseWithUser:(UserModel *)user;

//返回所有的数据
- (NSArray *)getAllUserFromDatabase;


@end
