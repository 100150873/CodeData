//
//  EditViewController.m
//  3-FMDBDatabase(练习用户注册和显示)
//
//  Created by qianfeng on 15/12/24.
//  Copyright (c) 2015年 李庆生. All rights reserved.
//

#import "EditViewController.h"
#import "LQSDatabaseManager.h"

@interface EditViewController ()
@property (weak, nonatomic) IBOutlet UITextField *userNameTF;
@property (weak, nonatomic) IBOutlet UITextField *passwdTF;

@property (weak, nonatomic) IBOutlet UITextField *ageTF;

@end

@implementation EditViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    
    //判断当前是添加还是修改？
    if (self.user != nil) {
        self.userNameTF.enabled = NO;
        
        self.userNameTF.text = self.user.name;
        self.passwdTF.text = self.user.password;
        self.ageTF.text = [NSString stringWithFormat:@"%ld", self.user.age];
    }
    
    
}

- (void)updateDatabase
{
    NSString *passwold = self.passwdTF.text;
    NSString *age = self.ageTF.text;
    
    //去掉， 字符串两端的空格, 多用于登陆注册
    passwold = [passwold stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    age = [age stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    if (passwold.length == 0 || age.length == 0) {
        return;
    }
    
    
    //更新数据
    self.user.password = passwold;
    self.user.age = [age integerValue];
    BOOL ret = [[LQSDatabaseManager shareInstance] updateDateBaseWithUser:self.user];
    
    if (ret) {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"温馨提示" message:@"更新数据成功" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定并返回" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
            [self.navigationController popToRootViewControllerAnimated:YES];
        }];
        
        [alertController addAction:action];
        [self presentViewController:alertController animated:YES completion:nil];
    }
    
    
}

- (void)insertUserToDatabase
{
    NSString *name = self.userNameTF.text;
    NSString *passwd = self.passwdTF.text;
    NSString *age = self.ageTF.text;
    
    name = [name stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    passwd = [passwd stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    age = [age stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    
    if (name.length == 0 || passwd.length == 0) {
        return;
    }
    
    UserModel *model = [[UserModel alloc] init];
    model.name = name;
    model.password = passwd;
    model.age = [age integerValue];
    
    NSLog(@"--%@, %@, %@", name, passwd, age);
    
    BOOL ret = [[LQSDatabaseManager shareInstance] insertDatabaseWithUser:model];
    
    if (ret) {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"温馨提示" message:@"保存数据成功" preferredStyle:UIAlertControllerStyleAlert];
        UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定并返回" style:UIAlertActionStyleDefault handler:^(UIAlertAction *action) {
        
            //present/dismiss
            [self dismissViewControllerAnimated:YES completion:nil];
            
        
        }];
        
        [alertController addAction:action];
        [self presentViewController:alertController animated:YES completion:nil];
        
    }
    
    
}

- (IBAction)saveBtnClicked:(UIButton *)sender {
    
    if (self.user != nil) {
        //更新数据库
        [self updateDatabase];
        
    } else {
        //插入数据

        [self insertUserToDatabase];
    }
    
    
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
