//
//  LQSDatabaseManager.m
//  3-FMDBDatabase(练习用户注册和显示)
//
//  Created by qianfeng on 15/12/23.
//  Copyright (c) 2015年 李庆生. All rights reserved.
//

#import "LQSDatabaseManager.h"
#import "FMDB.h"


@interface LQSDatabaseManager ()

@property (nonatomic, strong) FMDatabase *database;
@property (nonatomic, copy) NSString *dbPath;
@end


//LQSDatabaseManager 设置称为一个单例的类
@implementation LQSDatabaseManager
//[LQSDatabaseManager shareInstance] insertDatabaseWithUser:model
+ (instancetype)shareInstance
{
    static LQSDatabaseManager *manager = nil;
    
    //同一个时间， 只允许一条线程访问{}里面的内容。
    @synchronized(self) {
        if (manager == nil) {
            manager = [[LQSDatabaseManager alloc] init];
        }
    }
    return manager;
}


- (instancetype)init
{
    self = [super init];
    if (self) {
        
        //创建数据库
        self.database = [FMDatabase databaseWithPath:self.dbPath];
        //创建表
        if ([self.database open]) {
            
            NSString *sqlStr =
            @"CREATE TABLE IF NOT EXISTS T_USER(\
                NAME TEXT PRIMARY KEY,\
                PASSWD TEXT,\
                AGE INTEGER\
            )";
            
            BOOL ret = [self.database executeUpdate:sqlStr];
            if (ret) {
                NSLog(@"创建用户的表成功!");
            } else {
                NSLog(@"创建用户的表失败!");
            }
            
            //关闭数据库
            [self.database close];
        }
        
    }
    
    return self;
}

- (NSString *)dbPath
{
    NSString *libPath = NSSearchPathForDirectoriesInDomains(NSLibraryDirectory, NSUserDomainMask, YES)[0];
    
    return [libPath stringByAppendingPathComponent:@"user.db"];
}



- (BOOL)insertDatabaseWithUser:(UserModel *)user
{
    if ([self.database open]) {
        
        NSString *sqlStr = @"INSERT INTO T_USER(NAME, PASSWD, AGE) VALUES(?, ?, ?)";
        
        BOOL success = [self.database executeUpdate:sqlStr, user.name, user.password, @(user.age)];
        
        [self.database close];
        
        if (success) {
            NSLog(@"插入用户到数据库成功!");
        
            return YES;
        }
        
        NSLog(@"插入用户到数据库失败!");
        return NO;
    }
    NSLog(@"在插入用户的时候， 打开数据库失败");
    return NO;
}



- (BOOL)deleteDatabaseWithUserName:(NSString *)userName
{
    if ([self.database open]) {
        NSString *sqlStr = @"DELETE FROM T_USER WHERE NAME = ?";
        
        BOOL success = [self.database executeUpdate:sqlStr, userName];
        
        [self.database close];
        
        if (success) {
            NSLog(@"从数据库删除用户成功!");
            
            return YES;
        }
        
        NSLog(@"从数据库删除用户失败!");
        return NO;
    }
    
    NSLog(@"在删除用户的时候， 打开数据库失败");
    return NO;
}


- (BOOL)updateDateBaseWithUser:(UserModel *)user
{
    if ([self.database open]) {
        NSString *sqlStr = @"UPDATE T_USER SET PASSWD=?, AGE=? WHERE NAME=?";
        
        BOOL success = [self.database executeUpdate:sqlStr, user.password, @(user.age), user.name];
        
        [self.database close];
        
        if (success) {
            NSLog(@"从数据库更新用户成功!");
            
            return YES;
        }
        
        NSLog(@"从数据库更新用户失败!");
        return NO;
    }
    
    NSLog(@"在更新用户的时候， 打开数据库失败");
    return NO;
}


- (NSArray *)getAllUserFromDatabase
{
    
    if ([self.database open]) {
        
        NSMutableArray *mutArray = [[NSMutableArray alloc] init];
        
        NSString *sqlStr = @"SELECT * FROM T_USER ORDER BY NAME ASC";
        FMResultSet *rSet = [self.database executeQuery:sqlStr];
        
        while ([rSet next]) {
            NSString *name = [rSet stringForColumn:@"NAME"];
            NSString *passwd = [rSet stringForColumn:@"PASSWD"];
            NSInteger age = [rSet longForColumn:@"AGE"];
            
            
            UserModel *model = [[UserModel alloc] init];
            model.name = name;
            model.password = passwd;
            model.age = age;
            
            [mutArray addObject:model];
        }
        
        
        [self.database close];
        return mutArray;
    }
    
    return nil;
}


@end










