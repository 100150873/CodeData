//
//  HomeTableViewController.m
//  3-FMDBDatabase(练习用户注册和显示)
//
//  Created by qianfeng on 15/12/24.
//  Copyright (c) 2015年 李庆生. All rights reserved.
//

#import "HomeTableViewController.h"
#import "LQSDatabaseManager.h"
#import "UserModel.h"
#import "EditViewController.h"

@interface HomeTableViewController ()

@property (nonatomic, strong) NSMutableArray *dataSource;

@end

@implementation HomeTableViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"用户信息";
    
    _dataSource = [[NSMutableArray alloc] init];
    
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithBarButtonSystemItem:UIBarButtonSystemItemAdd target:self action:@selector(addUser:)];
    
}


- (void)addUser:(UIBarButtonItem *)bbi
{
    EditViewController *editVC = [[EditViewController alloc] initWithNibName:@"EditViewController" bundle:nil];
    
    
    
    [self presentViewController:editVC animated:YES completion:nil];
}


- (void)viewWillAppear:(BOOL)animated
{
    
    //先清空数组
    [_dataSource removeAllObjects];
    
    
    //从数据库里面获取所有的用户;LQSDatabaseManager shareInstance封装的单例类
    NSArray *userArray = [[LQSDatabaseManager shareInstance] getAllUserFromDatabase];
    
    //将获取到的所有用户， 添加到数据源
    [_dataSource addObjectsFromArray:userArray];
    
    
    [self.tableView reloadData];
    
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
#warning Potentially incomplete method implementation.
    // Return the number of sections.
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
#warning Incomplete method implementation.
    // Return the number of rows in the section.
    return _dataSource.count;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"MyCell"];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:@"MyCell"];
    }
    
    
    // Configure the cell...
    UserModel *model = _dataSource[indexPath.row];
    
    
    cell.textLabel.text = model.name;
    cell.detailTextLabel.text = [NSString stringWithFormat:@"%ld", model.age];
    cell.detailTextLabel.textColor = [UIColor redColor];
    
    return cell;
}


- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    EditViewController *editVC = [[EditViewController alloc] initWithNibName:@"EditViewController" bundle:nil];
    
    editVC.user = _dataSource[indexPath.row];
    
    
    [self.navigationController pushViewController:editVC animated:YES];
}



// Override to support conditional editing of the table view.
- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the specified item to be editable.
    return YES;
}



// Override to support editing the table view.
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    UserModel *user = _dataSource[indexPath.row];
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        //删除数据库
        [[LQSDatabaseManager shareInstance] deleteDatabaseWithUserName:user.name];
        
        // Delete the row from the data source
        [_dataSource removeObjectAtIndex:indexPath.row];
        
        
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    } else if (editingStyle == UITableViewCellEditingStyleInsert) {
        // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
    }   
}


/*
// Override to support rearranging the table view.
- (void)tableView:(UITableView *)tableView moveRowAtIndexPath:(NSIndexPath *)fromIndexPath toIndexPath:(NSIndexPath *)toIndexPath {
}
*/

/*
// Override to support conditional rearranging of the table view.
- (BOOL)tableView:(UITableView *)tableView canMoveRowAtIndexPath:(NSIndexPath *)indexPath {
    // Return NO if you do not want the item to be re-orderable.
    return YES;
}
*/

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
