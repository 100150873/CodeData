//
//  UserModel.m
//  3-FMDBDatabase(练习用户注册和显示)
//
//  Created by qianfeng on 15/12/23.
//  Copyright (c) 2015年 李庆生. All rights reserved.
//

#import "UserModel.h"

@implementation UserModel

@end
