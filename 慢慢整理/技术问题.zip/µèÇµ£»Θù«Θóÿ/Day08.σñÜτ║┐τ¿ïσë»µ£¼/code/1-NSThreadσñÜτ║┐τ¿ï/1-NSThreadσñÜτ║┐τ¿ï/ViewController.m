//
//  ViewController.m
//  1-NSThread多线程
//
//  Created by qianfeng on 15/12/24.
//  Copyright (c) 2015年 李庆生. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    NSLog(@"%s 是否是多线程 %d", __FUNCTION__, [NSThread isMultiThreaded]);
    
    //NSThread {number = 1, name = main}
    NSLog(@"当前的线程 %@", [NSThread currentThread]);
    
    //创建线程
    //第一种方法, 需要手动启动
    NSThread *thread = [[NSThread alloc] initWithTarget:self selector:@selector(run:) object:@"xxxxxx"];
    //设置线程的名字
    thread.name = @"thread<run:>";
    //启动线程
    [thread start];
    
    //第二种方法
    //[NSThread detachNewThreadSelector:@selector(run1) toTarget:self withObject:nil];
    
    
    NSLog(@"%s 是否是多线程 %d", __FUNCTION__, [NSThread isMultiThreaded]);
    NSLog(@"%s 是否在主线程 %d", __FUNCTION__, [NSThread isMainThread]);
    
    //第三种方法, 不推崇
    //[self performSelectorInBackground:@selector(loop) withObject:nil];
}

- (void)run:(NSString *)str
{
    NSLog(@"str = %@", str);
    NSLog(@"%s 所在的线程 %@", __FUNCTION__, [NSThread currentThread]);
    /*
    while (1) {
        NSLog(@"xxxxxx");
    }*/
    
    
    //sleepForTimeInterval: 使得当前的线程暂停
    [NSThread sleepForTimeInterval:5];
    
    //dateWithTimeIntervalSinceNow, 从现在开始，持续到的时间
    NSDate *date1 = [NSDate dateWithTimeIntervalSinceNow:0];
    NSLog(@"date1 = %@", date1);
    NSDate *date = [NSDate dateWithTimeIntervalSinceNow:5];
    NSLog(@"date = %@", date);
    [NSThread sleepUntilDate:date];
    
    
    [self doSomething];
}


- (void)run1
{
    NSLog(@"run1");
    NSLog(@"%s 所在线程 %@", __FUNCTION__,[NSThread currentThread]);
    
    /*
    while (1) {
        NSLog(@"vvvvvv");
    }*/
}

- (void)loop
{
    while (1) {
        NSLog(@"-------loop");
    }
}


- (void)doSomething
{
    NSLog(@"%s 所在的线程为 %@", __FUNCTION__, [NSThread currentThread]);
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end









