//
//  ViewController.m
//  3-NSThread下载图片
//
//  Created by qianfeng on 15/12/24.
//  Copyright (c) 2015年 李庆生. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (nonatomic,strong) UIImageView *imgView;
@property (nonatomic, strong) UIActivityIndicatorView *indicatorView;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.imgView = [[UIImageView alloc] init];
    self.imgView.frame  = self.view.bounds;
    [self.view addSubview:self.imgView];
    
    self.indicatorView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    self.indicatorView.center = self.imgView.center;
    [self.view addSubview:self.indicatorView];
    
    [NSThread detachNewThreadSelector:@selector(downloadImage) toTarget:self withObject:nil];
    
    [self.indicatorView startAnimating];
    
}

- (void)downloadImage
{
    NSString *urlStr = @"http://fg.p0y.cn/c/126/285822.jpg";
    NSURL *url = [NSURL URLWithString:urlStr];
    
    NSData *data = [NSData dataWithContentsOfURL:url];
    NSLog(@"data = %@", data);
    
    //对于iOS，UI的刷新， 必须放在主线程
    //self.imgView.image = [UIImage imageWithData:data];
    
    [self performSelectorOnMainThread:@selector(setImageWithData:) withObject:data waitUntilDone:NO];
    
    //[self.indicatorView stopAnimating];
    
    while (1) {
        
    }
}


- (void)setImageWithData:(NSData *)data
{
    NSLog(@"----%d", [NSThread isMainThread]);
    self.imgView.image = [UIImage imageWithData:data];
    [self.indicatorView stopAnimating];
}




- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end





