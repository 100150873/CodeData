//
//  ViewController.m
//  9-线程互斥(线程锁)
//
//  Created by qianfeng on 15/12/24.
//  Copyright (c) 2015年 李庆生. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    NSLock *myLock = [[NSLock alloc] init];
    
    //10个红包
    __block NSInteger num = 10;
    
    for (NSInteger i = 0; i < 10; i ++) {
        dispatch_async(dispatch_get_global_queue(0, 0), ^{
            
            //加锁
            //[myLock lock];
            
            @synchronized (self) {
                num --;
                NSLog(@"当前还剩%ld个红包!", num);
            }
            
            //解锁
            //[myLock unlock];
            
            
        });

        

        
    }

    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end








