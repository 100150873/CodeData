//
//  ViewController.m
//  8-GCD分组
//
//  Created by qianfeng on 15/12/24.
//  Copyright (c) 2015年 李庆生. All rights reserved.
//

#import "ViewController.h"


@interface ViewController ()

@property (nonatomic, strong) UIImage *image;
@property (nonatomic, strong) NSString *contentStr;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    //创建一个分组
    dispatch_group_t group = dispatch_group_create();
    
    //创建一个队列
    dispatch_queue_t globalQueue = dispatch_get_global_queue(0, 0);
    
    //异步执行分组里面的任务
    dispatch_group_async(group, globalQueue, ^{
        NSData *data = [NSData dataWithContentsOfURL:[NSURL URLWithString:@"http://fg.p0y.cn/c/126/285822.jpg"]];
        
        self.image = [UIImage imageWithData:data];
    });
    
   
    
    dispatch_queue_t mainQueue = dispatch_get_main_queue();
    dispatch_group_async(group, mainQueue, ^{
        
        NSString *urlStr = @"https://www.baidu.com";
        NSURL *url = [NSURL URLWithString:urlStr];
        
        self.contentStr = [[NSString alloc] initWithContentsOfURL:url encoding:NSUTF8StringEncoding error:nil];
    });
    
    //监测， 组里面的任务是否执行完毕
    //第一个参数： 组
    //第二个参数： 执行block所现在的队列
    //第三个参数： 回调函数
    dispatch_group_notify(group, dispatch_get_main_queue(), ^{
       
        NSLog(@"任务已经执行完毕!!!!");
        NSLog(@"contentStr = %@", self.contentStr);
        
        UIImageView *imgView = [[UIImageView alloc] init];
        imgView.frame = self.view.bounds;
        
        imgView.image = self.image;
        [self.view addSubview:imgView];
    });
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end






