//
//  DownloadOperation.h
//  5-自定义NSOpration
//
//  Created by qianfeng on 15/12/24.
//  Copyright (c) 2015年 李庆生. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface DownloadOperation : NSOperation

@property (nonatomic, strong) UIImage *image;

+ (instancetype)downloadImageWithUrl:(NSURL *)url;

@end
