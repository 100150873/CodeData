//
//  ViewController.m
//  5-自定义NSOpration
//
//  Created by qianfeng on 15/12/24.
//  Copyright (c) 2015年 李庆生. All rights reserved.
//

#import "ViewController.h"
#import "DownloadOperation.h"

@interface ViewController ()

@property (nonatomic, strong) DownloadOperation *downloadOperation;
@property (nonatomic, strong) DownloadOperation *downloadOperation2;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSURL *url = [NSURL URLWithString:@"http://fg.p0y.cn/c/126/285822.jpg"];
    self.downloadOperation = [DownloadOperation downloadImageWithUrl:url];
    
    self.downloadOperation2 = [DownloadOperation downloadImageWithUrl:url];
    
    
    //创建队列
    NSOperationQueue *queue = [[NSOperationQueue alloc] init];
    [queue addOperation:self.downloadOperation];
    [queue addOperation:self.downloadOperation2];
    queue.maxConcurrentOperationCount = 1;
    
    //KVO监测队列里面的任务， 是否执行完毕， 或者执行到那个任务
    //operations, operationCount
    [queue addObserver:self forKeyPath:@"operations" options:NSKeyValueObservingOptionNew | NSKeyValueObservingOptionOld context:nil];
    
}

- (void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context
{
    NSLog(@"change = %@", change);
    
    //所有的任务， 已经执行完毕
    if ([change[@"new"] count] == 0) {
        [self performSelectorOnMainThread:@selector(setImage) withObject:nil waitUntilDone:NO];
    }
}

- (void)setImage
{
    UIImageView *imgView = [[UIImageView alloc] init];
    imgView.frame = self.view.bounds;
    NSLog(@"--------");
    imgView.image = self.downloadOperation.image;
    [self.view addSubview:imgView];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end



