//
//  DownloadOperation.m
//  5-自定义NSOpration
//
//  Created by qianfeng on 15/12/24.
//  Copyright (c) 2015年 李庆生. All rights reserved.
//

#import "DownloadOperation.h"
#import <UIKit/UIKit.h>

@interface DownloadOperation ()
@property (nonatomic, strong) NSURL *url;

@end

@implementation DownloadOperation

//任务, main是任务的入口
- (void)main
{
    NSLog(@"-----main------");
    
    
    NSData *data = [NSData dataWithContentsOfURL:self.url];

    self.image = [UIImage imageWithData:data];
}


//实例化类方法
+ (instancetype)downloadImageWithUrl:(NSURL *)url
{
    DownloadOperation *operation = [[DownloadOperation alloc] init];
    
    operation.url = url;
    
    return operation;
}
@end
