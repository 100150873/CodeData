//
//  ViewController.m
//  4-NSOperation+NSOperationQueue
//
//  Created by qianfeng on 15/12/24.
//  Copyright (c) 2015年 李庆生. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    //NSOperation 是一个任务的抽象的类， 不能直接去使用
    //使用其子类
    //NSInvocationOperation
    //NSBlockOperation

    //关联一个函数, 以函数作为操作的任务
    NSInvocationOperation *invocationOperation = [[NSInvocationOperation alloc] initWithTarget:self selector:@selector(doSomething) object:nil];
    
    
    //关联一个block, 以block作为操作的任务
    NSBlockOperation *blockOperation = [NSBlockOperation blockOperationWithBlock:^{
        
        for (NSInteger i = 0; i < 5; i ++) {
            NSLog(@"blockOperation %ld, 线程: %@", i, [NSThread currentThread]);
            
            [NSThread sleepForTimeInterval:1];
        }
        
    }];
    
    
    //创建队列, 队列是用来存放任务
    NSOperationQueue *queue = [[NSOperationQueue alloc] init];
    queue.name = @"ssss";
    
    //获取系统的主队列
    NSOperationQueue *mainQueue = [NSOperationQueue mainQueue];
    NSLog(@"mainQueue = %@", mainQueue);
    
    //设置队列最大的并发数，如果是1，称为串行队列
    queue.maxConcurrentOperationCount = 1;
    
    
    //获取到当前的队列
    NSOperationQueue *currentQueue = [NSOperationQueue currentQueue];
    NSLog(@"currentQueue = %@", currentQueue);
    
    
    //将操作添加到队列里面
    [queue addOperation:invocationOperation];
    [queue addOperation:blockOperation];
    
}

- (void)doSomething
{
    NSLog(@"当前的队列 %@", [NSOperationQueue currentQueue]);
    for (NSInteger i = 0; i < 5; i ++) {
        NSLog(@"dosomething, 线程: %@", [NSThread currentThread]);
        
        [NSThread sleepForTimeInterval:1];
    }
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
