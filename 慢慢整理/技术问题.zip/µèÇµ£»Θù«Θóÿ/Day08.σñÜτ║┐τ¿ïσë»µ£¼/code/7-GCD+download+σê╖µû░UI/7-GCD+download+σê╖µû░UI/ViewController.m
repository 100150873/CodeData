//
//  ViewController.m
//  7-GCD+download+刷新UI
//
//  Created by qianfeng on 15/12/24.
//  Copyright (c) 2015年 李庆生. All rights reserved.
//

#import "ViewController.h"

#define URLSTR @"http://fg.p0y.cn/c/126/285822.jpg"


@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    dispatch_queue_t globalQueue =  dispatch_get_global_queue(0, 0);
    
    
    //下载图片: 在子线程下载，子线程会出现阻塞，但是不影响主线程
    //当下载完毕之后， 在主线程中刷新
    dispatch_async(globalQueue, ^{
       
        NSURL *url = [NSURL URLWithString:URLSTR];
        NSData *data = [NSData dataWithContentsOfURL:url];
        
        //在主队列，的线程里面完成刷新UI
        dispatch_async(dispatch_get_main_queue(), ^{
           
            UIImageView *imgView = [[UIImageView alloc] init];
            imgView.frame = self.view.bounds;
            imgView.image = [UIImage imageWithData:data];
            [self.view addSubview:imgView];
        });
    });
    
    

    
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end






