//
//  main.m
//  14-static
//
//  Created by xiaomage on 15/7/5.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

/**
 static的作用：
 1.修饰局部变量
 * 让局部变量只初始化一次
 * 局部变量在程序中只有一份内存
 * 并不会改变局部变量的作用域，仅仅是改变了局部变量的生命周期（只到程序结束，这个局部变量才会销毁）
 
 2.修饰全局变量
 * 全局变量的作用域仅限于当前文件
 */

#import <Foundation/Foundation.h>
#import "XMGCar.h"
#import "XMGPerson.h"

//void test()
//{
//    static int a = 0;
//    a++;
//    NSLog(@"a = %d", a);
//}

int main(int argc, const char * argv[]) {
    @autoreleasepool {
//        for (int i = 0; i<3; i++) {
//            test();
//        }
        
        extern int age;
        
        NSLog(@"age is %d", age);
        
        [XMGPerson test];
    }
    return 0;
}