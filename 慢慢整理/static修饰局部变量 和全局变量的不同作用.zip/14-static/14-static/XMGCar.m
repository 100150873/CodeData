//
//  XMGCar.m
//  14-static
//
//  Created by xiaomage on 15/7/5.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

#import "XMGCar.h"

@implementation XMGCar

int age = 30;

@end
