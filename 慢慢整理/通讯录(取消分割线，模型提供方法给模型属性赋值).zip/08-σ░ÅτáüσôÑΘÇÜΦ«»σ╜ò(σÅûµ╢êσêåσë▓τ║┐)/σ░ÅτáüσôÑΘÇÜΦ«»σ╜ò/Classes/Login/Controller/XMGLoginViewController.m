//
//  XMGLoginViewController.m
//  小码哥通讯录
//
//  Created by xiaomage on 15/6/12.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "XMGLoginViewController.h"

#import "MBProgressHUD+XMG.h"

@interface XMGLoginViewController ()<UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UIButton *loginBtn;

@property (weak, nonatomic) IBOutlet UITextField *accountField;
@property (weak, nonatomic) IBOutlet UITextField *pwdField;

@property (weak, nonatomic) IBOutlet UISwitch *rmbPwdSwitch;
@property (weak, nonatomic) IBOutlet UISwitch *autoLoginSwitch;
@end
/*
 来源控制器传递给目的控制器：顺传
 数据传值:
 1.接收方一定要有属性接收
 2.传递方必须要拿到接收方
 
 */
/*
 1.[self performSegueWithIdentifier]
 2.创建segue
 3.设置来源控制器segue.sourceViewController = self
 4.创建目的控制器，segue.destinationViewController = 目的控制器
 5.[self prepareForSegue]跳转之前的准备操作
 6.[segue perform]
 7.判断下segue的类型，如果是push,拿到导航控制器push
 [self.navigationController pushViewController:segue.destinationViewController animated:YES];
 */
@implementation XMGLoginViewController

// 在执行跳转之前的时候调用
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    
    UIViewController *vc = segue.destinationViewController;
    vc.title = [NSString stringWithFormat:@"%@的联系人列表", _accountField.text];
    NSLog(@"%@--%@",segue.sourceViewController,segue.destinationViewController);
}

// 点击了登录按钮的时候调用
// xmg 123
- (IBAction)login:(id)sender {
    
    // 提示用户，正在登录ing...
    [MBProgressHUD showMessage:@"正在登录ing..."];
    
    dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
        
        // 隐藏蒙版
        [MBProgressHUD hideHUD];
        
        // 验证下账号和密码是否正确
        if ([_accountField.text isEqualToString:@"xmg"] && [_pwdField.text isEqualToString:@"123"]) { // 输入正确
            
            // 直接跳转
            // 跳转到联系人界面
            [self performSegueWithIdentifier:@"login2Contact" sender:nil];
            
        }else{ // 账号或者密码错误
            
            // 提示用户账号或者密码错误
            [MBProgressHUD showError:@"账号或者密码错误"];
            
        }
        
    });
    
    
    
}

// 记住密码开关状态改变的时候调用
- (IBAction)rmbPwdChange:(id)sender {
    // 如果取消记住密码，自动登录也需要取消勾选
    
    if (_rmbPwdSwitch.on == NO) { // 取消记住密码
        // 取消自动登录
        [_autoLoginSwitch setOn:NO animated:YES];
    }
    
    
}

// 自动登录开关状态改变的时候调用
- (IBAction)autoLoginChange:(id)sender {
    
    // 如果勾选了自动登录,记住密码也要勾选
    if (_autoLoginSwitch.on == YES) {
        [_rmbPwdSwitch setOn:YES animated:YES];
        
    }
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    // 给文本框添加监听器,及时监听文本框内容的改变
    [_accountField addTarget:self action:@selector(textChange) forControlEvents:UIControlEventEditingChanged];
    [_pwdField addTarget:self action:@selector(textChange) forControlEvents:UIControlEventEditingChanged];
    
    
    // 判断下登录按钮能否点击
    [self textChange];
    
}

// 任一一个文本框的内容改变都会调用
- (void)textChange
{
    _loginBtn.enabled = _accountField.text.length && _pwdField.text.length;
    NSLog(@"%@--%@",_accountField.text,_pwdField.text);
}


@end
