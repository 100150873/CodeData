//
//  XMGAddViewController.h
//  小码哥通讯录
//
//  Created by xiaomage on 15/6/12.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import <UIKit/UIKit.h>

@class XMGAddViewController,XMGContact;
@protocol XMGAddViewControllerDelegate <NSObject>

@optional
- (void)addViewController:(XMGAddViewController *)addVc didClickAddBtnWithContact:(XMGContact *)contact;

@end

@class XMGContactViewController;

@interface XMGAddViewController : UIViewController

@property (nonatomic, weak) id<XMGAddViewControllerDelegate> delegate;



@end
