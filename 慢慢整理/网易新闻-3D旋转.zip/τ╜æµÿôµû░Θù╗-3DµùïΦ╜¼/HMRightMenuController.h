//
//  HMRightMenuController.h
//  原创网易新闻
//
//  Created by apple on 14-7-28.
//  Copyright (c) 2014年 heima. All rights reserved.
//  右边菜单控制器

#import <UIKit/UIKit.h>

@interface HMRightMenuController : UIViewController
/**
 *  右边菜单全部显示出来
 */
- (void)didShow;
@end
