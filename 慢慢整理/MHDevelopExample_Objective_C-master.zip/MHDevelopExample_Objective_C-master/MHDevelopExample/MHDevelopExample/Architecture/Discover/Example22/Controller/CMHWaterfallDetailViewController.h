//
//  CMHWaterfallDetailViewController.h
//  MHDevelopExample
//
//  Created by lx on 2018/6/11.
//  Copyright © 2018年 CoderMikeHe. All rights reserved.
//

#import "CMHViewController.h"

@interface CMHWaterfallDetailViewController : CMHViewController

@end
