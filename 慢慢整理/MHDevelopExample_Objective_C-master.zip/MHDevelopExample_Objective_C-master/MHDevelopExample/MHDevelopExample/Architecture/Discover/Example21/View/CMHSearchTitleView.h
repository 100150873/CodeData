//
//  CMHSearchTitleView.h
//  UTrading
//
//  Created by lx on 2018/4/23.
//  Copyright © 2018年 cqgk.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CMHTextField.h"

@interface CMHSearchTitleView : UIView
/// textField
@property (nonatomic , readonly , weak) CMHTextField *textField;
@end
