//
//  MHButton.h
//  MHDevelopExample
//
//  Created by CoderMikeHe on 17/2/10.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  去掉按钮高亮的button

#import <UIKit/UIKit.h>

@interface MHButton : UIButton

@end
