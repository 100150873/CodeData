//
//  MHImageView.h
//  MHDevelopExample
//
//  Created by CoderMikeHe on 17/2/8.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MHImageView : UIImageView
+ (instancetype) imageView;
@end
