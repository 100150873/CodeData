//
//  MHButton.m
//  MHDevelopExample
//
//  Created by CoderMikeHe on 17/2/10.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "MHButton.h"

@implementation MHButton

- (void)setHighlighted:(BOOL)highlighted{}

@end
