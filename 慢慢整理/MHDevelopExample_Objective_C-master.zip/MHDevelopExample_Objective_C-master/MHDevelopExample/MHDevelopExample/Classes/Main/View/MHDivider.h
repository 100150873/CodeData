//
//  MHDivider.h
//  MHDevelopExample
//
//  Created by CoderMikeHe on 17/2/8.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  分割线

#import <UIKit/UIKit.h>

@interface MHDivider : UIView
+ (instancetype)divider;
@end
