//
//  UIImage+MHFile.m
//  MHDevLibExample
//
//  Created by apple on 16/5/12.
//  Copyright © 2016年 Mike_He. All rights reserved.
//

#import "UIImage+MHFile.h"

@implementation UIImage (MHFile)

@end
