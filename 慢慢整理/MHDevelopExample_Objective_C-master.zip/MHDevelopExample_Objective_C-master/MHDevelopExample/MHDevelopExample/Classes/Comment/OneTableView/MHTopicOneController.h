//
//  MHTopicOneController.h
//  MHDevelopExample
//
//  Created by CoderMikeHe on 17/2/8.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  该控制器利用 ‘段头+Cell+段尾’（即:cell里面不嵌套tableView） 实现类似 ‘微信朋友圈话题Or优酷视频评论话题 ’的 ‘评论回复’功能 ， 这里只是抛砖引玉的作用。

#import "MHViewController.h"

@interface MHTopicOneController : MHViewController


@end
