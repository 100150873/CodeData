//
//  MHCommentReply.m
//  MHDevelopExample
//
//  Created by CoderMikeHe on 17/2/15.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "MHCommentReply.h"

@implementation MHCommentReply

- (instancetype)init
{
    self = [super init];
    if (self) {
        // 默认写死
        _mediabase_id = @"89757";
    }
    return self;
}

@end
