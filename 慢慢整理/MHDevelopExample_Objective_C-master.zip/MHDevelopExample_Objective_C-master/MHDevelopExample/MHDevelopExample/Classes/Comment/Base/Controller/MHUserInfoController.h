//
//  MHUserInfoController.h
//  MHDevelopExample
//
//  Created by CoderMikeHe on 17/2/9.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "MHViewController.h"
@class MHUser;
@interface MHUserInfoController : MHViewController

/** user */
@property (nonatomic , strong) MHUser *user;

@end
