//
//  MHYouKuCommentController.h
//  MHDevelopExample
//
//  Created by CoderMikeHe on 17/2/16.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "MHViewController.h"

@interface MHYouKuCommentController : MHViewController
/** 视频id */
@property (nonatomic , copy) NSString *mediabase_id;

@end
