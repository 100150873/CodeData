//
//  MHYouKuCommentItem.h
//  MHDevelopExample
//
//  Created by CoderMikeHe on 17/2/17.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "MHYouKuItem.h"

@interface MHYouKuCommentItem : MHYouKuItem

/** 评论数目 */
@property (nonatomic , assign) long long commentCount;


@end
