//
//  MHYouKuAnthologyItem.m
//  MHDevelopExample
//
//  Created by CoderMikeHe on 17/2/17.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "MHYouKuAnthologyItem.h"

@implementation MHYouKuAnthology
- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}
@end


@implementation MHYouKuAnthologyItem
- (instancetype)init
{
    self = [super init];
    if (self) {
        _anthologys = [NSMutableArray array];
    }
    return self;
}
@end
