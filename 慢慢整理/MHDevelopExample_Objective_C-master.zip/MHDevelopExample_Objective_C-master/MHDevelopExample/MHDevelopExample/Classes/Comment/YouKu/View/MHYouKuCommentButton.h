//
//  MHYouKuCommentButton.h
//  MHDevelopExample
//
//  Created by CoderMikeHe on 17/2/15.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  评论框

#import "MHButton.h"

@interface MHYouKuCommentButton : MHButton
+ (instancetype)commentButton;
@end
