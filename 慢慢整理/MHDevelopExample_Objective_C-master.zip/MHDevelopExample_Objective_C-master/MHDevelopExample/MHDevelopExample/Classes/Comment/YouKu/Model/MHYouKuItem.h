//
//  MHYouKuItem.h
//  MHDevelopExample
//
//  Created by CoderMikeHe on 17/2/17.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface MHYouKuItem : NSObject
/** title */
@property (nonatomic , copy) NSString * title;
@end
