//
//  MHYouKuTopicDetailController.h
//  MHDevelopExample
//
//  Created by CoderMikeHe on 17/2/16.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "MHViewController.h"
@class MHTopicFrame;
@interface MHYouKuTopicDetailController : MHViewController

/** 话题模型尺寸 */
@property (nonatomic , strong) MHTopicFrame *topicFrame;

@end
