//
//  SUGoodsController0.h
//  MHDevelopExample
//
//  Created by senba on 2017/6/12.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  MVC 的商品首页 - C  （PS:点击搜索框退出界面）

#import "SUTableViewController0.h"

@interface SUGoodsController0 : SUTableViewController0

@end
