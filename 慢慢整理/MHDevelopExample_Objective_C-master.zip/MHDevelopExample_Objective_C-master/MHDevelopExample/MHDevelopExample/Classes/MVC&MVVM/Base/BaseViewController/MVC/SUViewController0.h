//
//  SUViewController0.h
//  MHDevelopExample
//
//  Created by senba on 2017/6/12.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  使用MVC设计模式的所有自定义的控制器的父类 -- C

#import "SUBaseViewController.h"

@interface SUViewController0 : SUBaseViewController

@end
