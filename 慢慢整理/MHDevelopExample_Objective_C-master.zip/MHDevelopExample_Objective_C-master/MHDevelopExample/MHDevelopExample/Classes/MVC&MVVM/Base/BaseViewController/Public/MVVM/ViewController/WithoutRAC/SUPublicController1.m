//
//  SUPublicController1.m
//  MHDevelopExample
//
//  Created by senba on 2017/6/16.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  MVVM Without RAC 开发模式的事件处理的 公共控制器 -- C

#import "SUPublicController1.h"

@interface SUPublicController1 ()

@end

@implementation SUPublicController1

- (void)viewDidLoad {
    [super viewDidLoad];
}
@end
