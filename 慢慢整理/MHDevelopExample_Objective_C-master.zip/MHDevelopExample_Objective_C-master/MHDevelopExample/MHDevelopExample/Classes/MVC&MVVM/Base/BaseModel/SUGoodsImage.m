
//
//  SUGoodsImage.m
//  MHDevelopExample
//
//  Created by senba on 2017/6/9.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "SUGoodsImage.h"

@implementation SUGoodsImage

+ (NSDictionary<NSString *,id> *)modelCustomPropertyMapper {
    return @{ @"imageId" : @"id" };
}

@end
