//
//  SUGoodsHeaderView.h
//  MHDevelopExample
//
//  Created by senba on 2017/6/10.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  推荐商品 -- V

#import <UIKit/UIKit.h>

@interface SUGoodsHeaderView : UITableViewHeaderFooterView

@end
