//
//  SUPublicWebController0.h
//  MHDevelopExample
//
//  Created by senba on 2017/6/14.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  MVC WebView的统一加载控制器 -- C

#import "SUWebViewController0.h"

@interface SUPublicWebController0 : SUWebViewController0

@end
