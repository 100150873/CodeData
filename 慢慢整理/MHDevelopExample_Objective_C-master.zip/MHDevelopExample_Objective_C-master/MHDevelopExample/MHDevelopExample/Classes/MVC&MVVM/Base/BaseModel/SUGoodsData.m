//
//  SUGoodsData.m
//  MHDevelopExample
//
//  Created by senba on 2017/6/13.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "SUGoodsData.h"

@implementation SUGoodsData
+ (NSDictionary<NSString *,id> *)modelContainerPropertyGenericClass
{
    return @{@"data":[SUGoods class]};
}
@end
