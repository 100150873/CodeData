//
//  SULoginInputView.m
//  MHDevelopExample
//
//  Created by senba on 2017/6/11.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "SULoginInputView.h"

@implementation SULoginInputView

+ (instancetype)inputView
{
    return [self mh_viewFromXib];
}

@end
