//
//  SUPublicController0.m
//  MHDevelopExample
//
//  Created by senba on 2017/6/13.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  MVC 开发模式的事件处理的 公共控制器 -- C

#import "SUPublicController0.h"

@interface SUPublicController0 ()

@end

@implementation SUPublicController0

- (void)viewDidLoad {
    [super viewDidLoad];
}

@end
