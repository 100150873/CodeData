//
//  SUPublicWebController0.m
//  MHDevelopExample
//
//  Created by senba on 2017/6/14.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "SUPublicWebController0.h"

@interface SUPublicWebController0 ()

@end

@implementation SUPublicWebController0

- (void)viewDidLoad {
    [super viewDidLoad];
}

@end
