//
//  SUGoodsImageCell.h
//  MHDevelopExample
//
//  Created by senba on 2017/6/10.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  商品图片cell

#import <UIKit/UIKit.h>

@interface SUGoodsImageCell : UICollectionViewCell
/// imageView
@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@end
