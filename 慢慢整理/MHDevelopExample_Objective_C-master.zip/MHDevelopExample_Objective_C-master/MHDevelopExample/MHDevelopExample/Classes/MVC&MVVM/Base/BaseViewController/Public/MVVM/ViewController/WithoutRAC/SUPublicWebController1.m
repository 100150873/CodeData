//
//  SUPublicWebController1.m
//  MHDevelopExample
//
//  Created by senba on 2017/6/17.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  MVVM Without RAC的 跳转到WebView的统一加载控制器 -- C

#import "SUPublicWebController1.h"

@interface SUPublicWebController1 ()

@end

@implementation SUPublicWebController1

- (void)viewDidLoad {
    [super viewDidLoad];
}

@end
