//
//  SUBaseViewController.h
//  MHDevelopExample
//
//  Created by senba on 2017/6/12.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  最基础的UIViewController -- C

#import <UIKit/UIKit.h>

@interface SUBaseViewController : UIViewController

@end
