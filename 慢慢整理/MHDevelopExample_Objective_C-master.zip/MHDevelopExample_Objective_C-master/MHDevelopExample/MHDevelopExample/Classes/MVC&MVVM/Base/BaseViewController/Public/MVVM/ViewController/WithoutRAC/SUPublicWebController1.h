//
//  SUPublicWebController1.h
//  MHDevelopExample
//
//  Created by senba on 2017/6/17.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  MVVM Without RAC的 跳转到WebView的统一加载控制器 -- C

#import "SUWebViewController1.h"
#import "SUPublicWebViewModel1.h"
@interface SUPublicWebController1 : SUWebViewController1

@end
