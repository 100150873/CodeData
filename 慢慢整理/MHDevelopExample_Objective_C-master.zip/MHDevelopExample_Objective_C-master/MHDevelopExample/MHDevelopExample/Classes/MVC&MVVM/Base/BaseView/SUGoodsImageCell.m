//
//  SUGoodsImageCell.m
//  MHDevelopExample
//
//  Created by senba on 2017/6/10.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "SUGoodsImageCell.h"

@implementation SUGoodsImageCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
