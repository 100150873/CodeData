//
//  SUPublicViewModel2.m
//  MHDevelopExample
//
//  Created by senba on 2017/6/19.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "SUPublicViewModel2.h"

@implementation SUPublicViewModel2

@end
