//
//  SUPublicViewModel2.h
//  MHDevelopExample
//
//  Created by senba on 2017/6/19.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "SUViewModel2.h"

@interface SUPublicViewModel2 : SUViewModel2

@end
