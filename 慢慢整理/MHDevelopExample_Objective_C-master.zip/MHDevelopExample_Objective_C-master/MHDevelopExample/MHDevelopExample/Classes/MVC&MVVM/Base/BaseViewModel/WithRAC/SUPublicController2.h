//
//  SUPublicController2.h
//  MHDevelopExample
//
//  Created by senba on 2017/6/19.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  MVVM With RAC 开发模式的事件处理的 公共控制器 -- C

#import "SUViewController2.h"
#import "SUPublicViewModel2.h"
@interface SUPublicController2 : SUViewController2

@end
