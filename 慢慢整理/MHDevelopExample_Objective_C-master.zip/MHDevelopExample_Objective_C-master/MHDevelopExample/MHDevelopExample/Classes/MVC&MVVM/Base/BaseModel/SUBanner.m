//
//  SUBanner.m
//  MHDevelopExample
//
//  Created by senba on 2017/6/13.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "SUBanner.h"

@implementation SUBanner
+ (NSDictionary<NSString *,id> *)modelCustomPropertyMapper {
    return @{ @"primaryKey" : @"id" };
}
@end
