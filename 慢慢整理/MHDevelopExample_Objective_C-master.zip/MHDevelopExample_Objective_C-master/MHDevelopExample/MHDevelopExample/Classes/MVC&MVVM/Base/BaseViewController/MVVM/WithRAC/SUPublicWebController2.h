//
//  SUPublicWebController2.h
//  MHDevelopExample
//
//  Created by senba on 2017/6/19.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  MVVM With RAC的 跳转到WebView的统一加载控制器 -- C

#import "SUWebViewController2.h"
#import "SUPublicWebViewModel2.h"
@interface SUPublicWebController2 : SUWebViewController2

@end
