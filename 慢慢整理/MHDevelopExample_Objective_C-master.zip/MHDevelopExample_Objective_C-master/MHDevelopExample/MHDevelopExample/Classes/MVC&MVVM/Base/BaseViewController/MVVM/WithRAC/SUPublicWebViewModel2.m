//
//  SUPublicWebViewModel2.m
//  MHDevelopExample
//
//  Created by senba on 2017/6/19.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "SUPublicWebViewModel2.h"

@implementation SUPublicWebViewModel2

@end
