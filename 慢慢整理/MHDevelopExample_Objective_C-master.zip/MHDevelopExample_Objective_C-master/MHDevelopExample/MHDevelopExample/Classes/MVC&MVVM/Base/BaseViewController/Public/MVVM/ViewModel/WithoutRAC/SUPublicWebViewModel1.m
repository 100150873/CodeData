//
//  SUPublicWebViewModel1.m
//  MHDevelopExample
//
//  Created by senba on 2017/6/17.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  MVVM Without RAC 开发模式的事件处理Web的 公共视图模型 -- VM

#import "SUPublicWebViewModel1.h"

@implementation SUPublicWebViewModel1

@end
