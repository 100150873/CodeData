//
//  SUPublicWebViewModel2.h
//  MHDevelopExample
//
//  Created by senba on 2017/6/19.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "SUWebViewModel2.h"

@interface SUPublicWebViewModel2 : SUWebViewModel2

@end
