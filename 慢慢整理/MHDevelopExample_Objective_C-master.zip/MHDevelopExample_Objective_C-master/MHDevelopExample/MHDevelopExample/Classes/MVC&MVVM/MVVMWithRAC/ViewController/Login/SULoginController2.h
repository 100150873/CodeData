//
//  SULoginController2.h
//  MHDevelopExample
//
//  Created by senba on 2017/6/15.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  MVVM With RAC 开发模式的登录控制器 -- C

#import "SUViewController2.h"
#import "SULoginViewModel2.h"
@interface SULoginController2 : SUViewController2

@end
