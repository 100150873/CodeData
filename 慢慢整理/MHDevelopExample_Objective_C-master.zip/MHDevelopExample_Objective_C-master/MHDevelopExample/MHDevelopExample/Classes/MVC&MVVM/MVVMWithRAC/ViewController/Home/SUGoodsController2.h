//
//  SUGoodsController2.h
//  MHDevelopExample
//
//  Created by senba on 2017/6/19.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "SUTableViewController2.h"
#import "SUGoodsViewModel2.h"
@interface SUGoodsController2 : SUTableViewController2

@end
