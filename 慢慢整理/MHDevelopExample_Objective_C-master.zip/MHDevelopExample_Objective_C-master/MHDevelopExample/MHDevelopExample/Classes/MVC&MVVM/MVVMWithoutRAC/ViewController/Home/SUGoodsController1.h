//
//  SUGoodsController1.h
//  MHDevelopExample
//
//  Created by senba on 2017/6/16.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  MVVM Without RAC 开发模式的商品首页控制器 -- C

#import "SUTableViewController1.h"
#import "SUGoodsViewModel1.h"
@interface SUGoodsController1 : SUTableViewController1

@end
