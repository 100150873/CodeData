//
//  MHDeleteController.h
//  MHDevelopExample
//
//  Created by CoderMikeHe on 17/2/10.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "MHViewController.h"

@interface MHDeleteController : MHViewController

@end
