//
//  MHDisplayController.h
//  MHDevelopExample
//
//  Created by CoderMikeHe on 17/2/7.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//  Tips:该控制器利用 YZDisplayViewController [https://github.com/iThinkerYZ/YZDisplayViewController] 实现类似网易新闻+腾讯视频+喜马拉雅+今日头条的基本框架，这里只是起到一个 抛砖引玉 的作用。但是都是利用父子控制器来实现，详细使用请参照 YZDisplayViewController 的使用Demo以及该作者的博文: http://www.jianshu.com/p/b45655e23a42
//

#import <YZDisplayViewController/YZDisplayViewController.h>

@interface MHDisplayController : YZDisplayViewController

@end
