//
//  MHNetEaseNewsController.h
//  MHDevelopExample
//
//  Created by CoderMikeHe on 17/2/7.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import "MHViewController.h"

@interface MHNetEaseNewsController : MHViewController

@end
