//
//  MHTopicLabel.h
//  MHDevelopExample
//
//  Created by CoderMikeHe on 17/2/7.
//  Copyright © 2017年 CoderMikeHe. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MHTopicLabel : UILabel

/** label的比例值 */
@property (nonatomic, assign) CGFloat scale;

@end
