//
//  PaoPaoViewController.m
//  3.泡泡控制器
//
//  Created by liuyuecheng on 15/12/29.
//  Copyright (c) 2015年 liuyuecheng. All rights reserved.
//

#import "PaoPaoViewController.h"

@interface PaoPaoViewController ()<UITableViewDataSource,UITableViewDelegate>

@end

@implementation PaoPaoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    
    
    UITableView *table = [[UITableView alloc]initWithFrame:self.view.bounds];
    table.dataSource = self;
    table.delegate =self;
    [self.view addSubview:table];
    
}


#pragma mark -UITableViewDataSource&UITableViewDelegate

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return 4;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell"];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    }
    cell.textLabel.text = [NSString stringWithFormat:@"%ld",indexPath.row];
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    //执行回调,进行传值
    
#if 0
    //如果接受到了block,才可以回调
    if (self.blcok)
    {
        self.blcok([NSString stringWithFormat:@"%ld",indexPath.row]);
    }
#endif
    
#if 0
    //发送通知,触发回调
    [[NSNotificationCenter defaultCenter]postNotificationName:@"change" object:[NSString stringWithFormat:@"%ld",indexPath.row]];
#endif
    
 
    //通过代理来回调
    if ( [self.delegate respondsToSelector:@selector(postValue:)])
    {
        [self.delegate postValue:[NSString stringWithFormat:@"%ld",indexPath.row]];
    }
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
