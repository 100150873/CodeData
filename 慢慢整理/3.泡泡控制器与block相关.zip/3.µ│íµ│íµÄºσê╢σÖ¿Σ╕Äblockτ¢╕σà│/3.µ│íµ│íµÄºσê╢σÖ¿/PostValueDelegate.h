//
//  PostValueDelegate.h
//  3.泡泡控制器
//
//  Created by liuyuecheng on 15/12/29.
//  Copyright (c) 2015年 liuyuecheng. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol PostValueDelegate <NSObject>

//协议里面是一堆减方法的集合
- (void)postValue:(NSString *)string;

@end
