//
//  ViewController.m
//  3.泡泡控制器
//
//  Created by liuyuecheng on 15/12/29.
//  Copyright (c) 2015年 liuyuecheng. All rights reserved.
//

#import "ViewController.h"
#import "PaoPaoViewController.h"
#import "PostValueDelegate.h"
@interface ViewController ()<UITextFieldDelegate,UIPopoverControllerDelegate,PostValueDelegate>
{
    //泡泡控制器,它里面装得是视图控制器
    UIPopoverController *_popo;
    UITextField *_field;
}
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    
    //实例化泡泡内容
    PaoPaoViewController *paopao = [[PaoPaoViewController alloc]init];
    
    //设置代理
    paopao.delegate = self;
    
    //传递block,block参数不能省略
    [paopao setBlcok:^(NSString *string) {
        
        //block内容,调用才会执行.
        _field.text = string;
        
        //泡泡消失,键盘收起
        [_popo dismissPopoverAnimated:YES];
        
        [self.view endEditing:YES];
        
    }];
    
    
    //实例化泡泡控制器
    _popo = [[UIPopoverController alloc]initWithContentViewController:paopao];
    
    //设置泡泡的尺寸
    _popo.popoverContentSize = CGSizeMake(200, 300);
    
    //设置泡泡控制器的代理,获取弹出,消失事件
    _popo.delegate = self;
    
    //创建一个导航栏按钮
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"弹出泡泡" style:UIBarButtonItemStylePlain target:self action:@selector(showPaoPao)];
    
    _field = [[UITextField alloc]initWithFrame:CGRectMake(0, 0, 300, 50)];
    _field.borderStyle = UITextBorderStyleRoundedRect;
    _field.center = CGPointMake(self.view.frame.size.width/2, 150);
    _field.delegate  = self;
    [self.view addSubview:_field];
    
    
    //添加观察者
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(change:) name:@"change" object:nil];
}

- (void)change:(NSNotification *)noti
{
    _field.text = noti.object;
    
    [_popo dismissPopoverAnimated:YES];
    
    [self.view endEditing:YES];
}

- (void)dealloc
{
    //通知中心随视图控制器销毁而销毁
    [[NSNotificationCenter defaultCenter]removeObserver:self];
}

- (void)showPaoPao
{
    //第一种,泡泡从导航栏按钮弹出
    //presentPopoverFromBarButtonItem  从哪个按钮弹出
    //permittedArrowDirections         泡泡箭头方向
    //animated                         弹出泡泡是否带动画
    [_popo presentPopoverFromBarButtonItem:self.navigationItem.rightBarButtonItem permittedArrowDirections:UIPopoverArrowDirectionAny animated:YES];
}

#pragma mark -UITextFieldDelegate
//输入框开始编辑
- (void)textFieldDidBeginEditing:(UITextField *)textField
{
    //第二种,从任意位置弹出泡泡
    
    //presentPopoverFromRect    弹出泡泡的位置
    //inView                    在哪个视图中弹出
    //permittedArrowDirections  箭头方向
    //animated                  是否需要动画
    
    [_popo presentPopoverFromRect:CGRectMake(280,-100, 200, 300) inView:self.view permittedArrowDirections:UIPopoverArrowDirectionUp animated:YES];
}

#pragma mark -UIPopoverControllerDelegate
//泡泡已经消失
- (void)popoverControllerDidDismissPopover:(UIPopoverController *)popoverController
{
    //泡泡消失的同时,键盘也消失
    [self.view endEditing:YES];
}


#pragma mark -PostValueDelegate
//实现回调方法
- (void)postValue:(NSString *)string
{
    _field.text = string;
    
    [_popo dismissPopoverAnimated:YES];
    
    [self.view endEditing:YES];
}

@end
