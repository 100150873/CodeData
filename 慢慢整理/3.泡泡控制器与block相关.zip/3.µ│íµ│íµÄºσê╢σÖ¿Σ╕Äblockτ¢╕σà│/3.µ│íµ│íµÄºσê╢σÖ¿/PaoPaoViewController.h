//
//  PaoPaoViewController.h
//  3.泡泡控制器
//
//  Created by liuyuecheng on 15/12/29.
//  Copyright (c) 2015年 liuyuecheng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PostValueDelegate.h"

@interface PaoPaoViewController : UIViewController

//block用copy修饰.block创建在栈上,后面需要将它转移堆上,需要copy
@property (nonatomic,copy) void (^blcok)(NSString *);

//使用assign避免互相引用无法释放
@property (nonatomic,assign)id<PostValueDelegate>delegate;

@end


/*
 回调,反向传值是其中一个功能.
 
 一.使用Block来做回调
    1.需要反向传值的页面(B)（就是B页面向A页面传值）,写声明属性Block
    2.在A页面往B页面传block
    3.B页面,需要传值时,调用该block
 
 二.通知中心做回调
    1.添加一个观察者,设置好观察的字符串,回调方法
    2.在任意地方发送通知,触发回调
    3.通知中心使用完毕,销毁.
 
    通知中心是一对多.会提高程序的耦合度.慎用
    程序的耦合度:类与类之间的关联
 
 三.代理做回调
    1.确定谁是代理,谁是被代理.谁要传值,谁就是被代理.
    2.定制一个协议,协议里面有回调方法.
    3.被代理做的事情:1)拥有遵守协议的delegate成员.  2)通过delegate执行回调
 
    4.代理做的事情:1)遵守协议    2)设置代理   3)实现协议中的回调方法
 
 
 
 */