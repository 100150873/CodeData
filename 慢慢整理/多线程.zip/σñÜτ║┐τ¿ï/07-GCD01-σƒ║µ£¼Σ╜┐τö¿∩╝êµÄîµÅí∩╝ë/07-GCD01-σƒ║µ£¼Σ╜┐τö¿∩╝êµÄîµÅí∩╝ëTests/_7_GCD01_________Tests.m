//
//  _7_GCD01_________Tests.m
//  07-GCD01-基本使用（掌握）Tests
//
//  Created by apple on 14-9-15.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface _7_GCD01_________Tests : XCTestCase

@end

@implementation _7_GCD01_________Tests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
