//
//  HMGoodStudent.m
//  03-单例模式-Singleton（掌握）
//
//  Created by apple on 14-9-16.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import "HMGoodStudent.h"

@implementation HMGoodStudent
+ (void)load
{
    NSLog(@"load---HMGoodStudent");
}
//+ (void)initialize
//{
//    NSLog(@"initialize---HMGoodStudent");
//}
@end
