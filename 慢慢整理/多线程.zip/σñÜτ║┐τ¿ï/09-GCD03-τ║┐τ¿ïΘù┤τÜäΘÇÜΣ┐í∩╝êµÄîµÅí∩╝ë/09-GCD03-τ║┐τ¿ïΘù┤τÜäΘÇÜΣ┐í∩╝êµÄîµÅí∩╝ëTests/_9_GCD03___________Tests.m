//
//  _9_GCD03___________Tests.m
//  09-GCD03-线程间的通信（掌握）Tests
//
//  Created by apple on 14-9-15.
//  Copyright (c) 2014年 heima. All rights reserved.
//

#import <XCTest/XCTest.h>

@interface _9_GCD03___________Tests : XCTestCase

@end

@implementation _9_GCD03___________Tests

- (void)setUp
{
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown
{
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testExample
{
    XCTFail(@"No implementation for \"%s\"", __PRETTY_FUNCTION__);
}

@end
