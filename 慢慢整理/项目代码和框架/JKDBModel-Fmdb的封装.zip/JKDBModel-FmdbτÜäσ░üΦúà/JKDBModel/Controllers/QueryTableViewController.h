//
//  QueryTableViewController.h
//  JKDBModel
//
//  Created by zx_04 on 15/7/3.
//  Copyright (c) 2015年 joker. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QueryTableViewController : UITableViewController

@property (nonatomic, assign)   int                        type;

@end
