//
//  Depart.m
//  JKBaseModel
//
//  Created by zx_04 on 15/6/30.
//  Copyright (c) 2015年 joker. All rights reserved.
//

#import "Depart.h"

@implementation Depart

@end
