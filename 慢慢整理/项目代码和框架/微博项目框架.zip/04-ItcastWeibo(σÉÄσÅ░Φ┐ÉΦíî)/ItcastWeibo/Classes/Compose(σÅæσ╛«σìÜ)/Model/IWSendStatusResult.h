//
//  IWSendStatusResult.h
//  ItcastWeibo
//
//  Created by apple on 14-5-20.
//  Copyright (c) 2014年 itcast. All rights reserved.
//  封装发微博的返回结果

#import <Foundation/Foundation.h>
#import "IWStatus.h"

@interface IWSendStatusResult : IWStatus

@end
