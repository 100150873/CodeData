//
//  IWStatusTopView.h
//  ItcastWeibo
//
//  Created by apple on 14-5-11.
//  Copyright (c) 2014年 itcast. All rights reserved.
//  微博cell顶部的view

#import <UIKit/UIKit.h>
@class IWStatusFrame;
@interface IWStatusTopView : UIImageView
@property (nonatomic, strong) IWStatusFrame *statusFrame;
@end
