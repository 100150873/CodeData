//
//  IWStatusToolbar.h
//  ItcastWeibo
//
//  Created by apple on 14-5-11.
//  Copyright (c) 2014年 itcast. All rights reserved.
//  微博cell底部的工具条

#import <UIKit/UIKit.h>
@class IWStatus;
@interface IWStatusToolbar : UIImageView
@property (nonatomic, strong) IWStatus *status;
@end
