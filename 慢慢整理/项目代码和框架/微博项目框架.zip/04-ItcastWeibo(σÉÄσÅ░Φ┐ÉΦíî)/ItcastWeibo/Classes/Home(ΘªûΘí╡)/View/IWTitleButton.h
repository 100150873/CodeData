//
//  IWTitleButton.h
//  ItcastWeibo
//
//  Created by apple on 14-5-6.
//  Copyright (c) 2014年 itcast. All rights reserved.
//  导航栏上面的标题按钮

#import <UIKit/UIKit.h>

@interface IWTitleButton : UIButton
+ (instancetype)titleButton;
@end
