//
//  IWPhotoView.h
//  ItcastWeibo
//
//  Created by apple on 14-5-11.
//  Copyright (c) 2014年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>
@class IWPhoto;
@interface IWPhotoView : UIImageView
@property (nonatomic, strong) IWPhoto *photo;
@end
