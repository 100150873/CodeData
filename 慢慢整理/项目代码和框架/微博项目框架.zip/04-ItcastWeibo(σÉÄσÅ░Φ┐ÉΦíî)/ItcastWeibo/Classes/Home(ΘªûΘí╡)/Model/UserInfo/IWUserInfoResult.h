//
//  IWUserInfoResult.h
//  ItcastWeibo
//
//  Created by apple on 14-5-20.
//  Copyright (c) 2014年 itcast. All rights reserved.
//  封装加载用户信息的返回结果

#import <Foundation/Foundation.h>
#import "IWUser.h"

@interface IWUserInfoResult : IWUser

@end
