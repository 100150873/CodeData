//
//  IWUserInfoResult.m
//  ItcastWeibo
//
//  Created by apple on 14-5-20.
//  Copyright (c) 2014年 itcast. All rights reserved.
//

#import "IWUserInfoResult.h"

@implementation IWUserInfoResult

@end
