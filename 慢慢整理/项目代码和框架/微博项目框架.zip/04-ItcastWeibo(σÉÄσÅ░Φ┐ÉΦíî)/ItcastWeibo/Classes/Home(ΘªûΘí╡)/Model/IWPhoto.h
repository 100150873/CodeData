//
//  IWPhoto.h
//  ItcastWeibo
//
//  Created by apple on 14-5-11.
//  Copyright (c) 2014年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface IWPhoto : NSObject
/**
 *  缩略图
 */
@property (nonatomic, copy) NSString *thumbnail_pic;
@end
