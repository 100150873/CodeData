//
//  IWHomeViewController.h
//  ItcastWeibo
//
//  Created by apple on 14-5-5.
//  Copyright (c) 2014年 itcast. All rights reserved.
//  首页

#import <UIKit/UIKit.h>

@interface IWHomeViewController : UITableViewController
- (void)refresh;
@end
