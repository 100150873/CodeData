//
//  IWBadgeButton.h
//  ItcastWeibo
//
//  Created by apple on 14-5-5.
//  Copyright (c) 2014年 itcast. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface IWBadgeButton : UIButton
@property (nonatomic, copy) NSString *badgeValue;
@end
