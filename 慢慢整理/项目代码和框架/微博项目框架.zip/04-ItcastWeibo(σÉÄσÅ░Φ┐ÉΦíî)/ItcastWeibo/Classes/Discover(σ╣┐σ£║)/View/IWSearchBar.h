//
//  IWSearchBar.h
//  ItcastWeibo
//
//  Created by apple on 14-5-6.
//  Copyright (c) 2014年 itcast. All rights reserved.
//  自定义搜索框

#import <UIKit/UIKit.h>

@interface IWSearchBar : UITextField
+ (instancetype)searchBar;
@end
