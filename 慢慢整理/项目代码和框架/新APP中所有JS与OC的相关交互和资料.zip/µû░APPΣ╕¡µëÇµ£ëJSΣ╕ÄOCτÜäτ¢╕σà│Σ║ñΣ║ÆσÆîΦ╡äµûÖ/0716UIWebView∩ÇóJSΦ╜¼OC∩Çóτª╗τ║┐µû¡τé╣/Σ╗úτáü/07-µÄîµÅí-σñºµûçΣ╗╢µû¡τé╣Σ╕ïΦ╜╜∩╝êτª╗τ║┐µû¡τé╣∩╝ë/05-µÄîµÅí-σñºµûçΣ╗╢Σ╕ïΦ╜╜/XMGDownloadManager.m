//
//  XMGDownloadManager.m
//  05-掌握-大文件下载
//
//  Created by xiaomage on 15/7/16.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

#import "XMGDownloadManager.h"

@implementation XMGDownloadManager

@end
