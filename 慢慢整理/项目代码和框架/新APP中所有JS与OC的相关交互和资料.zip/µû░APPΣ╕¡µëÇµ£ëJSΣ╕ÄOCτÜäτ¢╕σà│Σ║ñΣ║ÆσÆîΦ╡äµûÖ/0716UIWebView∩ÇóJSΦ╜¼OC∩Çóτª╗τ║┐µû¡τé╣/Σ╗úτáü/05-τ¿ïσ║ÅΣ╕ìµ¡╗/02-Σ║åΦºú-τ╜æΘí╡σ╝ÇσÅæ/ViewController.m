//
//  ViewController.m
//  02-了解-网页开发
//
//  Created by xiaomage on 15/7/16.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

#import "ViewController.h"
#import "NSObject+Extension.h"

@interface ViewController () <UIWebViewDelegate>

@end

@implementation ViewController
- (IBAction)beng {
    @[][0];
}
@end
