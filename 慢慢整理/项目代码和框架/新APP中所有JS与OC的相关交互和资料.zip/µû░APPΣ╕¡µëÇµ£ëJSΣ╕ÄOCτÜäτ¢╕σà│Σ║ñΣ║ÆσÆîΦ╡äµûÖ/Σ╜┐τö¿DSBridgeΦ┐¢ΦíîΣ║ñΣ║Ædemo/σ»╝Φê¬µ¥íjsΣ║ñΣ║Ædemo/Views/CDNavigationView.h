//
//  CDNavigationView.h
//  MangocityTravel
//
//  Created by Cindy on 16/8/11.
//  Copyright © 2016年 Mangocity. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CDNavigationView : UIView

@property (nonatomic,retain) NSString *title;
@property (nonatomic,strong) UIColor *titleColor;//标题颜色
@property (nonatomic,strong) UIView *titleView;
@property (nonatomic,strong) UIButton *rightItemBar;  //  右侧按钮
@property (nonatomic,readonly) UIButton *backItemBar;  //  左侧返回按钮


@end
