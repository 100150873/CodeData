//
//  CDNavigationView.m
//  MangocityTravel
//
//  Created by Cindy on 16/8/11.
//  Copyright © 2016年 Mangocity. All rights reserved.
//

#import "CDNavigationView.h"

#define NavigationTitleFont  [UIFont boldSystemFontOfSize:18.0]
CGFloat const NavigationItemBarWidth = 50.0;

@interface CDNavigationView()
{
    UILabel *_labelTitle;
}
@property (nonatomic,readonly) UIView *contentView;  //  导航内容显示的容器（顶部偏移20个像素）
@end

@implementation CDNavigationView
@synthesize backItemBar = _backItemBar;
#pragma mark - init
- (instancetype)init
{
    self = [super init];
    if (self) {
        [self setup];
    }
    return self;
}

- (void)setup
{
    //  背景 和 边框
    self.backgroundColor = [UIColor whiteColor];
    self.layer.shadowColor = LINE_BG.CGColor;
    self.layer.shadowOffset = CGSizeMake(0.0,1.0);
    self.layer.shadowOpacity = 0.8;
    self.layer.shadowRadius = 1.0;

    //  初始化导航内容的容器
    _contentView = [[UIView alloc] init];
    _contentView.backgroundColor = [UIColor clearColor];
    [self addSubview:_contentView];
    [_contentView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(self).offset(20.0);  // 顶部偏移20个像素
        make.left.equalTo(self);
        make.right.equalTo(self);
        make.bottom.equalTo(self);
    }];
}

#pragma mark -  Setter
- (void)setTitle:(NSString *)title
{
    if (_labelTitle == nil) {
        _labelTitle = [[UILabel alloc] init];
        _labelTitle.textAlignment = NSTextAlignmentCenter;
        _labelTitle.textColor = [UIColor darkGrayColor];
        _labelTitle.font = NavigationTitleFont;
        [_contentView addSubview:_labelTitle];
        [_labelTitle mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(_contentView);
            make.bottom.equalTo(_contentView);
            make.centerX.equalTo(_contentView);
        }];
    }
    _labelTitle.text = title;
    
    _titleView.hidden = YES;  //  titleView和titleLabel只能存在一个
}


- (void)setTitleColor:(UIColor *)titleColor
{
    _labelTitle.textColor = titleColor;
}

- (void)setTitleView:(UIView *)titleView
{
    if (_titleView != titleView) {
        [_titleView removeFromSuperview];
    }
    _titleView = titleView;
    [_contentView addSubview:_titleView];
    [_titleView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_contentView);
        make.bottom.equalTo(_contentView);
        make.left.equalTo(_contentView).offset(NavigationItemBarWidth);
        make.right.equalTo(_contentView).offset(-NavigationItemBarWidth);
    }];
    
    _labelTitle.hidden = YES;  //  titleView和titleLabel只能存在一个
}

- (void)setRightItemBar:(UIButton *)rightItemBar
{
    if (_rightItemBar != rightItemBar) {
        [_rightItemBar removeFromSuperview];
    }
    _rightItemBar = rightItemBar;
    CGFloat  fitWidth = [rightItemBar.titleLabel textRectForBounds:CGRectMake(0, 0, SCREEN_WIDTH, 100.0) limitedToNumberOfLines:0].size.width + 15.0;
    [_contentView addSubview:_rightItemBar];
    [_rightItemBar mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.equalTo(_contentView);
        make.bottom.equalTo(_contentView);
        make.right.equalTo(_contentView);
        make.width.equalTo(@(NavigationItemBarWidth > fitWidth ? NavigationItemBarWidth : fitWidth));
    }];
    
    // 如果有titleView，需要一并更新约束
    if (self.titleView) {
        [self.titleView mas_updateConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self.titleView.superview).offset(-(NavigationItemBarWidth > fitWidth ? NavigationItemBarWidth : fitWidth));
        }];
    }
}

#pragma mark Getter
- (NSString *)title
{
    return _labelTitle.text;
}

- (UIButton *)backItemBar
{
    if (_backItemBar == nil) {
        _backItemBar = [[UIButton alloc] init];
        [_backItemBar setImage:[UIImage imageNamed:@"navigation_icon_back_item"] forState:UIControlStateNormal];
        _backItemBar.contentMode = UIViewContentModeScaleAspectFit;
        [_contentView addSubview:_backItemBar];
        [_backItemBar mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(_contentView);
            make.left.equalTo(_contentView);
            make.bottom.equalTo(_contentView);
            make.width.equalTo(@(NavigationItemBarWidth));
        }];
    }
    return _backItemBar;
}


@end
