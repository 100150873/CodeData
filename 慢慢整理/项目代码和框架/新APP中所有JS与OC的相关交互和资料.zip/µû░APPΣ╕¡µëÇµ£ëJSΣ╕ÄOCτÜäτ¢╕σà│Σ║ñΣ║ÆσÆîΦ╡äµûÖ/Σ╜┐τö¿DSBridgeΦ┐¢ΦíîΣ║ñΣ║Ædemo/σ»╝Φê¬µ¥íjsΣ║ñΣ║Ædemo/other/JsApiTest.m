//
//  JsApiTest.m
//  dspider
//
//  Created by 杜文 on 16/12/30.
//  Copyright © 2016年 杜文. All rights reserved.
//
/**这个类里面都是  供js调用的本地接口*/
#import "JsApiTest.h"
#import "ZCHtmlTestVC.h"
@interface JsApiTest ()

@property(nonatomic,strong)ZCHtmlTestVC *htmlVC;
@end
@implementation JsApiTest

/**检测客户端运行环境接口*/
- (NSString *) isMangoClient:(NSDictionary *) args
{
    return @"true";
}

/**查看登录状态接口*/
- (NSString *) hasLogin:(NSDictionary *) args
{
    return @"true";
}

/**去登陆接口*/
- (NSString *) toLogin:(NSDictionary *) args
{
    return @"true";
}

/**退出登陆接口*/
- (NSString *) onLogout:(NSDictionary *) args
{
    //清空Cookie
    NSHTTPCookieStorage * myCookie = [NSHTTPCookieStorage sharedHTTPCookieStorage];
    for (NSHTTPCookie * cookie in [myCookie cookies])
    {
        [[NSHTTPCookieStorage sharedHTTPCookieStorage] deleteCookie:cookie];
    }
    
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:ZCCookieKey];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    //清除UIWebView的缓存
    [[NSURLCache sharedURLCache] removeAllCachedResponses];
    NSURLCache * cache = [NSURLCache sharedURLCache];
    [cache removeAllCachedResponses];
    [cache setDiskCapacity:0];
    [cache setMemoryCapacity:0];
    if ([self.delegate respondsToSelector:@selector(backHome)])
    {
        [self.delegate backHome];
    }
//    ZCHtmlTestVC *testVC = [[ZCHtmlTestVC alloc] init];
//    [testVC backHome];
    return nil;
}


/**本地获取定位信息接口*/
- (NSString *)refreshLocation:(NSDictionary *) args
{
    if ([self.delegate respondsToSelector:@selector(locationCityName)])
    {
        [self.delegate locationCityName];
    }
    return @"true";
}

@end
