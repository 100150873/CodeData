//
//  JsApiTest.h
//  dspider
//
//  Created by 杜文 on 16/12/30.
//  Copyright © 2016年 杜文. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol backDelegate <NSObject>
@optional
- (void)backHome;

- (void)locationCityName;
@end

@interface JsApiTest : NSObject

@property(nonatomic,weak) id <backDelegate> delegate;

@end
