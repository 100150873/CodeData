//
//  ZCNavigationController.m
//  导航条js交互demo
//
//  Created by mangocity.com on 2017/2/6.
//  Copyright © 2017年 mangocity.com. All rights reserved.
//

#import "ZCNavigationController.h"

@interface ZCNavigationController ()

@end

@implementation ZCNavigationController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationBar.hidden = YES;
}

#pragma mark
/**
 *  可以拦截所有push进来的子控制器
 */
- (void)pushViewController:(UIViewController *)viewController animated:(BOOL)animated
{
    

//    UIButton *buttonBack = [[UIButton alloc]init];
//    [buttonBack setTitle:@"返回" forState:UIControlStateNormal];
//    [buttonBack setBackgroundColor:[UIColor redColor]];
//    [buttonBack setTitleColor:[UIColor redColor] forState:UIControlStateNormal];
//    buttonBack.titleLabel.font = [UIFont systemFontOfSize:14];
//    [buttonBack addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchDown];
    if (self.childViewControllers.count > 0)
    {
     viewController.navigationItem.leftBarButtonItem = [[UIBarButtonItem alloc]initWithTitle:@"返回" style:UIBarButtonItemStyleDone target:self action:@selector(back)];
    
    }
   
    
    [super pushViewController:viewController animated:YES];
}

- (UIViewController *)popViewControllerAnimated:(BOOL)animated
{
    return [super popViewControllerAnimated:YES];
}

- (NSArray *)popToRootViewControllerAnimated:(BOOL)animated
{
    return [super popToRootViewControllerAnimated:animated];
}

- (void)back
{
    [self popViewControllerAnimated:YES];
}

@end
