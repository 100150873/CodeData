//
//  ZCTabBarController.m
//  导航条js交互demo
//
//  Created by mangocity.com on 2017/2/10.
//  Copyright © 2017年 mangocity.com. All rights reserved.
//

#import "ZCTabBarController.h"
#import "ZCNavigationController.h"
#import "ZCTestVC.h"
#import "ZCMyVC.h"
#import "ZCJourneyVC.h"
#import "ZCServiceVC.h"
#import "ZCDiscoverVC.h"
//#import "H5HomeViewController.h"
@interface ZCTabBarController ()

@end

@implementation ZCTabBarController

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setupChildControllers];
    // 2 设置tabBar上按钮内容 -> 由对应的子控制器的tabBarItem属性
    [self setupAllTitleButton];
    
}

// 只会调用一次
+ (void)load
{
    // 获取哪个类中UITabBarItem
    UITabBarItem *item = [UITabBarItem appearanceWhenContainedIn:self, nil];
    
    // 设置按钮选中标题的颜色:富文本:描述一个文字颜色,字体,阴影,空心,图文混排
    // 创建一个描述文本属性的字典
    NSMutableDictionary *attrs = [NSMutableDictionary dictionary];
    attrs[NSForegroundColorAttributeName] = [UIColor blackColor];
    [item setTitleTextAttributes:attrs forState:UIControlStateSelected];
    
    // 设置字体尺寸:只有设置正常状态下,才会有效果
    NSMutableDictionary *attrsNor = [NSMutableDictionary dictionary];
    attrsNor[NSFontAttributeName] = [UIFont systemFontOfSize:13];
    [item setTitleTextAttributes:attrsNor forState:UIControlStateNormal];
}

- (void)setupChildControllers
{
    ZCTestVC * testvc1 = [ZCTestVC new];
//    H5HomeViewController *homeVC = [H5HomeViewController new];
    ZCNavigationController *testVC = [[ZCNavigationController alloc]initWithRootViewController:testvc1];
    [self addChildViewController:testVC];
    
    ZCJourneyVC * journeyVC = [ZCJourneyVC new];
    ZCNavigationController *navJourneyVC = [[ZCNavigationController alloc]initWithRootViewController:journeyVC];
    [self addChildViewController:navJourneyVC];
    
    ZCServiceVC * serviceVC = [ZCServiceVC new];
    ZCNavigationController *navServiceVC = [[ZCNavigationController alloc]initWithRootViewController:serviceVC];
    [self addChildViewController:navServiceVC];
    
    ZCDiscoverVC * discoverVC = [ZCDiscoverVC new];
    ZCNavigationController *navDiscoverVC = [[ZCNavigationController alloc]initWithRootViewController:discoverVC];
    [self addChildViewController:navDiscoverVC];
    
    ZCMyVC * myVC = [ZCMyVC new];
    ZCNavigationController *navMyVC = [[ZCNavigationController alloc]initWithRootViewController:myVC];
    [self addChildViewController:navMyVC];
}


- (void)setupAllTitleButton
{
    // 0:nav
    UINavigationController *nav = self.childViewControllers[0];
    nav.tabBarItem.title = @"首页";
    nav.tabBarItem.image = [UIImage imageNamed:@"tabBar_essence_icon"];
    // 快速生成一个没有渲染图片
//    nav.tabBarItem.selectedImage = [UIImage imageOriginalWithName:@"tabBar_essence_click_icon"];
    
    // 1:新帖
    UINavigationController *nav1 = self.childViewControllers[1];
    nav1.tabBarItem.title = @"行程";
    nav1.tabBarItem.image = [UIImage imageNamed:@"tabBar_new_icon"];
//    nav1.tabBarItem.selectedImage = [UIImage imageOriginalWithName:@"tabBar_new_click_icon"];
    
    
    // 3.关注
    UINavigationController *nav3 = self.childViewControllers[2];
    nav3.tabBarItem.title = @"发现";
    nav3.tabBarItem.image = [UIImage imageNamed:@"tabBar_friendTrends_icon"];
//    nav3.tabBarItem.selectedImage = [UIImage imageOriginalWithName:@"tabBar_friendTrends_click_icon"];
    
    // 4.关注
    UINavigationController *nav4 = self.childViewControllers[3];
    nav4.tabBarItem.title = @"客服";
    nav4.tabBarItem.image = [UIImage imageNamed:@"tabBar_friendTrends_icon"];
//    nav3.tabBarItem.selectedImage = [UIImage imageOriginalWithName:@"tabBar_friendTrends_click_icon"];
    
    // 5.我
    UINavigationController *nav5 = self.childViewControllers[4];
    nav5.tabBarItem.title = @"我";
    nav5.tabBarItem.image = [UIImage imageNamed:@"tabBar_me_icon"];
//    nav4.tabBarItem.selectedImage = [UIImage imageOriginalWithName:@"tabBar_me_click_icon"];
}
@end
