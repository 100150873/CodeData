//
//  ZCTestVC.m
//  导航条js交互demo
//
//  Created by mangocity.com on 2017/2/6.
//  Copyright © 2017年 mangocity.com. All rights reserved.
//

#import "ZCTestVC.h"
#import "ZCHtmlTestVC.h"
@interface ZCTestVC ()

@property(nonatomic,strong)UIButton *buttonNext;
@end

@implementation ZCTestVC

- (void)viewDidLoad {
    [super viewDidLoad];
    //    self.view.backgroundColor = [UIColor redColor];
    self.title = @"首页";
    [self.buttonNext addTarget:self action:@selector(nextPage) forControlEvents:UIControlEventTouchDown];
}


- (void)nextPage
{
    ZCHtmlTestVC *htmlVC = [ZCHtmlTestVC new];
    [self.navigationController pushViewController:htmlVC animated:YES];
}

- (UIButton *)buttonNext
{
    if (!_buttonNext)
    {
        
        /**<#name#>button*/
        _buttonNext = [[UIButton alloc]init];
        [_buttonNext setBackgroundColor:[UIColor redColor]];
        [_buttonNext setTitle:@"从模块入口跳转到H5页面" forState:UIControlStateNormal];
        [_buttonNext setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        _buttonNext.titleLabel.font = [UIFont systemFontOfSize:14];
        _buttonNext.frame = CGRectMake(100, 200, 250, 150);
        [self.view addSubview:_buttonNext];
    }
    return _buttonNext;
}

@end
