//
//  ZCJourneyVC.h
//  导航条js交互demo
//
//  Created by mangocity.com on 2017/2/10.
//  Copyright © 2017年 mangocity.com. All rights reserved.
//

#import "ZCBaseViewController.h"

@interface ZCJourneyVC : ZCBaseViewController

@end
