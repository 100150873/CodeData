//
//  ZCBaseViewController.h
//  导航条js交互demo
//
//  Created by mangocity.com on 2017/2/6.
//  Copyright © 2017年 mangocity.com. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "CDNavigationView.h"
@interface ZCBaseViewController : UIViewController
@property (nonatomic , readonly) CDNavigationView *navigationView;

- (void)setBaseTitle:(NSString *)title;

- (void)initBackItemBar;

#pragma mark -  init Right Button
/**
 *  自定义一个button的按钮
 *
 *  @param rightButton 自定义的button
 */
- (void)setRightItemBar:(UIButton *)rightButton;

#pragma mark - hidden Navigation
/**
 *  设置是否显示NavigationView导航栏
 *
 *  @param hidden 是否需要显示的布尔值
 */
- (void)setBaseNavigationViewHidden:(BOOL)hidden;

@end
