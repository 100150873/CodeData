//
//  ZCHtmlTestVC.h
//  导航条js交互demo
//
//  Created by mangocity.com on 2017/2/6.
//  Copyright © 2017年 mangocity.com. All rights reserved.
//

#import <UIKit/UIKit.h>
//#import "JsApiTest.h"
#import "ZCBaseViewController.h"
@interface ZCHtmlTestVC : ZCBaseViewController
{
//    JsApiTest *jsApi;
}


- (void)backHome;

@end
