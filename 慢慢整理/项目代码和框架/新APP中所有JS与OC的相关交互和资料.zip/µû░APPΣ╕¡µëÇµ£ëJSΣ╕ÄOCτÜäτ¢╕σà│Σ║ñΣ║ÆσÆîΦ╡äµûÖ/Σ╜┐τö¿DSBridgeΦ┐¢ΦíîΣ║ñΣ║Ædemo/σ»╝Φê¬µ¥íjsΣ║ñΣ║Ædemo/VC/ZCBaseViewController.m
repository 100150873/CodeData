//
//  ZCBaseViewController.m
//  导航条js交互demo
//
//  Created by mangocity.com on 2017/2/6.
//  Copyright © 2017年 mangocity.com. All rights reserved.
//

#import "ZCBaseViewController.h"

@interface ZCBaseViewController ()

@end

@implementation ZCBaseViewController
@synthesize navigationView = _navigationView;
- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    // Do any additional setup after loading the view.
    self.automaticallyAdjustsScrollViewInsets = NO;
    self.view.backgroundColor = UI_BACKGROUND_COLOR;
}

- (void)viewWillLayoutSubviews
{
    [super viewWillLayoutSubviews];
    
    //  确保NavigationView是在整个view视图的最上层
    [self.view bringSubviewToFront:_navigationView];
}

- (void)setBaseTitle:(NSString *)title
{
    self.navigationView.title = title;
}

- (void)initBackItemBar
{
    [self.navigationView.backItemBar addTarget:self action:@selector(navigationBackItemBarClickedEvent:) forControlEvents:UIControlEventTouchUpInside];
}

- (void)navigationBackItemBarClickedEvent:(UIButton *)backItem
{
    [self.navigationController popViewControllerAnimated:YES];
    MGLog(@"如果子类有附加的事件要在返回时处理，请在子类控制器中重写该相应方法，利用重载特性 即可在各自的控制器中拦截 “返回” 的点击事件");
}

#pragma mark  init right buttton
- (void)setRightItemBar:(UIButton *)rightButton
{
    self.navigationView.rightItemBar = rightButton;
    [rightButton addTarget:self action:@selector(mangocityRightButtonClickedEvent:) forControlEvents:UIControlEventTouchUpInside];
}

- (void)mangocityRightButtonClickedEvent:(UIButton *)button
{
    MGLog(@"请在子类控制器中重写该相应方法，利用重载特性 即可在各自的控制器中拦截 “城市选择” 的点击事件");
}

#pragma mark  navigation view hidden and alpha
- (void)setBaseNavigationViewHidden:(BOOL)hidden
{
    self.navigationView.hidden = hidden;
    
}

- (CDNavigationView *)navigationView
{
    if (_navigationView == nil) {
        _navigationView = [[CDNavigationView alloc] init];
        _navigationView.backgroundColor = [UIColor whiteColor];
        [self.view addSubview:_navigationView];
        [_navigationView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.view);
            make.left.equalTo(self.view);
            make.right.equalTo(self.view);
            make.height.equalTo(@(MGNavigationViewHeight));
        }];
    }
    return _navigationView;
}

@end
