//
//  ZCHtmlTestVC.m
//  导航条js交互demo
//
//  Created by mangocity.com on 2017/2/6.
//  Copyright © 2017年 mangocity.com. All rights reserved.
//

#import "ZCHtmlTestVC.h"
#import "JsApiTest.h"
#import "dsbridge.h"

#define ZCCookieName @"NewSiteH5Cookie"
#define Test_URL @"http://mango-sh2.iask.in"
@interface ZCHtmlTestVC ()<JSBWebEventDelegateProtocol,backDelegate>

@property(nonatomic,strong)JsApiTest *jsApi;
@property(nonatomic,strong)UIButton *buttonRight;
@property(nonatomic,assign)BOOL backHomeFlag;
@property(nonatomic,strong)DUIwebview *webView;

@end

@implementation ZCHtmlTestVC

#pragma mark - view life
- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setBaseTitle:@"js与native交互"];
    [self initBackItemBar];
    [self setRightItemBar:self.buttonRight];
    self.automaticallyAdjustsScrollViewInsets = NO;
    //    self.webView = [[DWebview alloc] initWithFrame:CGRectMake(0, MGNavigationViewHeight, SCREEN_WIDTH, SCREEN_HEIGHT - MGNavigationViewHeight)];
    self.webView = [[DUIwebview alloc] initWithFrame:CGRectMake(0, MGNavigationViewHeight, SCREEN_WIDTH, SCREEN_HEIGHT - MGNavigationViewHeight)];
    self.webView.WebEventDelegate = self;
    self.webView.backgroundColor = UI_BACKGROUND_COLOR;
    _jsApi=[[JsApiTest alloc] init];
    _jsApi.delegate = self;
    self.webView.JavascriptInterfaceObject = _jsApi;
    [self.view addSubview:self.webView];
    
    //判断是否沙盒中是否有这个值
    if ([[[[NSUserDefaults standardUserDefaults]dictionaryRepresentation]allKeys]containsObject:ZCCookieKey]) {
        //获取cookies：程序起来之后，uiwebview加载url之前获取保存好的cookies，并设置cookies，
        NSArray *cookies =[[NSUserDefaults standardUserDefaults]  objectForKey:ZCCookieKey];
        NSMutableDictionary *cookieProperties = [NSMutableDictionary dictionary];
        [cookieProperties setObject:[cookies objectAtIndex:0] forKey:NSHTTPCookieName];
        [cookieProperties setObject:[cookies objectAtIndex:1] forKey:NSHTTPCookieValue];
        [cookieProperties setObject:[cookies objectAtIndex:3] forKey:NSHTTPCookieDomain];
        [cookieProperties setObject:[cookies objectAtIndex:4] forKey:NSHTTPCookiePath];
        NSHTTPCookie *cookieuser = [NSHTTPCookie cookieWithProperties:cookieProperties];
        [[NSHTTPCookieStorage sharedHTTPCookieStorage]  setCookie:cookieuser];
    }
    //发请求
    NSURLRequest *req = [NSURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@",Test_URL]]];//这个是主页的url，不是登录页的url
    _webView.scalesPageToFit = YES;
    [ self.webView loadRequest:req];
    
    __block DUIwebview * weakWebview = self.webView;

    [self.webView setJavascriptContextInitedListener:^{
        [weakWebview evaluateJavaScript:@"jsBridgeConnect()" completionHandler:^(NSString * value) {
            
        }];
    }];
    
}

- (void)viewWillLayoutSubviews
{

}


#pragma mark - Action
- (void)navigationBackItemBarClickedEvent:(UIButton *)backItem
{
    if (self.webView.canGoBack)
    {
//        [self.webView evaluateJavaScript:@"back()" completionHandler:^(NSString * _Nonnull result) {
//            DebugLog(@"==== = %@",result);
//        }];
//        if (self.backHomeFlag)
//        {
//        NSString *temp = [NSString stringWithFormat:@"back('http://mango-sh2.iask.in')"];
//            [self.webView callHandler:@"back()" arguments:@[@"http://mango-sh2.iask.in"] completionHandler:^(NSString * value) {
//                DebugLog(@"value = %@",value);
//            }];
//                [self.webView evaluateJavaScript:temp completionHandler:^(NSString * _Nonnull result) {
//                    DebugLog(@"==== = %@",result);
//                }];
//            self.backHomeFlag = NO;
//        }
//        else
//        {
            [self.webView goBack];
//        }
        
    }
    else
    {
        [self.navigationController popViewControllerAnimated:YES];
    }

}

- (void)mangocityRightButtonClickedEvent:(UIButton *)button
{
    [self.webView loadUrl:@"http://mango-sh2.iask.in/Account/Login?BackUrl=http%3a%2f%2fmango-sh2.iask.in%3a9002%2fAccount%2fUserCenter"];
}

#pragma mark - DUIwebview Delegate
- (void) onPageStart:(NSString *)url
{


}
- (void) onpageFinished:(NSString *)url
{

    NSArray *nCookies = [[NSHTTPCookieStorage sharedHTTPCookieStorage] cookies];
    NSHTTPCookie *cookie;
    for (id c in nCookies)
    {
        if ([c isKindOfClass:[NSHTTPCookie class]])
        {
            cookie=(NSHTTPCookie *)c;
            if ([cookie.name isEqualToString:ZCCookieName])
            {
                NSNumber *sessionOnly = [NSNumber numberWithBool:cookie.sessionOnly];
                NSNumber *isSecure = [NSNumber numberWithBool:cookie.isSecure];
//                NSDate *expiresDate = [NSDate dateWithTimeIntervalSinceNow:3600*24*30*12];//当前点后，保存一年左右
                NSArray *cookies = [NSArray arrayWithObjects:cookie.name, cookie.value, sessionOnly, cookie.domain, cookie.path, isSecure, nil];
                [[NSUserDefaults standardUserDefaults] setObject:cookies forKey:ZCCookieKey];
                [[NSUserDefaults standardUserDefaults] synchronize];
                break;
            }
        }
    }

}

- (void) onpageError:(NSString *)url :(NSString *) msg
{


}

#pragma mark - Public Method
- (void)locationCityName
{
    [self.webView callHandler:@"onLocation" arguments:@[@"深圳"] completionHandler:^(NSString * value) {
        DebugLog(@"value = %@",value);
    }];
  
}

- (void)backHome
{
//    [self.webView callHandler:@"back()" arguments:@[@"http://mango-sh2.iask.in"] completionHandler:^(NSString * value) {
//        DebugLog(@"value = %@",value);
//    }];
    self.backHomeFlag = YES;
}

#pragma mark - Getter
- (UIButton *)buttonRight
{
    if (!_buttonRight)
    {
        _buttonRight = [[UIButton alloc]init];
        [_buttonRight setBackgroundColor:[UIColor clearColor]];
        [_buttonRight setTitle:@"登录" forState:UIControlStateNormal];
        [_buttonRight setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        _buttonRight.titleLabel.font = [UIFont systemFontOfSize:14];
    }
    return _buttonRight;
}

@end
