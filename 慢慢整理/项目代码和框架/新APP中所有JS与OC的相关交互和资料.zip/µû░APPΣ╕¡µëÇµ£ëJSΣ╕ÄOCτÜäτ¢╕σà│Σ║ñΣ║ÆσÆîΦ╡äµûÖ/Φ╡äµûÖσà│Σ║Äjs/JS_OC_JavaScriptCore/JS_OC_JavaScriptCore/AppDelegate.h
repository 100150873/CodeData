//
//  AppDelegate.h
//  JS_OC_JavaScriptCore
//
//  Created by Harvey on 16/8/23.
//  Copyright © 2016年 Haley. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

