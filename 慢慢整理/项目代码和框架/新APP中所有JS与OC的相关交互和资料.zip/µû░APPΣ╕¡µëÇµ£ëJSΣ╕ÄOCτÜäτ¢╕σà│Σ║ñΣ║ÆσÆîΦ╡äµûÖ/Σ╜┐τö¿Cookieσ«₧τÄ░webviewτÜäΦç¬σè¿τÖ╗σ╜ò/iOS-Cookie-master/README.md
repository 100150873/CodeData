# iOS-Cookie
iOS-Cookie,a demo for cookie opration

python BinaryCookieReader.py org.skyfox.iOS-Cookie.binarycookies


- [iOS开发WKWebView Cookie的读取与写入,与UIWebView的Cookie共享](http://www.skyfox.org/ios-wkwebview-cookie-opration.html)
- [iOS HTTP网络请求Cookie的读取与写入(NSHTTPCookieStorage)](http://www.skyfox.org/ios-url-request-cookie.html)