//
//  JsApiTest.m
//  dspider
//
//  Created by 杜文 on 16/12/30.
//  Copyright © 2016年 杜文. All rights reserved.
//
/**这个类里面都是  供js调用的本地接口*/
#import "JsApiTest.h"

@implementation JsApiTest

- (NSString *) testSyn:(NSDictionary *) args
{/**js调用的该接口 args这个字典里放的是传过来的参数  并回调给js*/
    NSLog(@"--- = ");
    return [(NSString *)[args valueForKey:@"msg"] stringByAppendingString:@"[ syn call]"];
}

- (NSString *) testAsyn:(NSDictionary *) args :(void (^)(NSString * _Nullable result))completionHandler
{
    completionHandler([(NSString *)[args valueForKey:@"msg"] stringByAppendingString:@"[ asyn call]"]);
    return nil;
}

- (NSString *)testNoArgSyn:(NSDictionary *) args
{
    return  @"testNoArgSyn called [ syn call]";
}

- (void)testNoArgAsyn:(NSDictionary *) args :(void (^)(NSString * _Nullable result))completionHandler
{
    completionHandler(@"testNoArgAsyn called [ asyn call]");
}

@end
