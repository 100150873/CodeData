//
//  DefineHeader.h
//  MangocityTravel
//
//  Created by Cindy on 16/8/15.
//  Copyright © 2016年 Mangocity. All rights reserved.
//

#ifndef DefineHeader_h
#define DefineHeader_h







#pragma mark -
/********************************************** All Define ********************************************************/
#define MG_API_KEY   @"CAF4DEB6-11CA-44A9-96E3-ABC05717058F"
#define MG_SID      @"310033"
#define MG_UID      @"9953"
#define MG_CHANNELID @"0092001"


#define MG_MEMBER_INFO_KEY @"MGMemberUserInfoKey"
#define MG_MEMBER_WECHAT_OPEN_ID_KEY @"MGMemberWechatOpenIdKey"

#define CDFLIGHT_DEFAULT_LEAVE_CITY_NAME @"CDFlightDefaultLeaveCityName"
#define CDFLIGHT_DEFAULT_LEAVE_CITY_ID @"CDFlightDefaultLeaveCityID"
#define CDFLIGHT_DEFAULT_ARRIVE_CITY_NAME @"CDFlightDefaultArriveCityName"
#define CDFLIGHT_DEFAULT_ARRIVE_CITY_ID @"CDFlightDefaultArriveCityID"
#define CDFLIGHT_DEFAULT_TRIP_TYPE @"CDFlightDefaultTripType"
#define CDFLIGHT_DEFAULT_SEAT_TYPE @"CDFlightDefaultSeatType"
#define CDFLIGHT_SELECTED_HISTORY_CITYS @"CDFlightSelectedHistoryCitys"



#define MGUserDefaults  [NSUserDefaults standardUserDefaults]
#define WS(weakSelf)  __weak __typeof(&*self)weakSelf = self;
#define DebugLog(message, ...) NSLog(@"%s: " message, __PRETTY_FUNCTION__, ##__VA_ARGS__)
#define NSStringFormat(...) [NSString stringWithFormat:__VA_ARGS__]

// 判断手机型号
#define IS_IPHONE_6Plus     ([[UIScreen mainScreen ] bounds].size.height == 736)
#define IS_IPHONE_6         ([[UIScreen mainScreen ] bounds].size.height == 667)
#define IS_IPHONE_5         ([[UIScreen mainScreen ] bounds].size.height == 568)
#define IS_IPHONE_4         ([[UIScreen mainScreen ] bounds].size.height == 480)

#define MGFONT_20  [UIFont systemFontOfSize:20]
#define MGFONT_18  [UIFont systemFontOfSize:18]
#define MGFONT_16  [UIFont systemFontOfSize:16]
#define MGFONT_14  [UIFont systemFontOfSize:14]
#define MGFONT_12  [UIFont systemFontOfSize:12]
#define MGFONT_10  [UIFont systemFontOfSize:10]
#define MGFONT_BOLD_18  [UIFont boldSystemFontOfSize:18];
#define MGFONT_BOLD_16  [UIFont boldSystemFontOfSize:16]
#define MGFONT_BOLD_14  [UIFont boldSystemFontOfSize:14]
#define MGFONT_BOLD_12  [UIFont boldSystemFontOfSize:12]
#define MGFONT_BOLD_10  [UIFont boldSystemFontOfSize:10];

#define FONT_8  [UIFont systemFontOfSize:8]
#define FONT_9  [UIFont systemFontOfSize:9]
#define FONT_10 [UIFont systemFontOfSize:10]
#define FONT_11 [UIFont systemFontOfSize:11]
#define FONT_12 [UIFont systemFontOfSize:12]
#define FONT_13 [UIFont systemFontOfSize:13]
#define FONT_14 [UIFont systemFontOfSize:14]
#define FONT_15 [UIFont systemFontOfSize:15]
#define FONT_16 [UIFont systemFontOfSize:16]
#define FONT_17 [UIFont systemFontOfSize:17]
#define FONT_18 [UIFont systemFontOfSize:18]
#define FONT_20 [UIFont systemFontOfSize:20]
#define FONT_22 [UIFont systemFontOfSize:22]
#define FONT_23 [UIFont systemFontOfSize:23]
#define FONT_24 [UIFont systemFontOfSize:24]
#define FONT_25 [UIFont systemFontOfSize:25]
#define FONT_26 [UIFont systemFontOfSize:26]
#define FONT_27 [UIFont systemFontOfSize:27]
#define FONT_28 [UIFont systemFontOfSize:28]
#define FONT_29 [UIFont systemFontOfSize:29]
#define FONT_30 [UIFont systemFontOfSize:30]
#define FONT_31 [UIFont systemFontOfSize:31]
#define FontBoldSystem(textSize)  [UIFont boldSystemFontOfSize:(textSize)];
#define FontSystem(textSize)  [UIFont systemFontOfSize:(textSize)];
#define DefineFontLaoSangamMN(textSize)  [UIFont fontWithName:@"LaoSangamMN" size:(textSize)]
#define DefineFontHelveticaNeue(textSize)  [UIFont fontWithName:@"HelveticaNeue" size:(textSize)]



#define SCREEN_WIDTH   [UIScreen mainScreen].bounds.size.width
#define SCREEN_HEIGHT  [UIScreen mainScreen].bounds.size.height
#define STATUS_BAR_HEIGHT [[UIApplication sharedApplication] statusBarFrame].size.height
/**
 *  底部导航的高度
 */
#define MGTabBarBottomViewHeight  49.0f
#define MGNavigationViewHeight  64.0f

//  导航视图线条显色
#define LINE_BG  DefineColorRGB(230.0, 230.0, 230.0, 1.0)

//线条粗细度
#define CommonLineBorderWidth 0.8

//字体大小
#define MainTitleFont FONT_18 //头部主标题
#define GeneralTitleFont FONT_14 //普通标题
#define GeneralTextFont FONT_12 //普通文本
#define DescritionTextFont FONT_10 //普通描述文本
#define edgeFont FONT_10   //跟团游的边界

//按钮圆角
#define BigButtonCornerRadius  7.5 //大按钮圆角
#define SmallButtonCornerRadius  2 //小按钮圆角





/**
 *  获得指定颜色值的实例
 *  @param r R值
 *  @param g G值
 *  @param b B值
 *  @param a 透明度
 *  @return UIColor的一个实例
 */
#define DefineColorRGB(r, g, b, a)  [UIColor colorWithRed:(r)/255.0 green:(g)/255.0 blue:(b)/255.0 alpha:(a)]
/**
 *  获得指定颜色值的实例
 *  @param hexValue 十六进制颜色值
 *  @return UIColor的一个实例
 */
#define DefineColorHEX(hexValue) [UIColor colorWithRed:((float)((hexValue & 0xFF0000) >> 16))/255.0 green:((float)((hexValue & 0xFF00) >> 8))/255.0 blue:((float)(hexValue & 0xFF))/255.0 alpha:1.0]  // rgb颜色转换（16进制->10进制）

#define BootPageCorlor DefineColorHEX(0xf6f6f6) //引导页背景色
#define MainColor DefineColorHEX(0xff7e00) // 主色系 - 橙色
#define MidColorBlack DefineColorHEX(0x333333) //  标题色：黑
#define MidColorGray DefineColorHEX(0x666666) //  正文色：深灰黑
#define MidColorLightGray DefineColorHEX(0x999999) //  辅助色：浅灰黑

#define MGColorLine DefineColorHEX(0xeaeaea) //  辅助线或分割线条：浅灰

#define MidColorSilver DefineColorHEX(0xefefef) //中性色-银色
#define MidColorLight DefineColorHEX(0xcccccc) //中性色-浅灰
//tableview或其他有边框的边框颜色
#define   CommonBordorColor DefineColorHEX(0xcccccc)
#define CostarColor DefineColorHEX(0x21b0ae) //主辅色
/***@brief zise*/
#define ZS_BG [UIColor colorWithRed:186.f/255.0 green:47.f/255.0 blue:251.f/255.0 alpha:1]
/***@brief 浅蓝色*/
#define LIGHT_PINK [UIColor colorWithRed:240.f/255.0 green:72.f/255.0 blue:72.f/255.0 alpha:1]
/***@brief 淡灰色*/
#define LIGHT_GRAY [UIColor colorWithRed:235.f/255.0 green:235.f/255.0 blue:235.f/255.0 alpha:1]
/***@brief 深灰色*/
#define DARK_GRAY [UIColor colorWithRed:178.f/255.0 green:178.f/255.0 blue:178.f/255.0 alpha:1]
/***@brief 价格的颜色*/
#define DARK_PRICE_RED [UIColor colorWithRed:230.f/255.0 green:61.f/255.0 blue:9.f/255.0 alpha:1]
/***@brief 黑色*/
#define DARK_BACK [UIColor colorWithRed:100.f/255.0 green:100.f/255.0 blue:100.f/255.0 alpha:1]
/***@brief 浓咖啡色*/
#define COFFEE_BACK [UIColor colorWithRed:50.f/255.0 green:50.f/255.0 blue:50.f/255.0 alpha:1]
/***@brief 黑色*/
#define INPUT_COLOR [UIColor colorWithRed:204.f/255.0 green:204.f/255.0 blue:204.f/255.0 alpha:1]
/***@brief 深灰色*/
#define DARK_INPUT_GRAY [UIColor colorWithRed:50.f/255.0 green:50.f/255.0 blue:50.f/255.0 alpha:1]
/***@brief 红色*/
#define DARK_RED [UIColor colorWithRed:203.f/255.0 green:23.f/255.0 blue:23.f/255.0 alpha:1]
/***@brief 字体浅灰色*/
#define LAGHT_GEAY [UIColor colorWithRed:153.f/255.0 green:153.f/255.0 blue:153.f/255.0 alpha:1]
/***@brief 橙红色*/
#define MIDDEL_RED [UIColor colorWithRed:235.f/255.0 green:97.f/255.0 blue:0.f/255.0 alpha:1]
/***@brief 绿色*/
#define MIDDEL_GREEN [UIColor colorWithRed:30.f/255.0 green:160.f/255.0 blue:0.f/255.0 alpha:1]

/***@brief HTML5主题色*/
#define HTML5_GREEN [UIColor colorWithRed:138.f/255.0 green:205.f/255.0 blue:97.f/255.0 alpha:1]

/***@brief 淡灰色*/
#define LIGH_GRA [UIColor colorWithRed:243.f/255.0 green:243.f/255.0 blue:243.f/255.0 alpha:1]
/***@brief 黄色*/
#define LIGH_YELLOW [UIColor colorWithRed:255.f/255.0 green:190.f/255.0 blue:75.f/255.0 alpha:1]
/***@brief 芒果橙*/
#define MangoColor [UIColor colorWithRed:255.f/255.0 green:102.f/255.0 blue:0/255.0 alpha:1]
#define UI_BACKGROUND_COLOR [UIColor colorWithRed:245.0/255.0 green:245.0/255.0 blue:245.0/255.0 alpha:1]
#define MANGOCITY_DEBUG_FLAG    YES    //是否DEBUG状态

//标题字体颜色
#define CommonTitleTextColor 0x444444
//辅助色-绿
#define AssistColorGreen 0x1f9f8b
//普通字体颜色
#define CommonGrayTextColor 0x999999

//模块间距
#define ModuleDistance 10

// 测试线
#define MESSAGE_URL      @"http://10.10.39.59:8005/ctsp/"
// 正式线
//#define MESSAGE_URL      @"http://sg2.mangocity.com/ctsp/"
// 意见反馈
//#define Feedback_Url @""MESSAGE_URL"public/opinionPublish.do"

//团购订单地址
#define groupOrderAddress @"http://m.mangocity.com/html5/tuan/orderList.html"

// 当前运行的SDK版本号
#define SDK_VERSION [[[UIDevice currentDevice] systemVersion] floatValue]




#pragma mark - 关于自定义日历
#define CDCalendarDayOffset  (1+7)  //  一个月份item + 7个周item
#define CDCalendarMonthHeight  26.0
#define CDCalendarWeekHeight  30.0

#define MGScreenMarginAtLeftAndRight  15.0





#pragma mark - 关于日志输出
/**
 *  关于日志输出的宏定义
 */
// Log 开关控制
#ifdef DEBUG // 调试状态, 打开LOG功能
    // Log 颜色控制
    #define XCODE_COLORS_ESCAPE @"\033["
    #define XCODE_COLORS_RESET_FG  XCODE_COLORS_ESCAPE @"fg;" // Clear any foreground color
    #define XCODE_COLORS_RESET_BG  XCODE_COLORS_ESCAPE @"bg;" // Clear any background color
    #define XCODE_COLORS_RESET     XCODE_COLORS_ESCAPE @";"   // Clear any foreground or background color
    /**
     *  替换NSLog来使用，debug模式下可以打印很多方法名，行信息。
     *
     *  @return  color  log : bule、red、black
     */
    // 正常日志输出
    #define MGLog(...) NSLog(__VA_ARGS__)
    // 黑色日志输出
    #define MGDetailLog(fmt, ...) NSLog((@"--------------------------> %@ [Line %d] \n" fmt "\n\n"), [[NSString stringWithFormat:@"%s",__FILE__] lastPathComponent], __LINE__, ##__VA_ARGS__);
    //  蓝色日志输出
    #define MGDetailLogBlue(frmt, ...) NSLog((XCODE_COLORS_ESCAPE @"fg70,180,255; --------------------------> %@ [Line %d] \n" frmt "\n\n"      XCODE_COLORS_RESET), [[NSString stringWithFormat:@"%s",__FILE__] lastPathComponent], __LINE__,##__VA_ARGS__);
    //  红色日志输出
    #define MGDetailLogRed(frmt, ...) NSLog((XCODE_COLORS_ESCAPE @"fg255,0,0; --------------------------> %@ [Line %d] \n" frmt "\n\n" XCODE_COLORS_RESET),[[NSString stringWithFormat:@"%s",__FILE__] lastPathComponent], __LINE__, ##__VA_ARGS__);
    //DEBUG模式下打印日志,当前行以及弹出一个警告
    #define MGAlertLog(fmt, ...)  { UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"Alert Log" message:[NSString stringWithFormat:@"%@\n\n%@",[NSString stringWithFormat:@"%@\n[Line %d] ", [[NSString stringWithFormat:@"%s",__FILE__] lastPathComponent], __LINE__],[NSString stringWithFormat:fmt, ##__VA_ARGS__]]  delegate:nil cancelButtonTitle:@"Dismiss" otherButtonTitles:nil]; [alert show];}
#else // 发布状态, 关闭LOG功能
    #define MGLog(...)
    #define MGDetailLog(...)
    #define MGDetailLogBlue(...)
    #define MGDetailLogRed(frmt, ...)
    #define MGAlertLog(...)
#endif

#endif /* DefineHeader_h */
