// 导航返回接口
function PageNavGo(options)
 {
    alert(options);
	if (options) 
	{
        alert(options);
		var opt = {};
		opt.index = options.index && !isNaN(options.index) ? options.index : 0; //定义跳转的页面栈,选填,如果index不为0则跳转到指定页面栈
		opt.url = options.url ? options.url : '';//定义跳转的URL,选填;
		   if (opt.index !== 0) 
		{ //如果index不为空则跳转到指定页面栈
			window.history.go(opt.index);
		} 
		   else if (opt.url !== '')
		 { //如果URL不为空则跳转到指定URL,支持相对/绝对路径
			window.location.href = opt.url;
		} 
		   else
		 { //如果没有参则跳转到上一页
			window.history.back();
		}
	} 
	else 
	{ //如果没有传参options则跳转到上一页
		window.history.back();
	}
}
