//
//  ZCHtmlTestVC.m
//  导航条js交互demo
//
//  Created by mangocity.com on 2017/2/6.
//  Copyright © 2017年 mangocity.com. All rights reserved.
//

#import "ZCHtmlTestVC.h"
#import <JavaScriptCore/JavaScriptCore.h>
 NSString  *test_URL = @"http://mango-sh2.iask.in";
@interface ZCHtmlTestVC ()<UIWebViewDelegate>

@property(nonatomic,strong)UIButton *buttonRight;
@property(nonatomic,strong)UIWebView *webView;
@end

@implementation ZCHtmlTestVC

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self setBaseTitle:@"导航条js交互demo"];
    [self initBackItemBar];
    self.title = @"导航条js交互demo";
    self.webView.delegate = self;
//    [self.webView loadRequest:[NSURLRequest requestWithURL:[[NSBundle mainBundle] URLForResource:@"index" withExtension:@"html"]]];
    [self.webView loadRequest:[NSURLRequest requestWithURL:[NSURL URLWithString:@"http://mango-sh2.iask.in"]]];
    [self setRightItemBar:self.buttonRight];}

#pragma mark - <UIWebViewDelegate>
- (void)webViewDidFinishLoad:(UIWebView *)webView
{

}

- (BOOL)webView:(UIWebView *)webView shouldStartLoadWithRequest:(NSURLRequest *)request navigationType:(UIWebViewNavigationType)navigationType
{
    NSLog(@"%@",request.URL.absoluteString);
    return YES;
}

- (void)navigationBackItemBarClickedEvent:(UIButton *)backItem
{
    if (self.webView.canGoBack)
    {
         [self.webView stringByEvaluatingJavaScriptFromString:@"PageNavGo();"];

//        [self.webView goBack];
    }
    else
    {
        [self.navigationController popViewControllerAnimated:YES];
    }

}

- (void)mangocityRightButtonClickedEvent:(UIButton *)button
{
    [self.webView stringByEvaluatingJavaScriptFromString:@"jsBridgeConnect()"];
//    [self.webView stringByEvaluatingJavaScriptFromString:@"Bridge()"];
}

#pragma mark - Getter
- (UIWebView *)webView
{
    if (!_webView)
    {
        _webView = [[UIWebView alloc]init];
        _webView.scrollView.scrollEnabled = NO;
        [self.view addSubview:_webView];
        [_webView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.view).offset(MGNavigationViewHeight);
            make.bottom.equalTo(self.view);
            make.left.equalTo(self.view);
            make.right.equalTo(self.view);
        }];
    }
    return _webView;
}

- (UIButton *)buttonRight
{
    if (!_buttonRight)
    {
        _buttonRight = [[UIButton alloc]init];
        [_buttonRight setBackgroundColor:[UIColor clearColor]];
        [_buttonRight setTitle:@"交互" forState:UIControlStateNormal];
        [_buttonRight setTitleColor:[UIColor blackColor] forState:UIControlStateNormal];
        _buttonRight.titleLabel.font = [UIFont systemFontOfSize:14];
    }
    return _buttonRight;
}

@end
