//
//  ZCBaiduTool.m
//  GTTemplateAPP
//
//  Created by yixin on 2017/5/12.
//  Copyright © 2017年 GZC. All rights reserved.
//

#import "ZCBaiduTool.h"

@interface ZCBaiduTool ()<BMKPoiSearchDelegate>

/** poi检索对象 */
@property (nonatomic, strong) BMKPoiSearch *search;

/** 回调代码块 */
@property (nonatomic, copy) ResultBlock block;

@end

@implementation ZCBaiduTool

ZCSingletonM(ZCBaiduTool)

#pragma mark -懒加载
-(BMKPoiSearch *)search
{
    if (!_search) {
        _search = [[BMKPoiSearch alloc] init];
        _search.delegate = self;
    }
    return _search;
}

- (void)poiSearchWithCenter:(CLLocationCoordinate2D)center andKeyWord:(NSString *)key resultBlock:(ResultBlock)resultBlock
{
    // 记录block
    self.block = resultBlock;
    
    //发起检索
    BMKNearbySearchOption *option = [[BMKNearbySearchOption alloc]init];
    // 第几页
    option.pageIndex = 0;
    // 每一页数量
    option.pageCapacity = 10;
    option.location = center;
    // 搜索关键字
    option.keyword = @"小吃";
    BOOL flag = [self.search poiSearchNearBy:option];
    if(flag)
    {
        NSLog(@"周边检索发送成功");
    }
    else
    {
        NSLog(@"周边检索发送失败");
    }
}

- (void)addAnnotationWithCenter:(CLLocationCoordinate2D)center title:(NSString *)title subTitle:(NSString *)subTitle toMapView:(BMKMapView *)mapView
{
    // 添加大头针
    BMKPointAnnotation* annotation = [[BMKPointAnnotation alloc]init];
    annotation.coordinate = center;
    annotation.title = title;
    annotation.subtitle = subTitle;
    [mapView addAnnotation:annotation];
}


#pragma mark -BMKPoiSearchDelegate

//实现PoiSearchDeleage处理回调结果
- (void)onGetPoiResult:(BMKPoiSearch*)searcher result:(BMKPoiResult*)poiResultList errorCode:(BMKSearchErrorCode)error
{
    if (error == BMK_SEARCH_NO_ERROR) {
        //在此处理正常结果
        NSLog(@"获取到数据");
        
        // 获取兴趣点列表
        NSArray *pois = poiResultList.poiInfoList;
        self.block(pois, nil);
        
        
        
    }
    else if (error == BMK_SEARCH_AMBIGUOUS_KEYWORD){
        //当在设置城市未找到结果，但在其他城市找到结果时，回调建议检索城市列表
        // result.cityList;
        NSLog(@"起始点有歧义");
        self.block(nil, @"起始点有歧义");
    } else {
        self.block(nil, [NSString stringWithFormat:@"抱歉，未找到结果--%zd", error]);
    }
}

@end
