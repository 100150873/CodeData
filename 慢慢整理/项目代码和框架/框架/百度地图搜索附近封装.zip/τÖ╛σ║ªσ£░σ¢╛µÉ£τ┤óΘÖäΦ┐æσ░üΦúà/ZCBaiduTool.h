//
//  ZCBaiduTool.h
//  GTTemplateAPP
//
//  Created by yixin on 2017/5/12.
//  Copyright © 2017年 GZC. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <BaiduMapAPI_Map/BMKMapComponent.h>
#import <BaiduMapAPI_Location/BMKLocationComponent.h>
#import <BaiduMapAPI_Search/BMKSearchComponent.h>

typedef void(^ResultBlock)(NSArray<BMKPoiInfo *> *poiInfos, NSString *error);

@interface ZCBaiduTool : NSObject
ZCSingletonH(ZCBaiduTool)

/**
 *  自定义方法,根据中心还有关键字进行周边检索
 *
 *  @param center      中心
 *  @param key         关键字
 *  @param resultBlock 回调代码块
 */
- (void)poiSearchWithCenter:(CLLocationCoordinate2D)center andKeyWord:(NSString *)key resultBlock:(ResultBlock)resultBlock;

/**
 *  根据传入的中心还有标题和子标题, 添加大头针数据模型到地图
 *
 *  @param center   中心
 *  @param title    标题
 *  @param subTitle 子标题
 *  @param mapView  地图
 */
- (void)addAnnotationWithCenter:(CLLocationCoordinate2D)center title:(NSString *)title subTitle:(NSString *)subTitle toMapView:(BMKMapView *)mapView;


@end
