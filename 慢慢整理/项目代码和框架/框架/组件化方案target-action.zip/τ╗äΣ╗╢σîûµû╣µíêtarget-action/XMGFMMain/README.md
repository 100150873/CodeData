# XMGFMMain

[![CI Status](http://img.shields.io/travis/王顺子/XMGFMMain.svg?style=flat)](https://travis-ci.org/王顺子/XMGFMMain)
[![Version](https://img.shields.io/cocoapods/v/XMGFMMain.svg?style=flat)](http://cocoapods.org/pods/XMGFMMain)
[![License](https://img.shields.io/cocoapods/l/XMGFMMain.svg?style=flat)](http://cocoapods.org/pods/XMGFMMain)
[![Platform](https://img.shields.io/cocoapods/p/XMGFMMain.svg?style=flat)](http://cocoapods.org/pods/XMGFMMain)

## Example

To run the example project, clone the repo, and run `pod install` from the Example directory first.

## Requirements

## Installation

XMGFMMain is available through [CocoaPods](http://cocoapods.org). To install
it, simply add the following line to your Podfile:

```ruby
pod "XMGFMMain"
```

## Author

王顺子, test@qq.com

## License

XMGFMMain is available under the MIT license. See the LICENSE file for more info.
