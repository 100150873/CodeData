//
//  XMGMediatorManager+XMGMain.h
//  XMGFMMain
//
//  Created by 小码哥 on 2017/2/19.
//  Copyright © 2017年 王顺子. All rights reserved.
//

#import "XMGMediatorManager.h"

@interface XMGMediatorManager (XMGMain)

+ (UIViewController *)rootTabbarController;

+ (void)addChildVC: (UIViewController *)vc normalImageName: (NSString *)normalImageName selectedImageName:(NSString *)selectedImageName isRequiredNavController: (BOOL)isRequired;

+ (void)setTabbarMiddleBtnClick: (void(^)(BOOL isPlaying))middleClickBlock;


@end
