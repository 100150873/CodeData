//
//  XMGMediatorManager+XMGMain.m
//  XMGFMMain
//
//  Created by 小码哥 on 2017/2/19.
//  Copyright © 2017年 王顺子. All rights reserved.
//

#import "XMGMediatorManager+XMGMain.h"

@implementation XMGMediatorManager (XMGMain)

+ (UIViewController *)rootTabbarController {
    
    UIViewController *vc = [self performTarget:@"MainModuleAPI" action:@"rootTabBarCcontroller" params:nil isRequiredReturnValue:YES];
//    if (vc == nil) {
//        return [UIViewController 404Page];
//    }
    
    return vc;
}


+ (void)addChildVC: (UIViewController *)vc normalImageName: (NSString *)normalImageName selectedImageName:(NSString *)selectedImageName isRequiredNavController: (BOOL)isRequired {
    
    NSArray *param = @[vc, normalImageName, selectedImageName, @(isRequired)];
    [self performTarget:@"MainModuleAPI" action:@"addChildVC:" params:param isRequiredReturnValue:NO];
    
}


+ (void)setTabbarMiddleBtnClick: (void(^)(BOOL isPlaying))middleClickBlock {
    
    [self performTarget:@"MainModuleAPI" action:@"setTabbarMiddleBtnClick:" params:middleClickBlock isRequiredReturnValue:NO];
    
    
}


@end
