//
//  XMGViewController.h
//  XMGFMMain
//
//  Created by 王顺子 on 11/09/2016.
//  Copyright (c) 2016 王顺子. All rights reserved.
//

@import UIKit;

@interface XMGViewController : UIViewController

@end
