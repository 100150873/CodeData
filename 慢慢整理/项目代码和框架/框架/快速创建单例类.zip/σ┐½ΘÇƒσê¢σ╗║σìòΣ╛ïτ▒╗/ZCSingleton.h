//
//  ZCSingleton.h
//  GTTemplateAPP
//
//  Created by yixin on 2017/5/12.
//  Copyright © 2017年 GZC. All rights reserved.
//

#ifndef ZCSingleton_h
#define ZCSingleton_h

//******************************** 将类方法声明宏，传入类名 ********************************
#define ZCSingletonH(ClassName) +(instancetype) share##ClassName;



//********************************* 将方法的实现声明为宏 **********************************

#define ZCSingletonM(ClassName) static id _instance;\
\
+(instancetype)allocWithZone:(struct _NSZone *)zone\
{\
static dispatch_once_t onceToken;\
dispatch_once(&onceToken, ^{\
_instance = [super allocWithZone:zone];\
});\
\
return _instance;\
}\
\
\
+(instancetype)share##ClassName\
{\
static dispatch_once_t onceToken;\
dispatch_once(&onceToken, ^{\
_instance = [[self alloc] init];\
});\
\
return _instance;\
}\
\
\
-(id)copyWithZone:(NSZone *)zone\
{\
return _instance;\
}

#endif /* ZCSingleton_h */
