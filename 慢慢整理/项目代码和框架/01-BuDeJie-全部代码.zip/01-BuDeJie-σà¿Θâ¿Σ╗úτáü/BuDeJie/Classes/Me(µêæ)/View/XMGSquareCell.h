//
//  XMGSquareCell.h
//  BuDeJie
//
//  Created by xiaomage on 16/3/16.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import <UIKit/UIKit.h>
@class XMGSquareItem;
@interface XMGSquareCell : UICollectionViewCell
@property (nonatomic, strong) XMGSquareItem *item;
@end
