//
//  XMGVideoViewController.m
//  BuDeJie
//
//  Created by xiaomage on 16/3/18.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import "XMGVideoViewController.h"

@implementation XMGVideoViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
}

- (XMGTopicType)type
{
    return XMGTopicTypeVideo;
}
@end
