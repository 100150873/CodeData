//
//  XMGSubTagItem.h
//  BuDeJie
//
//  Created by xiaomage on 16/3/15.
//  Copyright © 2016年 小码哥. All rights reserved.
//

#import <Foundation/Foundation.h>
// image_list,sub_number,theme_name
@interface XMGSubTagItem : NSObject

@property (nonatomic, strong) NSString *theme_name;
@property (nonatomic, strong) NSString *image_list;
@property (nonatomic, strong) NSString *sub_number;

@end
