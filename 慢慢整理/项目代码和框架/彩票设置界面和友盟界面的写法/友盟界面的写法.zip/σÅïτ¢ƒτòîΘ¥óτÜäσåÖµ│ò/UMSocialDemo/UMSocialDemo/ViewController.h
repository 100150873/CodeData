//
//  ViewController.h
//  UMSocialDemo
//
//  Created by wyq.Cloudayc on 9/22/16.
//  Copyright © 2016 Umeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

