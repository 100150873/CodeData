//
//  UMSNavigationViewController.h
//  UMSocialSDK
//
//  Created by wyq.Cloudayc on 11/8/16.
//  Copyright © 2016 UMeng. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <UMSocialCore/UMSBaeViewController.h>

@interface UMSRootViewController : UMSBaeViewController

@end
