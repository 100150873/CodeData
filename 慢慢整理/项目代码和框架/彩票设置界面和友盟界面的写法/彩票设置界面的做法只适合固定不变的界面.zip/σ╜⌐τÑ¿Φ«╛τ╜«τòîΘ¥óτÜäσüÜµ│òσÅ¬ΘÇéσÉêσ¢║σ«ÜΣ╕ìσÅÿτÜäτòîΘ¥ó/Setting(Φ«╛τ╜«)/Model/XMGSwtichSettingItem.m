//
//  XMGSwtichSettingItem.m
//  小码哥彩票
//
//  Created by xiaomage on 15/7/1.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "XMGSwtichSettingItem.h"

@implementation XMGSwtichSettingItem

@end
