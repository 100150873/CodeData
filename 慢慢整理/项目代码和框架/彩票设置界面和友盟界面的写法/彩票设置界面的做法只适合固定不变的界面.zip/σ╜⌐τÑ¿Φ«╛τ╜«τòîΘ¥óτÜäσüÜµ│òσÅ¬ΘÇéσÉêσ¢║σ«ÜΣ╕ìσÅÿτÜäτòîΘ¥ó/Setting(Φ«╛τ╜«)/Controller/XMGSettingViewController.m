//
//  XMGSettingViewController.m
//  小码哥彩票
//
//  Created by xiaomage on 15/7/1.
//  Copyright (c) 2015年 xiaomage. All rights reserved.
//

#import "XMGSettingViewController.h"

#import "XMGSettingItem.h"
#import "XMGSettingGroup.h"


#import "XMGArrowSettingItem.h"
#import "XMGSwtichSettingItem.h"

#import "XMGSettingCell.h"

#import "XMGBlurView.h"
#import "MBProgressHUD+XMG.h"

@interface XMGSettingViewController ()

// 记录当前tableView的所有数组
@property (nonatomic, strong) NSMutableArray *groups;

@end

@implementation XMGSettingViewController

- (NSMutableArray *)groups
{
    if (_groups == nil) {
        _groups = [NSMutableArray array];
    }
    return _groups;
}

- (instancetype)init
{
  return [super initWithStyle:UITableViewStyleGrouped];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"设置";

    // 添加第一组
    [self setUpGroup0];
    
    [self setUpGroup1];
    
    [self setUpGroup2];
    
}

- (void)setUpGroup0
{
    XMGArrowSettingItem *redeemCode = [XMGArrowSettingItem itemWithImage:[UIImage imageNamed:@"RedeemCode"] title:@"使用兑换码"];
    redeemCode.destVc = [UIViewController class];
    
    // 当前组有多少行
    XMGSettingGroup *group = [XMGSettingGroup groupWithItems:@[redeemCode]];
    group.headTitle = @"asdasd";
    
    [self.groups addObject:group];
    
}

- (void)setUpGroup1
{
    
    XMGArrowSettingItem *redeemCode = [XMGArrowSettingItem itemWithImage:[UIImage imageNamed:@"RedeemCode"] title:@"使用兑换码"];
    
    XMGSwtichSettingItem *item = [XMGSwtichSettingItem itemWithImage:[UIImage imageNamed:@"RedeemCode"] title:@"使用兑换码"];
    XMGSwtichSettingItem *item1 = [XMGSwtichSettingItem itemWithImage:[UIImage imageNamed:@"RedeemCode"] title:@"使用兑换码"];
    XMGSwtichSettingItem *item2 = [XMGSwtichSettingItem itemWithImage:[UIImage imageNamed:@"RedeemCode"] title:@"使用兑换码"];
    
    
    // 当前组有多少行
    XMGSettingGroup *group = [XMGSettingGroup groupWithItems:@[redeemCode,item,item1,item2]];
    
    [self.groups addObject:group];
    
}

- (void)setUpGroup2
{
    XMGArrowSettingItem *version = [XMGArrowSettingItem itemWithImage:[UIImage imageNamed:@"RedeemCode"] title:@"检查有没有最新的版本"];
    
    version.itemOpertion = ^{
        XMGBlurView *blurView = [[XMGBlurView alloc] initWithFrame:XMGScreenBounds];
        
        [XMGKeyWindow addSubview:blurView];
        
        [MBProgressHUD showSuccess:@"当前木有最新的版本"];
        
        dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.5 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
            [blurView removeFromSuperview];
        });
    
    };
    
    // 当前组有多少行
    XMGArrowSettingItem *item = [XMGArrowSettingItem itemWithImage:[UIImage imageNamed:@"RedeemCode"] title:@"使用兑换码"];
    XMGArrowSettingItem *item1 = [XMGArrowSettingItem itemWithImage:[UIImage imageNamed:@"RedeemCode"] title:@"使用兑换码"];
    XMGArrowSettingItem *item2 = [XMGArrowSettingItem itemWithImage:[UIImage imageNamed:@"RedeemCode"] title:@"使用兑换码"];
    
    // 当前组有多少行
    XMGSettingGroup *group = [XMGSettingGroup groupWithItems:@[version,item,item1,item2]];
    
    [self.groups addObject:group];
}

#pragma mark - tableView数据源
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return self.groups.count;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    XMGSettingGroup *group = self.groups[section];
    
    return group.items.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    // 创建cell
    XMGSettingCell *cell = [XMGSettingCell cellWithTableView:tableView];
    
    // 取出哪一组
    XMGSettingGroup *group = self.groups[indexPath.section];
    
    // 取出哪一行
    XMGSettingItem *item = group.items[indexPath.row];
    
    // 给cell传递模型
    cell.item = item;
    
    return cell;
    
}

// 返回头部标题
- (NSString *)tableView:(UITableView *)tableView titleForHeaderInSection:(NSInteger)section
{
     XMGSettingGroup *group = self.groups[section];
    
    return group.headTitle;
}

// 返回尾部标题
- (NSString *)tableView:(UITableView *)tableView titleForFooterInSection:(NSInteger)section
{
    XMGSettingGroup *group = self.groups[section];
    
    return group.footTitle;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    // 取出哪一组
    XMGSettingGroup *group = self.groups[indexPath.section];
    
    // 取出哪一行
    XMGSettingItem *item = group.items[indexPath.row];
    
    if (item.itemOpertion) {
        item.itemOpertion();
        return;
    }
    
    if ([item isKindOfClass:[XMGArrowSettingItem class]]) {
        XMGArrowSettingItem *arrowItem = (XMGArrowSettingItem *)item;
        
        if (arrowItem.destVc) {
            // 才需要跳转
            // 创建跳转的控制器
            UIViewController *vc = [[arrowItem.destVc alloc] init];
            
            [self.navigationController pushViewController:vc animated:YES];
        }
        
    }
    
}

@end