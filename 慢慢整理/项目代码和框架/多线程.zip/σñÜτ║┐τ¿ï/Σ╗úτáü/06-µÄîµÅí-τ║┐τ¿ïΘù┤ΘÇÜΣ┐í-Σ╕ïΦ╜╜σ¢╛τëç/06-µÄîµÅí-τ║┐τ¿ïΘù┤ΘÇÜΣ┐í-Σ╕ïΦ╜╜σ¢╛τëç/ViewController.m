//
//  ViewController.m
//  06-掌握-线程间通信-下载图片
//
//  Created by xiaomage on 15/7/8.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imageView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    // 另外一种线程之间的通信方式
//    NSPort;
//    NSMessagePort;
//    NSMachPort;
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [self performSelectorInBackground:@selector(download3) withObject:nil];
}

- (void)download3
{
    // 图片的网络路径
    NSURL *url = [NSURL URLWithString:@"http://img.pconline.com.cn/images/photoblog/9/9/8/1/9981681/200910/11/1255259355826.jpg"];
    
    // 加载图片
    NSData *data = [NSData dataWithContentsOfURL:url];
    
    // 生成图片
    UIImage *image = [UIImage imageWithData:data];
    
    // 回到主线程，显示图片
    [self.imageView performSelector:@selector(setImage:) onThread:[NSThread mainThread] withObject:image waitUntilDone:NO];
//    [self.imageView performSelectorOnMainThread:@selector(setImage:) withObject:image waitUntilDone:NO];
//    [self performSelectorOnMainThread:@selector(showImage:) withObject:image waitUntilDone:YES];
}

//- (void)showImage:(UIImage *)image
//{
//    self.imageView.image = image;
//}

- (void)download2
{
    // 图片的网络路径
    NSURL *url = [NSURL URLWithString:@"http://img.pconline.com.cn/images/photoblog/9/9/8/1/9981681/200910/11/1255259355826.jpg"];
    
    CFTimeInterval begin = CFAbsoluteTimeGetCurrent();
    // 根据图片的网络路径去下载图片数据
    NSData *data = [NSData dataWithContentsOfURL:url];
    CFTimeInterval end = CFAbsoluteTimeGetCurrent();
    
    NSLog(@"%f", end - begin);
    
    // 显示图片
    self.imageView.image = [UIImage imageWithData:data];
}

- (void)download
{
    // 图片的网络路径
    NSURL *url = [NSURL URLWithString:@"http://img.pconline.com.cn/images/photoblog/9/9/8/1/9981681/200910/11/1255259355826.jpg"];
    
    NSDate *begin = [NSDate date];
    // 根据图片的网络路径去下载图片数据
    NSData *data = [NSData dataWithContentsOfURL:url];
    NSDate *end = [NSDate date];
    
    NSLog(@"%f", [end timeIntervalSinceDate:begin]);
    
    // 显示图片
    self.imageView.image = [UIImage imageWithData:data];
}

@end
