//
//  ViewController.h
//  05-掌握-线程安全
//
//  Created by xiaomage on 15/7/8.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController


@end

