//
//  ViewController.m
//  01-处理耗时操作
//
//  Created by xiaomage on 15/7/8.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (IBAction)buttonClick {
    for (NSInteger i = 0; i<50000; i++) {
        NSLog(@"------buttonClick---%zd", i);
    }
}

@end
