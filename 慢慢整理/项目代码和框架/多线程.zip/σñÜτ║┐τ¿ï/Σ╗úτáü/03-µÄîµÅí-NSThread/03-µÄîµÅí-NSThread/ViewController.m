//
//  ViewController.m
//  03-掌握-NSThread
//
//  Created by xiaomage on 15/7/8.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

#import "ViewController.h"
#import "XMGThread.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [self createThread3];
}

- (void)createThread3
{
    [self performSelectorInBackground:@selector(run:) withObject:@"jack"];
}

- (void)createThread2
{
    [NSThread detachNewThreadSelector:@selector(run:) toTarget:self withObject:@"rose"];
}

- (void)createThread1
{
    //    // 创建线程
    //    NSThread *thread = [[NSThread alloc] initWithTarget:self selector:@selector(run:) object:@"jack"];
    //    // 启动线程
    //    [thread start];
    // 创建线程
    XMGThread *thread = [[XMGThread alloc] initWithTarget:self selector:@selector(run:) object:@"jack"];
    thread.name = @"my-thread";
    // 启动线程
    [thread start];
}

- (void)run:(NSString *)param
{
    for (NSInteger i = 0; i<100; i++) {
        NSLog(@"-----run-----%@--%@", param, [NSThread currentThread]);
    }
}

@end
