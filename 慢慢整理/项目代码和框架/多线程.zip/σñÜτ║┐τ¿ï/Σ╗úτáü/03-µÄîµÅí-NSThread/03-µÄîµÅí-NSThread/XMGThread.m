//
//  XMGThread.m
//  03-掌握-NSThread
//
//  Created by xiaomage on 15/7/8.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

#import "XMGThread.h"

@implementation XMGThread
- (void)dealloc
{
    NSLog(@"XMGThread -- dealloc");
}
@end
