//
//  XMGCar.m
//  10-掌握-单粒模式
//
//  Created by xiaomage on 15/7/8.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

#import "XMGCar.h"

@interface XMGCar()

@end

@implementation XMGCar
XMGSingletonM(Car)
@end
