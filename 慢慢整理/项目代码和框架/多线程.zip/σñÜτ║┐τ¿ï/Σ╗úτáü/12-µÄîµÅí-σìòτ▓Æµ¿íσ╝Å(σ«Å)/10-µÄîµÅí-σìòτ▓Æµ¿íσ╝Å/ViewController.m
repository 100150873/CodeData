//
//  ViewController.m
//  10-掌握-单粒模式
//
//  Created by xiaomage on 15/7/8.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

#import "ViewController.h"
#import "XMGPerson.h"
#import "XMGCar.h"

@interface ViewController ()

@end

@implementation ViewController

XMGSingletonM(ViewController)

- (void)viewDidLoad {
    [super viewDidLoad];
    
    NSLog(@"%@ %@", [ViewController sharedViewController], [[ViewController alloc] init]);
    NSLog(@"%@ %@", [XMGCar sharedCar], [[XMGCar alloc] init]);
    
//    XMGPerson *person1 = [[XMGPerson alloc] init];
//    person1.name = @"jack";
//    
//    XMGPerson *person2 = [[XMGPerson alloc] init];
//    XMGPerson *person3 = [[XMGPerson alloc] init];
//    XMGPerson *person4 = [[XMGPerson alloc] init];
    
//    NSLog(@"%p %p %p %p", person1, person2, person3, person4);
//    NSLog(@"%@", person3.name);
    
//    NSLog(@"%@ %@", [XMGPerson sharedPerson], [XMGPerson sharedPerson]);
}

@end
