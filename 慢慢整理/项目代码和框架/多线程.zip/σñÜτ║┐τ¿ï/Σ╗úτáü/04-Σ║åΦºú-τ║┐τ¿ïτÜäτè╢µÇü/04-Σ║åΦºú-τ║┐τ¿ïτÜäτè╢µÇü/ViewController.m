//
//  ViewController.m
//  04-了解-线程的状态
//
//  Created by xiaomage on 15/7/8.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)touchesBegan:(NSSet *)touches withEvent:(UIEvent *)event {
    [NSThread detachNewThreadSelector:@selector(run) toTarget:self withObject:nil];
}

- (void)run
{
    for (NSInteger i = 0; i<100; i++) {
        NSLog(@"-----%zd", i);
        
        if (i == 49) {
            [NSThread exit]; // 直接退出线程
        }
    }
}

- (void)run2
{
    NSLog(@"-------");
//    [NSThread sleepForTimeInterval:2]; // 让线程睡眠2秒（阻塞2秒）
//    [NSThread sleepUntilDate:[NSDate distantFuture]];
    [NSThread sleepUntilDate:[NSDate dateWithTimeIntervalSinceNow:2]];
    NSLog(@"-------");
}

@end
