//
//  main.m
//  03-复制
//
//  Created by MLJ on 14-5-18.
//  Copyright (c) 2014年 itcast. All rights reserved.
//

#import <Foundation/Foundation.h>

int main(int argc, const char * argv[])
{
    @autoreleasepool {
        
    }
    return 0;
}

/**
 NSMutableString调用mutableCopy ： 深复制
 */
void mutableStringMutableCopy()
{
    NSMutableString *srcStr = [NSMutableString stringWithFormat:@"age is %d", 10];
    NSMutableString *copyStr = [srcStr mutableCopy];
    
    [copyStr appendString:@"abc"];
    
    NSLog(@"srcStr=%@, copyStr=%@", srcStr, copyStr);
}

/**
 NSMutableString调用copy ： 深复制
 */
void mutableStringCopy()
{
    NSMutableString *srcStr = [NSMutableString stringWithFormat:@"age is %d", 10];
    
    NSString *copyStr = [srcStr copy];
    
    
    [srcStr appendString:@"abc"];
    
    NSLog(@"srcStr=%p, copyStr=%p", srcStr, copyStr);
}

/**
 NSString调用mutableCopy ： 深复制
 */
void stringMutableCopy()
{
    NSString *srcStr = [NSString stringWithFormat:@"age is %d", 10];
    
    NSMutableString *copyStr =  [srcStr mutableCopy];
    [copyStr appendString:@"abc"];
    
    NSLog(@"srcStr=%@, copyStr=%@", srcStr, copyStr);
}

/**
 NSString调用copy : 浅复制
 */
void stringCopy()
{
    //  copy ： 产生的肯定是不可变副本
    
    //  如果是不可变对象调用copy方法产出不可变副本，那么不会产生新的对象，指针复制
    NSString *srcStr = [NSString stringWithFormat:@"age is %d", 10];
    NSString *copyStr = [srcStr copy];
    
    NSLog(@"%p %p", srcStr, copyStr);
}

