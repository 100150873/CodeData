//
//  NineViewController.h
//  ByValue
//
//  Created by SDC201 on 16/5/24.
//  Copyright © 2016年 PCEBG. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Singleton.h"

@interface NineViewController : UIViewController

@end
