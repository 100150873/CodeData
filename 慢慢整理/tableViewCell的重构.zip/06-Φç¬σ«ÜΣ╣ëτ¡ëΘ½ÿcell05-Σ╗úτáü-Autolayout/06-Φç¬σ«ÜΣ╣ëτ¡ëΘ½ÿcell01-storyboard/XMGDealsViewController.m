//
//  XMGDealsViewController.m
//  06-自定义等高cell01-storyboard
//
//  Created by xiaomage on 15/6/2.
//  Copyright (c) 2015年 小码哥. All rights reserved.
//

#import "XMGDealsViewController.h"
#import "XMGDeal.h"
#import "XMGDealCell.h"

@interface XMGDealsViewController ()
/** 所有的团购数据 */
@property (nonatomic, strong) NSArray *deals;
@end

@implementation XMGDealsViewController

- (NSArray *)deals
{
    if (_deals == nil) {
        // 加载plist中的字典数组
        NSString *path = [[NSBundle mainBundle] pathForResource:@"deals.plist" ofType:nil];
        NSArray *dictArray = [NSArray arrayWithContentsOfFile:path];
        
        // 字典数组 -> 模型数组
        NSMutableArray *dealArray = [NSMutableArray array];
        for (NSDictionary *dict in dictArray) {
            XMGDeal *deal = [XMGDeal dealWithDict:dict];
            [dealArray addObject:deal];
        }
        
        _deals = dealArray;
    }
    return _deals;
}


- (void)viewDidLoad {
    [super viewDidLoad];
    
//    UINib *nib = [UINib nibWithNibName:NSStringFromClass([XMGDealCell class]) bundle:nil];
//    [self.tableView registerNib:nib forCellReuseIdentifier:@"deal"];
    
    [self.tableView registerClass:[XMGDealCell class] forCellReuseIdentifier:@"deal"];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Table view data source
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return self.deals.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    //创建cell
    XMGDealCell *cell = [XMGDealCell cellWithTableView:tableView];
    // 取出模型数据
    cell.deal = self.deals[indexPath.row];
    
    return cell;
}

@end
